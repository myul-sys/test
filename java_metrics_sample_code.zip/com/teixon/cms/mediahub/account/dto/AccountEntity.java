package com.teixon.cms.mediahub.account.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

/**
 * 시스템 계정 정보
 *
 * @author matin
 **/
@Entity
@Table(name = "account_tbl")
@EntityListeners(value = {AuditingEntityListener.class})
public class AccountEntity {

	/**
	 * default constructor
	 */
	public AccountEntity() {
		// this.registDate = new Date();

		this.status = AccountStatus.Used;
		this.accountType = AccountType.Account;
	}

	/**
	 * 계정 ID
	 */
	@Id
	@Column(name = "acct_id", nullable = false)
	@GenericGenerator(name = "acct_id_uuid", strategy = "com.teixon.cms.mediahub.common.jpa.id.UUIDGenerator")
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "acct_id_uuid")
	private String accountId;

	/**
	 * 계정 명
	 */
	@Column(name = "acct_nm", nullable = false, length = 500)
	private String name;

	/**
	 * 계정 로그인 아이디
	 */
	@Column(name = "acct_login_id", nullable = false, length = 100)
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String loginId;

	/**
	 * 계정 비밀번호
	 */
	@Column(name = "acc_pwd", nullable = false, length = 200)
	@JsonProperty(value = "password", access = JsonProperty.Access.WRITE_ONLY)
	private String password;

	/**
	 * 등록 일자
	 */
	@CreatedDate
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_dt", nullable = false)
	// @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date registDate;

	/**
	 * account type
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "acct_type", nullable = false, length = 100)
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private AccountType accountType;

	/**
	 * 상태
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "status", nullable = false, length = 100)
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private AccountStatus status;

	/**
	 * 상태
	 *
	 * @author matin
	 */
	public enum AccountStatus {
		/**
		 * 사용
		 */
		Used,
		/**
		 * 미사용
		 */
		NotUsed,
	}

	/**
	 * 유형 *
	 *
	 * @author matin
	 */
	public enum AccountType {
		/**
		 * 관리자
		 */
		Admin,

		/**
		 * 일반 계정
		 */
		Account,
	}

	/**
	 * @return the accountId
	 */
	public String getAccountId() {

		return accountId;
	}

	/**
	 * @return the name
	 */
	public String getName() {

		return name;
	}

	/**
	 * @param name
	 * 		the name to set
	 */
	public void setName(final String name) {

		this.name = name;
	}

	/**
	 * @return the loginId
	 */
	public String getLoginId() {

		return loginId;
	}

	/**
	 * @param loginId
	 * 		the loginId to set
	 */
	public void setLoginId(final String loginId) {

		this.loginId = loginId;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {

		return password;
	}

	/**
	 * @param password
	 * 		the password to set
	 */
	public void setPassword(final String password) {

		this.password = password;
	}

	/**
	 * @return the registDate
	 */
	public Date getRegistDate() {

		return registDate;
	}

	/**
	 * @return the accountType
	 */
	public AccountType getAccountType() {

		return accountType;
	}

	/**
	 * @param accountType
	 * 		the accountType to set
	 */
	public void setAccountType(final AccountType accountType) {

		this.accountType = accountType;
	}

	/**
	 * @return the status
	 */
	public AccountStatus getStatus() {

		return status;
	}

	/**
	 * @param status
	 * 		the status to set
	 */
	public void setStatus(final AccountStatus status) {

		this.status = status;
	}

}
