package com.teixon.cms.mediahub.account.repository;


/**
 * AccountFindRepositoryImpl
 *
 * @author matin
 */
public class AccountFindRepositoryImpl implements AccountFindRepository {

}
