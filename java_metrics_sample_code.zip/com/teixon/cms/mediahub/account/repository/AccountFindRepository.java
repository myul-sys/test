package com.teixon.cms.mediahub.account.repository;

/**
 * AccountFindRepository
 *
 * @author matin
 */
public interface AccountFindRepository {

}
