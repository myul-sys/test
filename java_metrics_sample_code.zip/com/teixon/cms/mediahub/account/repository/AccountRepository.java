package com.teixon.cms.mediahub.account.repository;

import com.teixon.cms.mediahub.account.dto.AccountEntity;
import com.teixon.cms.mediahub.account.dto.AccountEntity.AccountStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * AccountEntity 관리 Repository
 *
 * @author matin
 **/
@Repository
public interface AccountRepository extends JpaRepository<AccountEntity, String>,
		AccountFindRepository {

	/**
	 * @param loginId
	 * 		account login id
	 * @param statues
	 * 		account status
	 *
	 * @return count same login id and status
	 */
	@Query(value = //
			       "SELECT COUNT(acct) FROM AccountEntity acct WHERE acct.loginId = :loginId AND acct.status in ( :statues )")
	int countByLoginId(
			@Param("loginId") String loginId,
			@Param("statues") Set<AccountStatus> statues);

	/**
	 * @param statues
	 * 		account status
	 *
	 * @return count same login id and status
	 */
	@Query(value = //
			"SELECT acct FROM AccountEntity acct WHERE acct.status in ( :statues )")
	Optional<List<AccountEntity>> findByStatues(
			@Param("statues") Set<AccountStatus> statues);

}
