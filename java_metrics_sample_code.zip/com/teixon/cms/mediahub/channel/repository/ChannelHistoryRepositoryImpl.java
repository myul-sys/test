package com.teixon.cms.mediahub.channel.repository;


import com.teixon.cms.mediahub.channel.dto.ChannelHistoryEntity;
import com.teixon.cms.mediahub.channel.dto.ChannelFindCondition;
import com.teixon.cms.mediahub.channel.dto.ChannelHistoryList;
import com.teixon.cms.mediahub.repository.event.EventEntity;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.*;

/**
 * 채널 히스토리 목록을 조회 한다
 *
 * @author lastkwy
 **/
@Repository(value = "ChannelHistoryRepository")
public class ChannelHistoryRepositoryImpl implements ChannelHistoryFindRepository  {
    /**
     * entity manager
     */
    @Autowired
    private EntityManager em;

    /**
     * 로그 핸들
     */
    private final Logger logger = LoggerFactory.getLogger(ChannelHistoryRepositoryImpl.class);

    @Override
    public ChannelHistoryList findByList(final ChannelFindCondition condition) {

        logger.debug("findByList [condition = {}]", condition);

        // make query
        final CriteriaBuilder cb = this.em.getCriteriaBuilder();
        final CriteriaQuery<ChannelHistoryEntity> cqSelect = cb.createQuery(ChannelHistoryEntity.class);
        final Root<ChannelHistoryEntity> selectRoot = cqSelect.from(ChannelHistoryEntity.class);

        cqSelect.select(selectRoot);
        cqSelect.where(getPredicates(selectRoot, condition));
        cqSelect.orderBy(cb.desc(selectRoot.get("registerDate")));

        if(condition.keywordType != null && ( condition.keywordType.equals("eventName") || condition.keywordType.toLowerCase().equals("all"))) {
            Join<ChannelHistoryEntity,EventEntity> join = selectRoot.join("event", JoinType.LEFT);
        }

        final TypedQuery<ChannelHistoryEntity> querySelect = this.em.createQuery(cqSelect);

        querySelect.setFirstResult((int) condition.getOffset());
        querySelect.setMaxResults(condition.getPageSize());

        final List<ChannelHistoryEntity> list = querySelect.getResultList();
        final Long totalCount = countByList(condition);

        return new ChannelHistoryList(list, totalCount, condition.getOffset(), condition.getPageSize());
    }

    @Override
    public Long countByList(final ChannelFindCondition condition) {

        logger.debug("countByList [condition = {}]", condition);

        final CriteriaBuilder cb = this.em.getCriteriaBuilder();
        final CriteriaQuery<Long> cqCount = cb.createQuery(Long.class);
        final Root<ChannelHistoryEntity> countRoot = cqCount.from(ChannelHistoryEntity.class);
        if(condition.keywordType != null && ( condition.keywordType.equals("eventName") || condition.keywordType.toLowerCase().equals("all"))) {
            Join<ChannelHistoryEntity,EventEntity> join = countRoot.join("event", JoinType.LEFT);
        }
        // count query
        cqCount.select(cb.count(countRoot));
        cqCount.where(getPredicates(countRoot, condition));

        return this.em.createQuery(cqCount).getSingleResult();
    }

    /**
     * 검색 조건을 생성 한다
     *
     * @param root
     * 		ChannelHistoryEntity root
     * @param condition
     * 		조건
     *
     * @return 검색 조건 목록
     */
    private Predicate[] getPredicates(
            final Root<ChannelHistoryEntity> root,
            final ChannelFindCondition condition) {

        logger.debug("getPredicates [condition = {}]", condition);

        final CriteriaBuilder cb = this.em.getCriteriaBuilder();
        final List<Predicate> predicates = new ArrayList<>();

        predicates.add(cb.and(cb.equal(root.get("accountId"), condition.accountId)));

        Optional.of(condition.dateRange)
            .filter(range -> !range.isEmpty())
            .ifPresent(range -> {
                Date to = range.getTo();
                Calendar cal = Calendar.getInstance();
                cal.setTime(to);

                cal.add(Calendar.DATE, 1);
                cal.add(Calendar.MILLISECOND, -1);

                final Predicate p = cb.between(root.get("startDate"), range.getFrom() , cal.getTime());
                predicates.add(p);
            });

        Optional.ofNullable(condition.keyword) //
                .filter(keyword -> !keyword.equals("null") && !StringUtils.trimToEmpty(keyword).isBlank()) //
                .ifPresent(keyword -> {
                    if(condition.keywordType == null || condition.keywordType.toLowerCase().equals("all"))
                        condition.keywordType = "all";

                    switch(condition.keywordType){
                        case "channelHistoryId":
                        case "channelId":
                        case "eventId":
                            final Predicate p = cb.and(//
                                    cb.or(//
                                            cb.like(root.get(condition.keywordType), String.format("%%%s%%", keyword)) //
                                    ));
                            predicates.add(p);
                            break;
                        case "all":
                            final Predicate p2 = cb.and(//
                                    cb.or(//
                                            cb.like(root.get("channelHistoryId"), String.format("%%%s%%", keyword)), //
                                            cb.like(root.get("channelId"), String.format("%%%s%%", keyword)), //
                                            cb.like(root.get("eventId"), String.format("%%%s%%", keyword)), //
                                            cb.like(root.get("event").get("title"), String.format("%%%s%%", keyword))
                                    ));
                            predicates.add(p2);
                            break;
                        case "eventName":
                            final Predicate p3 = cb.and(//
                                    cb.or(//
                                            cb.like(root.get("event").get("title"), String.format("%%%s%%", keyword))
                                    ));
                            predicates.add(p3);
                            break;
                    }
                });

        return predicates.toArray(new Predicate[predicates.size()]);
    }

}
