package com.teixon.cms.mediahub.channel.repository;

import com.teixon.cms.mediahub.channel.dto.ChannelFindCondition;
import com.teixon.cms.mediahub.channel.dto.ChannelHistoryList;


public interface ChannelHistoryFindRepository {
    /**
     * 채널 히스토리 목록을 조회한다
     *
     * @param condition
     * 		채널 히스토리 목록 조회 조건
     *
     * @return 채널 히스토리 목록
     */
    ChannelHistoryList findByList(ChannelFindCondition condition);

    /**
     * 채널 히스토리 목록의 갯수를 가져온다
     *
     * @param condition
     * 		채널 히스토리 목록 조회 조건
     *
     * @return  채널 히스토리 총 갯수
     */
    Long countByList(final ChannelFindCondition condition);

}
