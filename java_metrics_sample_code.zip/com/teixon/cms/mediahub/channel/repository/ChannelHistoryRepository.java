package com.teixon.cms.mediahub.channel.repository;


import com.teixon.cms.mediahub.channel.dto.ChannelHistoryEntity;
import com.teixon.cms.mediahub.channel.dto.ChannelHistoryStatistics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * channel entity management repository
 *
 * @author lastkwy
 */
public interface ChannelHistoryRepository extends JpaRepository<ChannelHistoryEntity, String>, ChannelHistoryFindRepository  {


    /**
     * get a channel detail
     *
     * @param accountId
     * 		account id
     * @param channelId
     * 		channel id
     *
     * @return channel detail {@link ChannelHistoryEntity}
     */
    @Query(value = //
            "SELECT chl FROM ChannelHistoryEntity chl WHERE chl.accountId = :accountId AND chl.channelId = :channelId ")
    Optional<ChannelHistoryEntity> findByChannelId(
            @Param("accountId") String accountId,
            @Param("channelId") String channelId);

    /**
     * get a channel detail
     *
     * @param accountId
     * 		account id
     * @param channelHistoryId
     * 		channel history id
     *
     * @return channel detail {@link ChannelHistoryEntity}
     */
    @Query(value = //
            "SELECT chl FROM ChannelHistoryEntity chl WHERE chl.accountId = :accountId AND chl.channelHistoryId = :channelHistoryId ")
    Optional<ChannelHistoryEntity> findByChannelHistoryId(
            @Param("accountId") String accountId,
            @Param("channelHistoryId") String channelHistoryId);


    /**
     * channel history statistics
     *
     * @param from
     * 		search statistics from date( YYYY-MM-DD )
     * @param to
     * 		search statistics to date( YYYY-MM-DD )
     *
     * @return statistics list {@link ChannelHistoryStatistics}
     */
    @Query(nativeQuery = true, value = //
            "select " +
                    "    a.date as date, " +
                    "    GREATEST(SUM(b.totalTime) ,0) as  totalSecond, " +
                    "    GREATEST(CAST(SUM(b.totalTime/3600) AS INTEGER) ,0) as  totalTime " +
                    "from " +
                    "    ( " +
                    "    SELECT to_char(GENERATE_SERIES(to_date(:from,'YYYY-MM-DD') ,to_date(:to,'YYYY-MM-DD'), INTERVAL '1 day'),'YYYY-MM-DD')  AS date " +
                    "    )  a -- 날짜 기간 자동 생성 쿼리 \n " +
                    "     left join " +
                    "    ( " +
                    "        select to_char(reg_dt, 'YYYY-MM-DD') as date, " +
                    "               EXTRACT(EPOCH from end_dt - start_dt) as totalTime from channel_history_tbl where acct_id = :accountId and end_dt is not null" +
                    "    )  b ON a.date = b.date\n" +
                    "group by a.date " +
                    "order by a.date")
    Optional<List<ChannelHistoryStatistics>> findByChannelHistoryStatistics(
            @Param("accountId") String accountId,
            @Param("from") String from,
            @Param("to") String to);

    /**
     * get a channel detail
     *
     * @param accountId
     * 		account id
     *
     * @return channel detail {@link ChannelHistoryEntity}
     */
    @Query(value = //
            "SELECT chl FROM ChannelHistoryEntity chl WHERE chl.accountId = :accountId AND chl.assignId = :assignId AND chl.channelId = :channelId AND chl.contentsId = :contentsId")
    Optional<ChannelHistoryEntity> findByRecordInfo(
            @Param("accountId") String accountId,
            @Param("channelId") String channelId,
            @Param("contentsId") String contentsId,
            @Param("assignId") String assignId);
}
