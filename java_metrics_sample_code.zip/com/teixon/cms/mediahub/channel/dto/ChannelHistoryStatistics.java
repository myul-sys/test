package com.teixon.cms.mediahub.channel.dto;


/**
 * channel history information entity
 *
 * @author lastkwy
 */
public interface ChannelHistoryStatistics {

    String getDate();
    int getTotalSecond();
    int getTotalTime();
}


