package com.teixon.cms.mediahub.channel.dto;


import java.util.List;

public class ChannelHistoryStatisticsData {
    public List<ChannelHistoryStatistics>  reference;
    public Integer referenceTotal;

    public List<ChannelHistoryStatistics>  previous;
    public Integer previousTotal;
}
