package com.teixon.cms.mediahub.channel.dto;

import com.teixon.cms.mediahub.common.data.BaseCondition;
import com.teixon.cms.mediahub.common.utils.DateRange;
import com.teixon.cms.mediahub.repository.channel.ChannelAssignedDeviceType;
import com.teixon.cms.mediahub.repository.channel.ChannelStatus;
import com.teixon.cms.mediahub.user.dto.UserEntity;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public final class ChannelFindCondition extends BaseCondition {

    /**
     * account id
     */
    public String accountId;

    /**
     * channel id
     */
    public String channelId;

    /**
     * area id
     */
    public String eventId;

    /**
     * area id 제외한 검색
     */
    public Boolean isNullEvent;

    /**
     * channel search keyword
     */
    public String keyword;

    /**
     * channel search keyword type
     * - 전체 : All
     * - 할당일련번호 : channelHistoryId
     * - 채널ID : channelId
     * - 현장명 : eventName
     * - 현장ID : eventId
     * - 촬영자 : deviceOwnerName
     * - 스크림주소 - channelUrl
     */
    public String keywordType;

    /**
     * channel DeviceType set String parameter
     */
    public Set<String> deviceType;

    /**
     * channel DeviceType set query
     */
    public Set<ChannelAssignedDeviceType> findDeviceType;

    /**
     * channel statuses set String parameter
     */
    public Set<String> statuses;

    /**
     * channel statuses set query
     */
    public Set<ChannelStatus> findStatuses;

    /** 시작일 끝일 */
    public DateRange dateRange;


    /** 검색 기간 값 */
    public Integer dateRangeValue;

    /**
     * constructor
     */
    public ChannelFindCondition() {
        this(0, Integer.MAX_VALUE);
        this.isNullEvent = false;
        initStatuses();
        this.deviceType = new HashSet<>();

        dateRange = new DateRange(null,null);
        dateRangeValue = 0;
    }

    public void initStatuses(){
        this.statuses = new HashSet<String>(Arrays.asList(
                ChannelStatus.Error.toString(),
                ChannelStatus.Ready.toString(),
                ChannelStatus.Wait.toString()));
    }

    /**
     * @param pageNumber
     * 		page number (begin 0)
     * @param pageSize
     * 		page size
     */
    public ChannelFindCondition(final Integer pageNumber, final Integer pageSize) {
        super(pageNumber, pageSize);
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public void setAccountId(String accountId) {

        this.accountId = accountId;
    }

    public void setChannelId(String channelId) {

        this.channelId = channelId;
    }

    public void setEventId(String eventId) {

        this.eventId = eventId;
    }

    public void setIsNullEvent(Boolean isNullEvent) {

        this.isNullEvent = isNullEvent;
    }

    public void setStatuses(Set<String> statuses) {
        this.statuses = statuses;
    }


    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public void setKeywordType(String keywordType) {
        this.keywordType = keywordType;
    }

    public void setDateRange(DateRange dateRange) {
        this.dateRange = dateRange;
    }

    public DateRange getDateRange() {
        return this.dateRange;
    }

    public void setDateRangeValue(Integer dateRangeValue) {
        this.dateRangeValue = dateRangeValue;
    }


}