package com.teixon.cms.mediahub.channel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import com.teixon.cms.mediahub.repository.channel.ChannelAssignedDeviceType;
import com.teixon.cms.mediahub.repository.channel.ChannelStatus;
import com.teixon.cms.mediahub.repository.contents.ContentsEntity;
import com.teixon.cms.mediahub.repository.device.DeviceResultEntity;
import com.teixon.cms.mediahub.repository.event.EventResultEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * channel history information entity
 *
 * @author lastkwy
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "channel_history_tbl")
public class ChannelHistoryEntity implements Serializable {

    /**
     * channel history id
     */
    @Id
    @Column(name = "channel_his_id", nullable = false, updatable = false, length = ColumnLength.UUID)
    @GenericGenerator(name = "channel_history_id_count", strategy = "com.teixon.cms.mediahub.common.jpa.id.CountGenerator")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "channel_history_id_count")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String channelHistoryId;

    /**
     * channel history id
     *
     * @return channel history id
     */
    public String getChannelHistoryId() {

        return channelHistoryId;
    }

    /**
     * account id
     */
    @Column(name = "channel_id", length = ColumnLength.TITLE)
    public String channelId;

    /**
     * account id
     */
    @Column(name = "acct_id", nullable = false, updatable = false, length = ColumnLength.UUID)
    public String accountId;

    /**
     * contents id
     */
    @Column(name = "ct_id", length = ColumnLength.UUID)
    public String contentsId;

    @OneToOne
    @JoinColumn(name = "ct_id", insertable = false, updatable = false, foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    public ContentsEntity contents;

    /**
     * channel name
     */
    @Column(name = "channel_name", nullable = false, length = ColumnLength.TITLE)
    public String name;

    /**
     * channel url (
     */
    @Column(name = "channel_url", length = ColumnLength.TITLE)
    public String channelUrl;


    /**
     * channel key
     */
    @Column(name = "channel_key", length = ColumnLength.TITLE)
    public String channelKey;

    /**
     * channel url
     */
    @Column(name = "live_url", length = ColumnLength.TITLE)
    public String liveUrl;

    /**
     * channel status
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 100)
    public ChannelStatus status;

    /**
     * channel added date
     */
    @Column(name = "start_dt")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    public Date startDate;

    /**
     * channel added date
     */
    @Column(name = "end_dt")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    public Date endDate;

    /**
     * channel mod date
     */
    @Column(name = "mod_dt", nullable = false)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    public Date modifyDate;

    /**
     * channel added date
     */
    @CreatedDate
    @Column(name = "reg_dt", nullable = false)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    public Date registerDate;

    //--------------------------------------- 채널 기본 정보 외 정보 시작

    /**
     * event id
     */
    @Column(name = "event_id", length = ColumnLength.UUID)
    public String eventId;

    @OneToOne
    @JoinColumn(name = "event_id", insertable = false, updatable = false, foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    public EventResultEntity event;

    /**
     * device type
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "device_type", length = ColumnLength.STATUS)
    public ChannelAssignedDeviceType deviceType;

    /**
     * device id
     */
    @Column(name = "device_id", length = ColumnLength.UUID)
    public String deviceId;

    @OneToOne
    @JoinColumn(name = "device_id", insertable = false, updatable = false, foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    public DeviceResultEntity device;

    @Transient
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    public String deviceOwnerName;

    public String getDeviceOwnerName() {
        if (device != null) {
            return device.getOwnerName();
        }
        return null;
    }

    @Transient
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    public String deviceOwnerPhone;

    public String getDeviceOwnerPhone() {
        if (device != null) {
            return device.getOwnerPhone();
        }
        return null;
    }

//	/** owner name */
//	@Column(name = "device_owner_nm", length = ColumnLength.TITLE)
//	public String deviceOwnerName;
//
//	/** owner phone */
//	@Column(name = "device_owner_phone", length = ColumnLength.TITLE)
//	public String deviceOwnerPhone;

    /**
     * worker id
     */
    @Column(name = "worker_id", length = ColumnLength.UUID)
    public String workerId;


    /**
     * access id(할당 받은 유저 아이디)
     */
    @Column(name = "assign_id", length = ColumnLength.UUID)
    public String assignId;

    /**
     * channel added date
     */
    @Column(name = "assign_dt")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    public Date assignDate;
    //--------------------------------------- 채널 기본 정보 외 정보 끝


    public ChannelHistoryEntity() {

        this.status = ChannelStatus.Ready;
    }

    @PreUpdate
    public void preUpdate() {

        this.modifyDate = new Date();
    }

    @Override
    public String toString() {

        return ToStringBuilder.reflectionToString(this);
    }

}