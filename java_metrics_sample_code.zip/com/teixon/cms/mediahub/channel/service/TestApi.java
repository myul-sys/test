package com.teixon.cms.mediahub.channel.service;

import com.teixon.cms.mediahub.common.utils.StringFormatter;
import org.json.simple.JSONObject;
import org.springframework.web.util.UriTemplate;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.Charset;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

public class TestApi {
    private static final HttpClient httpClient = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_2)
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    String accept = "application/json; charset=utf-8";
    String contentType = "application/json; charset=utf-8";

    String wowzaHost = "221.146.70.207:8087";
    String apiVersion = "v2";
    String apiTarget = "servers";
    String baseUrl = "http://{wowzaHost}/{apiVersion}/{apiTarget}";

    private String getBaseUrl(Map<String,String> path){
        return URI.create(StringFormatter.fromValues(baseUrl, path)).toString();
    }


    private HttpRequest.Builder GetBuilder(String url) {
        HttpRequest.Builder result = HttpRequest.newBuilder();
        result.uri(URI.create(url)).setHeader("Accept", accept).setHeader("Content-Type", contentType);
        return result;
    }


    public void WowzaStreamFileCreate(String name, String serverName , String uri){
        String defaultServerName = serverName == null ? "_defaultServer_" : serverName;

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("name", name);
        jsonObject.put("serverName", defaultServerName);
        jsonObject.put("uri", uri);

        Map<String, String> path = new HashMap<>();
        path.put("wowzaHost",wowzaHost);
        path.put("apiVersion",apiVersion);
        path.put("apiTarget",apiTarget);

        String requestUrl = getBaseUrl(path);

        HttpRequest request = GetBuilder( String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/streamfiles",requestUrl))
                .POST(HttpRequest.BodyPublishers.ofString(jsonObject.toJSONString()))
                .build();

        CompletableFuture<HttpResponse<String>> response =
                httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString());

        String result = "";
        try {
            result = response.thenApply(HttpResponse::body).get(5, TimeUnit.SECONDS);

            this.WowzaStreamFileConnect(name);
        } catch (Exception e) {

        }

        System.out.println("WowzaStreamFileCreate");
        System.out.println(result);
    }


    public void WowzaStreamFileGet(String name) {

        Map<String, String> path = new HashMap<>();
        path.put("wowzaHost",wowzaHost);
        path.put("apiVersion",apiVersion);
        path.put("apiTarget",apiTarget);

        String requestUrl = getBaseUrl(path);

        String url = String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/streamfiles/%s",requestUrl,URLEncoder.encode(name, Charset.forName("UTF-8")) );
        HttpRequest request = GetBuilder(url)
                .GET()
                .build();

        CompletableFuture<HttpResponse<String>> response =
                httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString());

        String result = "";
        try {
            result = response.thenApply(HttpResponse::body).get(5, TimeUnit.SECONDS);
        } catch (Exception e) {

        }

        System.out.println(result);

    }

    public void WowzaStreamFileDelete(String name) {

        Map<String, String> path = new HashMap<>();
        path.put("wowzaHost",wowzaHost);
        path.put("apiVersion",apiVersion);
        path.put("apiTarget",apiTarget);

        String requestUrl = getBaseUrl(path);

        String url = String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/streamfiles/%s",requestUrl,URLEncoder.encode(name, Charset.forName("UTF-8")) );
        HttpRequest request = GetBuilder(url)
                .DELETE()
                .build();

        CompletableFuture<HttpResponse<String>> response =
                httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString());

        String result = "";
        try {
            result = response.thenApply(HttpResponse::body).get(5, TimeUnit.SECONDS);
        } catch (Exception e) {

        }

        System.out.println(result);

    }

    public void WowzaStreamFileList(){
        Map<String, String> path = new HashMap<>();
        path.put("wowzaHost",wowzaHost);
        path.put("apiVersion",apiVersion);
        path.put("apiTarget",apiTarget);

        String requestUrl = getBaseUrl(path);

        HttpRequest request = GetBuilder(String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/streamfiles",requestUrl))
                .GET()
                .build();

        CompletableFuture<HttpResponse<String>> response =
                httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString());

        String result = "";
        try {
            result = response.thenApply(HttpResponse::body).get(5, TimeUnit.SECONDS);
        } catch (Exception e) {
            System.err.println(e);
        }

        System.out.println(result);
    }

    public void WowzaStreamFileConnect(String name) {
        Map<String, String> path = new HashMap<>();
        path.put("wowzaHost",wowzaHost);
        path.put("apiVersion",apiVersion);
        path.put("apiTarget",apiTarget);

        String requestUrl = getBaseUrl(path);


        Map<String, String> parameter = new HashMap<>();
        parameter.put("connectAppName","live");
        parameter.put("appInstance","_definst_");
        parameter.put("mediaCasterType","rtp");


        String url = String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/streamfiles/%s",requestUrl,URLEncoder.encode(name, Charset.forName("UTF-8")) );
        url = url + String.format("/actions/connect%s",StringFormatter.fromParameter(parameter));
        HttpRequest request = GetBuilder(url)
                .PUT(HttpRequest.BodyPublishers.noBody())
                .build();

        CompletableFuture<HttpResponse<String>> response =
                httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString());

        String result = "";
        try {
            result = response.thenApply(HttpResponse::body).get(5, TimeUnit.SECONDS);
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("WowzaStreamFileConnect");
        System.out.println(result);

    }

    public void WowzaStreamFileDisconnect(String name) {
        Map<String, String> path = new HashMap<>();
        path.put("wowzaHost",wowzaHost);
        path.put("apiVersion",apiVersion);
        path.put("apiTarget",apiTarget);

        String requestUrl = getBaseUrl(path);

        String url = String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/instances/_definst_/incomingstreams/%s.stream",requestUrl,URLEncoder.encode(name, Charset.forName("UTF-8")) );
        url = url + String.format("/actions/disconnectStream");
        HttpRequest request = GetBuilder(url)
                .PUT(HttpRequest.BodyPublishers.noBody())
                .build();

        CompletableFuture<HttpResponse<String>> response =
                httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString());

        String result = "";
        try {
            result = response.thenApply(HttpResponse::body).get(5, TimeUnit.SECONDS);
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("WowzaStreamFileDisconnect");
        System.out.println(result);
    }

}