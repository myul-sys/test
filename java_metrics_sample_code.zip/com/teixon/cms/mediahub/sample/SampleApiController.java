package com.teixon.cms.mediahub.sample;

import com.teixon.cms.mediahub.common.utils.DateRange;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/api/sample")
@RestController
public class SampleApiController {

	//	@GetMapping("/rangeParam")
	//	public RangeParam(
	//			@ModelAttribute final RangeParam param
	//	) {
	//
	//		return param;
	//	}


	public class RangeParam {

		public DateRange dateRange;

	}

}
