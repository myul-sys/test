package com.teixon.cms.mediahub.log.repository;

import com.teixon.cms.mediahub.log.dto.LoginLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoginLogRepository extends JpaRepository<LoginLogEntity, String> {
}
