package com.teixon.cms.mediahub.log.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@EntityListeners(value = AuditingEntityListener.class)
@Table(name = "login_log_tbl")
public class LoginLogEntity {

	/**
	 * area id
	 */
	@Id
	@Column(name = "login_log_id", updatable = false, nullable = false, length = ColumnLength.UUID)
	@GenericGenerator(name = "login_log_id_uuid", strategy = "com.teixon.cms.mediahub.common.jpa.id.UUIDGenerator")
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "login_log_id_uuid")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String loginLogId;

	/**
	 * 접속 유저 ID
	 */
	@Column(name = "user_id", updatable = false, nullable = false, length = ColumnLength.UUID)
	public String userId;
	
	/**
	 * 접속 IP
	 */
	@Column(name = "ip", updatable = false, nullable = false, length = ColumnLength.UUID)
	public String ip;

	/**
	 * user name
	 */
	@Column(name = "user_nm", nullable = false, length = ColumnLength.NAME)
	public String name;

	/**
	 * user added date
	 */
	@CreatedDate
	@Column(name = "reg_dt", nullable = false)
	public Date registerDate;
}
