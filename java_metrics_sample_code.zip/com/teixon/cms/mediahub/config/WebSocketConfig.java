package com.teixon.cms.mediahub.config;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    /** 로그 핸들 */
    private final Logger logger = LoggerFactory.getLogger(WebSocketConfig.class);

    @Override
    public void registerStompEndpoints(final StompEndpointRegistry registry){
        //endpoint register
        registry.addEndpoint("/notice").addInterceptors(new HttpHandshakeInterceptor()).withSockJS();
    }

    @Override
    public void configureMessageBroker(final MessageBrokerRegistry config){
        config.setApplicationDestinationPrefixes("/");
        //topic -> receiver alarm, queue -> sender alarm
        config.enableSimpleBroker("/topic","queue");
    }
}
