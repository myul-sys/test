package com.teixon.cms.mediahub.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;

/**
 * spring async thread 관리
 *
 * @author matin
 */
@Configuration
@EnableAsync
@EnableScheduling
public class SpringAsyncConfig implements SchedulingConfigurer {

	/** 로그 핸들 */
	private final Logger logger = LoggerFactory.getLogger(SpringAsyncConfig.class);

	/** 스케쥴러 관려 설정 */
	@Override
	public void configureTasks(final ScheduledTaskRegistrar scheduledTaskRegistrar) {

		final ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();

		threadPoolTaskScheduler.setPoolSize(10);
		threadPoolTaskScheduler.setThreadNamePrefix("JM_TASK-");
		threadPoolTaskScheduler.initialize();

		scheduledTaskRegistrar.setTaskScheduler(threadPoolTaskScheduler);

	}

	/**
	 * Thread executor 관련 설정
	 *
	 * @return 실행 객체
	 */
	@Bean(name = "threadPoolTaskExecutor")
	public Executor threadPoolTaskExecutor() {

		final ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setCorePoolSize(2);
		taskExecutor.setMaxPoolSize(300);
		taskExecutor.setQueueCapacity(10);
		taskExecutor.setThreadNamePrefix("JM_EXEC-");
		taskExecutor.initialize();
		return new HandlingExecutor(taskExecutor); // HandlingExecutor로 wrapping 합니다.
	}

	/**
	 * HandlingExecutor
	 *
	 * @author matin
	 */
	public class HandlingExecutor implements AsyncTaskExecutor {

		/** executor */
		private final AsyncTaskExecutor executor;

		/**
		 * 생성자
		 *
		 * @param executor
		 * 		비동기 실행객체
		 */
		public HandlingExecutor(final AsyncTaskExecutor executor) {

			this.executor = executor;
		}

		@Override
		public void execute(final Runnable task) {

			executor.execute(task);
		}

		@Override
		public void execute(final Runnable task, final long startTimeout) {

			executor.execute(createWrappedRunnable(task), startTimeout);
		}

		@Override
		public Future<?> submit(final Runnable task) {

			return executor.submit(createWrappedRunnable(task));
		}

		@Override
		public <T> Future<T> submit(final Callable<T> task) {

			return executor.submit(createCallable(task));
		}

		/**
		 * @param <T>
		 * 		객체
		 * @param task
		 * 		작업
		 *
		 * @return 작업 정보
		 */
		private <T> Callable<T> createCallable(final Callable<T> task) {

			return () -> {
				try {
					return task.call();
				} catch (final Exception ex) {
					handle(ex);
					throw ex;
				}
			};
		}

		/**
		 * @param task
		 * 		작업
		 *
		 * @return thread
		 */
		private Runnable createWrappedRunnable(final Runnable task) {

			return () -> {
				try {
					task.run();
				} catch (final Exception ex) {
					handle(ex);
				}
			};
		}

		/**
		 * @param ex
		 * 		오류 처리 내용
		 */
		private void handle(final Exception ex) {

			logger.info("Failed to execute task. : {}", ex.getMessage());
			logger.error("Failed to execute task. ", ex);
		}

	}

}
