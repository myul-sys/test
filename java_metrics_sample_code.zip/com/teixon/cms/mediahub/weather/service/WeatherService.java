package com.teixon.cms.mediahub.weather.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.teixon.cms.mediahub.repository.event.EventEntity;
import com.teixon.cms.mediahub.weather.dto.WeatherAreaEntity;
import com.teixon.cms.mediahub.weather.dto.WeatherEventDataEntity;
import com.teixon.cms.mediahub.weather.dto.WeatherEventEntity;
import com.teixon.cms.mediahub.weather.dto.WeatherEventLogEntity;
import com.teixon.cms.mediahub.weather.repository.WeatherAreaRepository;
import com.teixon.cms.mediahub.weather.repository.WeatherEventDataRepository;
import com.teixon.cms.mediahub.weather.repository.WeatherEventLogRepository;
import com.teixon.cms.mediahub.weather.repository.WeatherEventRepository;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class WeatherService {

    /**
     * logger
     */
    private final Logger logger = LoggerFactory.getLogger(WeatherService.class);

    @Autowired
    WeatherEventRepository weatherEventRepo;

    @Autowired
    WeatherEventLogRepository weatherEventLogRepo;

    @Autowired
    WeatherEventDataRepository weatherEventDataRepo;

    @Autowired
    WeatherAreaRepository weatherAreaRepo;

    int TIMEOUT_VALUE = 2500;   // 1초

    private String key = "ITpd4AdG%2FfZgpZ6sR3zeovFvPK1yR6XXZJhIgrSX21SvXfjyLtRKql1tSItrHn%2BZVn00NnwSOTV7Nn6wtx3Dsg%3D%3D";
    private String getJsonInfo(String weatherInfo){
        JsonElement node = new JsonParser().parse(weatherInfo);
        JsonObject nodeObject = node.getAsJsonObject();
        JsonObject responseObject = nodeObject.getAsJsonObject("response");
        JsonObject bodyObject = responseObject.getAsJsonObject("body");
        JsonObject itemsObject = bodyObject.getAsJsonObject("items");
        JsonArray items = itemsObject.getAsJsonArray("item");

        JsonObject tempNode = new JsonObject();
        JsonArray tempItems = new JsonArray();

        for(int i = 0; i< items.size(); i++) {
            tempItems.add(items.get(i).getAsJsonObject());
        }
        tempNode.add("item", tempItems);
        return tempNode.toString();
    }

    public WeatherAreaEntity findWeatherArea(EventEntity event) {
        String[] addrs = event.getOldAddress().split("\\s");
        String addr1 = null;
        String addr2 = null;
        String addr3 = null;
        logger.info("addrs length : {}", addrs.length);

        for(int i = 0; i < addrs.length; i++) {
            String temp = addrs[i];
            logger.info("temp : {}", temp);
            if( i == 0) {
                addr1 = temp ;

                if(addr1.indexOf("세종") != -1) {
                    addr2 = addr1;
                }
                continue;
            }

            if(addr1.lastIndexOf("시") != -1  && addr2 == null && (temp.lastIndexOf("구") != -1 || temp.lastIndexOf("군") != -1)){
                addr2 = temp;
            }

            if(addr1.lastIndexOf("도") != -1  && (addr2 == null || addr2.lastIndexOf("시") != -1) && (temp.lastIndexOf("시") != -1 || temp.lastIndexOf("구") != -1 || temp.lastIndexOf("군") != -1)){
                if(addr1.indexOf("세종") == -1) {
                    if(addr2 != null) {
                        addr2 = addr2 + temp;
                    } else {
                        addr2 = temp;
                    }
                } else {
                    if(addr3 != null) {
                        addr3 = addr2 + temp;
                    } else {
                        addr3 = temp;
                    }
                }
            }

            if(addr3 == null && (temp.lastIndexOf("읍") != -1 || temp.lastIndexOf("면") != -1|| temp.lastIndexOf("동") != -1)){
                addr3 = temp;
            }

            if(addr1 != null && addr2 != null && addr3 != null) {
                break;
            }

        }


        Optional<WeatherAreaEntity> wa;
        WeatherAreaEntity waData = null;
        if(waData == null) {
            wa = weatherAreaRepo.findByAddr1LikeAndAddr2LikeAndAddr3Like(addr1,addr2,addr3);
            if(wa.isPresent()) {
                waData = wa.get();
                logger.info("addr : {}, {}, {}", addr1,addr2,addr3);
                logger.info("waData : {}", waData);
            }
        }
        if(waData == null) {
            wa = weatherAreaRepo.findByAddr1AndAddr2AndAddr3IsNull(addr1,addr2);
            if(wa.isPresent()) {
                waData = wa.get();
                logger.info("addr : {}, {}", addr1,addr2);
                logger.info("waData : {}", waData);
            }
        }
        if(waData == null) {
            wa = weatherAreaRepo.findByAddr1AndAddr2IsNullAndAddr3IsNull(addr1);
            if(wa.isPresent()) {
                waData = wa.get();
                logger.info("addr : {}", addr1);
                logger.info("waData : {}", waData);
            }
        }
        return waData;
    }

    public WeatherEventEntity createWeatherEvent(EventEntity event) throws IOException {

        WeatherAreaEntity waData = findWeatherArea(event);

        Date currentTime = new Date();
        String date = DateToTime(currentTime);
        String time = DateToHour(currentTime);

        String weatherInfo = "";
        WeatherEventEntity we = new WeatherEventEntity();
        we.accountId = event.getAccountId();
        we.eventId = event.getEventId();
        we.weatherAreaId = waData.getId();
        we.coordinateY = waData.coordinateY;
        we.coordinateX = waData.coordinateX;
        we.lat = waData.lat;
        we.lng = waData.lng;
        we.apiRequestDate = new Date();
        we = weatherEventRepo.saveAndFlush(we);

        try{
            weatherInfo = this.getWeatherInfo(WeatherServiceType.SrtFcst, key, date, time , waData.coordinateX, waData.coordinateY);
            if(StringUtils.isNotBlank(weatherInfo)){
                List<WeatherEventDataEntity> dataList = this.getWeatherInfoParse(weatherInfo);
                WeatherEventEntity finalWe = we;
                dataList = dataList.stream().map(data -> {
                    data.coordinateY = finalWe.coordinateY;
                    data.coordinateX = finalWe.coordinateX;
                    data.lat = finalWe.lat;
                    data.lng = finalWe.lng;
                    data.baseTotalTime = date + time;
                    data.getWeatherEventDataId().setWeatherEventId(finalWe.getWeatherEventId());
                    return data;
                }).collect(Collectors.toList());
                weatherEventDataRepo.saveAll(dataList);
            }
            logger.debug("find weatherInfo [{}]", weatherInfo);
            we.weatherInfo = weatherInfo;
        } catch (Exception e){
            logger.error(e.getMessage());
        } finally {
            weatherEventRepo.save(we);
        }

        WeatherEventLogEntity wee = new WeatherEventLogEntity();
        wee.eventId = event.getEventId();
        wee.weatherEventId = we.getWeatherEventId();
        wee.weatherInfo = getJsonInfo(weatherInfo);
        wee.weatherAreaId = waData.getId();
        wee.coordinateX = we.coordinateX;
        wee.coordinateY = we.coordinateY;
        wee.lat = we.lat;
        wee.lng = we.lng;
        wee.baseTotalTime = date + time;
        wee.apiRequestDate = we.apiRequestDate;
        weatherEventLogRepo.save(wee);

        return we;
    }

    public WeatherEventEntity updateWeatherEventIsWeatherInfo(EventEntity event) {
        WeatherEventEntity we = weatherEventRepo.findByEventId(event.getAccountId(), event.getEventId())
                .orElseThrow(() -> new RuntimeException("not find updateWeather"));

        logger.debug("find WeatherEventEntity [{}]", we);

        Date currentTime = new Date();
        String date = DateToTime(currentTime);
        String time = DateToHour(currentTime);

        Long count = weatherEventDataRepo.countByWeatherEventDataId_WeatherEventIdAndBaseTotalTime(we.getWeatherEventId(),date + time);
        if(count > 0) {
            logger.debug("already event weather date, base total time[{}]", date + time);
            return null;
        }
        we.apiRequestDate = new Date();
        String weatherInfo = "";
        try{
            weatherInfo = this.getWeatherInfo(WeatherServiceType.SrtFcst, key, date, time, we.coordinateX, we.coordinateY);
            if(StringUtils.isNotBlank(weatherInfo)){
                List<WeatherEventDataEntity> dataList = this.getWeatherInfoParse(weatherInfo);
                WeatherEventEntity finalWe = we;
                dataList = dataList.stream().map(data -> {
                    data.coordinateY = finalWe.coordinateY;
                    data.coordinateX = finalWe.coordinateX;
                    data.lat = finalWe.lat;
                    data.lng = finalWe.lng;
                    data.baseTotalTime = date + time;
                    data.getWeatherEventDataId().setWeatherEventId(finalWe.getWeatherEventId());
                    return data;
                }).collect(Collectors.toList());
                weatherEventDataRepo.saveAll(dataList);
            }
            logger.debug("find weatherInfo [{}]", weatherInfo);
            we.weatherInfo = weatherInfo;
        } catch (Exception e){
            logger.error(e.getMessage());
        } finally {
            we = weatherEventRepo.saveAndFlush(we);
        }

        WeatherEventLogEntity wee = new WeatherEventLogEntity();
        wee.eventId = event.getEventId();
        wee.weatherEventId = we.getWeatherEventId();
        wee.weatherInfo = getJsonInfo(weatherInfo);
        wee.weatherAreaId = we.weatherAreaId;
        wee.coordinateX = we.coordinateX;
        wee.coordinateY = we.coordinateY;
        wee.lat = we.lat;
        wee.lng = we.lng;
        wee.baseTotalTime = date + time;
        wee.apiRequestDate = we.apiRequestDate;
        weatherEventLogRepo.save(wee);

        return we;
    }

    public enum WeatherServiceType {
        /**
         * 초단기실황조회
         */
        SrtNcst,
        /**
         * 초단기예보조회
         */
        SrtFcst,

        /**
         * 동네예보조회
         */
        VilageFcst,
        /**
         * 예보버전조회
         */
        FcstVersion

    }

    private String getServiceTypeToName(WeatherServiceType type){

        String result = "";
        switch (type) {
            case SrtNcst:
                result = "getUltraSrtNcst";
                break;
            case SrtFcst:
                result = "getUltraSrtFcst";
                break;
            case VilageFcst:
                result = "getVilageFcst";
                break;
            case FcstVersion:
                result = "getFcstVersion";
                break;
        }
        return result;
    }

    private String DateToTime(Date currentTime){
        Calendar today = Calendar.getInstance();
        today.setTime(currentTime);

        SimpleDateFormat timeHourFormat = new SimpleDateFormat("HH");
        String hour = timeHourFormat.format(currentTime);

        SimpleDateFormat timeMinutesFormat = new SimpleDateFormat("mm");
        String minutes = timeMinutesFormat.format(currentTime);
        if(Integer.parseInt(minutes) < 30) {
            Integer temp = Integer.parseInt(hour) - 1;
            if(temp < 0) {
                today.add(Calendar.DATE, -1);
            }
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String date = dateFormat.format(today.getTime());

        return date;
    }

    private String DateToHour(Date currentTime){
        SimpleDateFormat timeHourFormat = new SimpleDateFormat("HH");
        String hour = timeHourFormat.format(currentTime);

        SimpleDateFormat timeMinutesFormat = new SimpleDateFormat("mm");
        String minutes = timeMinutesFormat.format(currentTime);
        if(Integer.parseInt(minutes) < 30) {
            Integer temp = Integer.parseInt(hour) - 1;
            if(temp < 0) {
                temp = 23;
            }
            hour = StringUtils.leftPad("" + temp, 2, '0');
        }
        hour = hour + "30";
        return hour;
    }

    public String getWeatherInfo(WeatherServiceType type, String key, String baseDate, String baseTime, String x, String y) throws IOException {
        String serviceType = getServiceTypeToName(type);

        String sendKey = key;
        if(sendKey == null) {
            sendKey = "ITpd4AdG/fZgpZ6sR3zeovFvPK1yR6XXZJhIgrSX21SvXfjyLtRKql1tSItrHn+ZVn00NnwSOTV7Nn6wtx3Dsg==";
        }

        logger.info("date : {}, time : {}",baseDate, baseTime);
        StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/"+serviceType); /*URL*/
        urlBuilder.append("?" + URLEncoder.encode("ServiceKey","UTF-8") + "="+sendKey); /*Service Key*/
        urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*페이지번호*/
        urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("300", "UTF-8")); /*한 페이지 결과 수*/
        urlBuilder.append("&" + URLEncoder.encode("dataType","UTF-8") + "=" + URLEncoder.encode("JSON", "UTF-8")); /*요청자료형식(XML/JSON)Default: XML*/
        urlBuilder.append("&" + URLEncoder.encode("base_date","UTF-8") + "=" + URLEncoder.encode(baseDate, "UTF-8")); /*15년 12월 1일 발표*/
        urlBuilder.append("&" + URLEncoder.encode("base_time","UTF-8") + "=" + URLEncoder.encode(baseTime, "UTF-8")); /*06시 발표(정시단위)*/
        urlBuilder.append("&" + URLEncoder.encode("nx","UTF-8") + "=" + URLEncoder.encode(x, "UTF-8")); /*예보지점의 X 좌표값*/
        urlBuilder.append("&" + URLEncoder.encode("ny","UTF-8") + "=" + URLEncoder.encode(y, "UTF-8")); /*예보지점 Y 좌표*/
        URL url = new URL(urlBuilder.toString());
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(TIMEOUT_VALUE);
        conn.setReadTimeout(TIMEOUT_VALUE);
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Content-type", "application/json");

        logger.debug("Response error: {}",conn.getErrorStream());
        logger.debug("Response message: {}",conn.getResponseMessage());

        BufferedReader rd;
        if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } else {
            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = rd.readLine()) != null) {
            sb.append(line);
        }
        rd.close();
        conn.disconnect();

        return sb.toString();
    }

    public List<WeatherEventDataEntity> getWeatherInfoParse(String info){
        JsonParser parse = new JsonParser();
        JsonObject root = parse.parse(info).getAsJsonObject();
        JsonObject response = root.getAsJsonObject("response");
        JsonObject body = response.getAsJsonObject("body");
        JsonObject items = body.getAsJsonObject("items");

        JsonArray item = items.getAsJsonArray("item");

        List<WeatherEventDataEntity> list = new ArrayList();
        for(int i =0; i < item.size(); i++) {

            JsonObject obj = item.get(i).getAsJsonObject();
            String baseDate = obj.get("baseDate").getAsString();
            String baseTime = obj.get("baseTime").getAsString();
            String category = obj.get("category").getAsString();
            String fcstDate = obj.get("fcstDate").getAsString();
            String fcstTime = obj.get("fcstTime").getAsString();
            String fcstValue = obj.get("fcstValue").getAsString();

            WeatherEventDataEntity entity = null;
            var filterList = list.stream().filter(value -> value.getWeatherEventDataId().getFcstDateTime().equals(fcstDate + fcstTime)).collect(Collectors.toList());
            if(filterList.size() == 0) {
                entity = new WeatherEventDataEntity();
                entity.getWeatherEventDataId().setFcstDateTime(fcstDate + fcstTime);
                list.add(entity);
            } else {
                entity = filterList.stream().findFirst().get();
            }

            switch (category){
                case "T1H":
                    entity.temperatures = fcstValue + " ℃";
                    break;
                case "RN1":
                    entity.rain = fcstValue;
                    if(!entity.rain.equals("강수없음") && entity.rain.indexOf("mm") == -1 ) {
                        entity.rain = entity.rain + " mm";
                    }
                    break;
                case "SKY":
                    entity.skyCode = fcstValue;
                    entity.skyName = getSKYCodeName(fcstValue);
                    break;
                case "UUU":
                    entity.eastWestValue = fcstValue + " m/s";
                    break;
                case "VVV":
                    entity.southNorthValue = fcstValue + " m/s";
                    break;
                case "REH":
                    entity.humidity = fcstValue + " %";
                    break;
                case "PTY":
                    entity.rainCode = fcstValue;
                    entity.rainName = getRainCodeName(fcstValue);
                    break;
                case "LGT":
                    entity.thunderstroke = fcstValue;
                    break;
                case "VEC":
                    entity.windDirection = fcstValue + " deg";
                    break;
                case "WSD":
                    entity.windSpeed = fcstValue + " m/s";
                    break;
            }
        }
        return list;
    }

    private String getSKYCodeName(String code){
        String result = "";
        switch(code){
            case "1":
                result = "맑음";
                break;
            case "3":
                result = "구름많음";
                break;
            case "4" :
                result = "흐림";
                break;
        }
        return result;
    }

    private String getRainCodeName(String code){

        String result = "";
        switch(code){
            case "0":
                result = "없음";
                break;
            case "1":
                result = "비";
                break;
            case "2" :
                result = "비/눈";
                break;
            case "3" :
                result = "눈";
                break;
            case "4" :
                result = "소나기";
                break;
            case "5" :
                result = "빗방울";
                break;
            case "6" :
                result = "빗방울/눈날림";
                break;
            case "7" :
                result = "눈날림";
                break;

        }
        return result;
    }
}

