package com.teixon.cms.mediahub.weather.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

/**
 * area create to weather information entity
 *
 * @author matin
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "weather_area_tbl")
public class WeatherAreaEntity {

    /**
     * weather id
     */
    @Id
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Column(name = "id", nullable = false, updatable = false, length = ColumnLength.VALUE)
    private String id;

    /**
     * addr1 (시)
     */
    @Column(name = "addr1", nullable = false, length = ColumnLength.VALUE)
    public String addr1;

    /**
     * addr2(구)
     */
    @Column(name = "addr2",  length = ColumnLength.VALUE)
    public String addr2;

    /**
     * addr3(동)
     */
    @Column(name = "addr3", length = ColumnLength.VALUE)
    public String addr3;


    /**
     *  api 사용할 좌표 x 값
     */
    @Column(name = "coordinate_x",nullable = false, length = 10)
    public String coordinateX;

    /**
     *  api 사용할 좌표 y 값
     */
    @Column(name = "coordinate_y", nullable = false,length = 10)
    public String coordinateY;



    /**
     *  Latitude 위도 시
     */
    @Column(name = "lat_h", nullable = false,length = ColumnLength.VALUE)
    public String latH;

    /**
     *  Latitude 위도 분
     */
    @Column(name = "lat_m", nullable = false,length = ColumnLength.VALUE)
    public String latM;

    /**
     *  Latitude 위도 초
     */
    @Column(name = "lat_s", nullable = false,length = ColumnLength.VALUE)
    public String latS;

    /**
     *  longitude 경도 시
     */
    @Column(name = "lng_h", nullable = false,length = ColumnLength.VALUE)
    public String lngH;

    /**
     *  longitude 경도 분
     */
    @Column(name = "lng_m", nullable = false,length = ColumnLength.VALUE)
    public String lngM;

    /**
     *  longitude 경도 초
     */
    @Column(name = "lng_s", nullable = false,length = ColumnLength.VALUE)
    public String lngS;


    /**
     *  Latitude 위도
     */
    @Column(name = "lat", nullable = false,length = ColumnLength.VALUE)
    public String lat;

    /**
     *  longitude 경도
     */
    @Column(name = "lng", nullable = false, length = ColumnLength.VALUE)
    public String lng;


    public WeatherAreaEntity(){

    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public String getId() {
        return id;
    }
}
