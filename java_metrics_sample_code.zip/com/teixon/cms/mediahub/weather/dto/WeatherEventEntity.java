package com.teixon.cms.mediahub.weather.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

/**
 * area create to weather information entity
 *
 * @author matin
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "weather_event_tbl")
public class WeatherEventEntity {


    /**
     * account id
     */
    @Column(name = "acct_id", nullable = false, updatable = false, length = ColumnLength.UUID)
    public String accountId;

    /**
     * weather id
     */
    @Id
    @Column(name = "weather_event_id", updatable = false, nullable = false, length = ColumnLength.UUID)
    @GenericGenerator(name = "weather_event_id_uuid", strategy = "com.teixon.cms.mediahub.common.jpa.id.UUIDGenerator")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "weather_event_id_uuid")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String weatherEventId;

    /**
     * area id
     */
    @Column(name = "event_id", nullable = false,updatable = false, length = ColumnLength.UUID)
    public String eventId;

    /**
     * weather info is json data
     */
    @Column(name = "weather_area_id", nullable = false, length = ColumnLength.UUID)
    public String weatherAreaId;

    /**
     * weather info is json data
     */
    @Column(name = "weather_info", nullable = true, length = 20000)
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    public String weatherInfo;


    /**
     *  api 사용할 좌표 x 값
     */
    @Column(name = "coordinate_x", nullable = true, length = 10)
    public String coordinateX;

    /**
     *  api 사용할 좌표 y 값
     */
    @Column(name = "coordinate_y", nullable = true, length = 10)
    public String coordinateY;

    /**
     *  Latitude 위도
     */
    @Column(name = "lat", nullable = false, length = ColumnLength.VALUE)
    public String lat;

    /**
     *  longitude 경도
     */
    @Column(name = "lng", nullable = false, length = ColumnLength.VALUE)
    public String lng;

    /**
     * registration date
     */
    @CreatedDate
    @Column(name = "reg_dt", nullable = false, updatable = false)
    private Date registerDate;

    /**
     * registration date
     */
    @LastModifiedDate
    @Column(name = "mod_dt", updatable = false)
    private Date modifyDate;

    /**
     * weather api request date
     */
    @Column(name = "api_req_dt", nullable = true)
    public Date apiRequestDate;

//    @OneToMany
//    @JoinColumn(name = "weather_event_id", insertable = false, updatable = false,foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    @Transient
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    public List<WeatherEventDataEntity> WeatherEventDataList;

    public WeatherEventEntity(){

    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public String getWeatherEventId() {
        return weatherEventId;
    }

    public Date getRegisterDate() {
        return registerDate;
    }
}
