package com.teixon.cms.mediahub.weather.dto;


import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.ToStringBuilder;
import javax.persistence.*;
import java.io.Serializable;


/**
 * area create to weather information entity
 *
 * @author lastkwy
 */
@Embeddable
public class WeatherEventDataId implements Serializable {


    private static final long serialVersionUID = -3233379424529682964L;
    /**
     * weather id
     */
    @Column(name = "weather_event_id", updatable = false, nullable = false, length = ColumnLength.UUID)
    private String weatherEventId;

    /**
     * area id
     */
    @Column(name = "fcst_date_time", updatable = false, nullable = false, length = 20)
    private String fcstDateTime;

    public WeatherEventDataId(){

    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public String getWeatherEventId() {
        return weatherEventId;
    }

    public String getFcstDateTime() {
        return fcstDateTime;
    }

    public WeatherEventDataId setWeatherEventId(String weatherEventId) {
        this.weatherEventId = weatherEventId;
        return this;
    }

    public WeatherEventDataId setFcstDateTime(String fcstDateTime) {
        this.fcstDateTime = fcstDateTime;
        return this;
    }
}
