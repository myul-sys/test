package com.teixon.cms.mediahub.weather.dto;

import com.teixon.cms.mediahub.common.data.BaseCondition;
import com.teixon.cms.mediahub.common.utils.DateRange;
import com.teixon.cms.mediahub.common.utils.Range;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Date;


/**
 * conditions for searching for device
 **/
public class WeatherEventLogFindCondition extends BaseCondition {
    /**
     * account id
     */
    public String accountId;

    /**
     * device id
     */
    public String deviceId;

    /**
     * device search keyword
     */
    public String keyword;


    /** 시작일 끝일 */
    public DateRange dateRange;

    public WeatherEventLogFindCondition() {
        super(0, Integer.MAX_VALUE);
        dateRange = new DateRange(null,null);
    }


    @Override
    public String toString() {

        return ToStringBuilder.reflectionToString(this);
    }

    public DateRange getDateRange() {
        return dateRange;
    }

    public void setDateRange(DateRange dateRange) {
        this.dateRange = dateRange;
    }
}
