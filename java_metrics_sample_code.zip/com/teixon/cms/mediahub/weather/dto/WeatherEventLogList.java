package com.teixon.cms.mediahub.weather.dto;

import com.teixon.cms.mediahub.common.data.EntityList;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

public class WeatherEventLogList extends EntityList<WeatherEventLogEntity> {

    /**
     * @param weatherEventLogList
     * 		entity list
     * @param total
     * 		total count
     * @param firstResult
     * 		index of first item
     * @param pageSize
     * 		page size
     */
    public WeatherEventLogList(
            final List<WeatherEventLogEntity> weatherEventLogList, final Long total, final Long firstResult,
            final Integer pageSize) {

        super(weatherEventLogList, total, firstResult, pageSize);
    }

    @Override
    public String toString() {

        return ToStringBuilder.reflectionToString(this);
    }
}
