package com.teixon.cms.mediahub.weather.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.ToStringBuilder;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

/**
 * area create to weather information entity
 *
 * @author matin
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "weather_event_data_tbl")
public class WeatherEventDataEntity {


    /**
     * weather id
     */
    @EmbeddedId
    private WeatherEventDataId weatherEventDataId;
    /**
     * API 요청 기본 시간
     */
    @Column(name = "base_total_time", length = ColumnLength.CODE)
    public String baseTotalTime;

    /**
     * weather info is 하늘 상태 코드
     */
    @Column(name = "sky_code", length = ColumnLength.CODE)
    public String skyCode;

    /**
     * weather info is 하늘 상태 이름
     */
    @Column(name = "sky_name", length = ColumnLength.CODE)
    public String skyName;

    /**
     * weather info is 온도 C
     */
    @Column(name = "temperatures", length = ColumnLength.CODE)
    public String temperatures;

    /**
     * weather info is 강수량 mm
     */
    @Column(name = "rain", length = ColumnLength.CODE)
    public String rain;

    /**
     * weather info is 강수량 코드
     */
    @Column(name = "rain_code", length = ColumnLength.CODE)
    public String rainCode;

    /**
     * weather info is 강수량 이름
     */
    @Column(name = "rain_name", length = ColumnLength.CODE)
    public String rainName;

    /**
     * weather info is 풍속(+ : 동, - : 서) m/s
     */
    @Column(name = "east_west_value", length = ColumnLength.CODE)
    public String eastWestValue;

    /**
     * weather info is 풍속(+ : 남 , - : 북) m/s
     */
    @Column(name = "south_north_value", length = ColumnLength.CODE)
    public String southNorthValue;

    /**
     * weather info is 습도 %
     */
    @Column(name = "humidity", length = ColumnLength.CODE)
    public String humidity;


    /**
     * weather info is 낙뢰
     */
    @Column(name = "thunderstroke", length = ColumnLength.CODE)
    public String thunderstroke;


    /**
     * weather info is 풍속 m/s
     */
    @Column(name = "wind_speed", length = ColumnLength.CODE)
    public String windSpeed;

    /**
     * weather info is 풍향 meg
     */
    @Column(name = "wind_direction", length = ColumnLength.CODE)
    public String windDirection;


    /**
     *  api 사용할 좌표 x 값
     */
    @Column(name = "coordinate_x",nullable = false, length = 10)
    public String coordinateX;

    /**
     *  api 사용할 좌표 y 값
     */
    @Column(name = "coordinate_y", nullable = false,length = 10)
    public String coordinateY;

    /**
     *  Latitude 위도
     */
    @Column(name = "lat", nullable = false,length = ColumnLength.VALUE)
    public String lat;

    /**
     *  longitude 경도
     */
    @Column(name = "lng", nullable = false, length = ColumnLength.VALUE)
    public String lng;

    /**
     * registration date
     */
    @CreatedDate
    @Column(name = "reg_dt", nullable = false, updatable = false)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Date registerDate;

    public WeatherEventDataEntity(){
        this.weatherEventDataId = new WeatherEventDataId();
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public WeatherEventDataId getWeatherEventDataId() {
        return weatherEventDataId;
    }

    public Date getRegisterDate() {
        return registerDate;
    }
}
