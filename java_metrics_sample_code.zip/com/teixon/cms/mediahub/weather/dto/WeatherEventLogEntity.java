package com.teixon.cms.mediahub.weather.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

/**
 * area create to weather information entity
 *
 * @author matin
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "weather_event_log_tbl")
public class WeatherEventLogEntity {


    /**
     * weather id
     */
    @Id
    @Column(name = "weather_log_id", updatable = false, nullable = false, length = ColumnLength.UUID)
    @GenericGenerator(name = "weather_log_id_uuid", strategy = "com.teixon.cms.mediahub.common.jpa.id.UUIDGenerator")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "weather_log_id_uuid")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String weatherLogId;

    /**
     * weather id
     */
    @Column(name = "event_id", updatable = false, length = ColumnLength.UUID)
    public String eventId;

    /**
     * weather id
     */
    @Column(name = "weather_area_id", nullable = false, updatable = false, length = ColumnLength.UUID)
    public String weatherAreaId;

    /**
     * weather id
     */
    @Column(name = "weather_event_Id", nullable = false, updatable = false, length = ColumnLength.UUID)
    public String weatherEventId;

    /**
     * weather id
     */
    @Column(name = "weather_info", nullable = false, updatable = false, length = 20000)
    public String weatherInfo;

    /**
     * area id
     */
    @Column(name = "base_total_time", length = 20)
    public String baseTotalTime;

    /**
     * weather api request date
     */
    @Column(name = "api_req_dt", nullable = true)
    public Date apiRequestDate;

    /**
     *  api 사용할 좌표 x 값
     */
    @Column(name = "coordinate_x",nullable = false, length = 10)
    public String coordinateX;

    /**
     *  api 사용할 좌표 y 값
     */
    @Column(name = "coordinate_y", nullable = false,length = 10)
    public String coordinateY;

    /**
     *  Latitude 위도
     */
    @Column(name = "lat", nullable = false,length = ColumnLength.VALUE)
    public String lat;

    /**
     *  longitude 경도
     */
    @Column(name = "lng", nullable = false, length = ColumnLength.VALUE)
    public String lng;

    /**
     * registration date
     */
    @CreatedDate
    @Column(name = "reg_dt", nullable = false, updatable = false)
    public Date registerDate;


    public WeatherEventLogEntity(){

    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
