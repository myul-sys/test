package com.teixon.cms.mediahub.weather.repository;


import com.teixon.cms.mediahub.weather.dto.WeatherAreaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface WeatherAreaRepository extends JpaRepository<WeatherAreaEntity, String> {

    /**
     * get a weather area info(addr1)
     *
     * @param addr1
     * 		addr1(광역시)
     *
     * @return weather event detail {@link WeatherAreaEntity}
     */
    Optional<WeatherAreaEntity> findByAddr1AndAddr2IsNullAndAddr3IsNull(
            String addr1);

    /**
     * get a weather area info(addr1,addr2)
     *
     * @param addr1
     * 		addr1(광역시)
     * @param addr2
     * 		addr2(구)
     *
     * @return weather event detail {@link WeatherAreaEntity}
     */
    Optional<WeatherAreaEntity> findByAddr1AndAddr2AndAddr3IsNull(
            @Param("addr1") String addr1,
            @Param("addr2") String addr2);

    /**
     * get a weather area info(addr1,addr2,addr3)
     *
     * @param addr1
     * 		addr1(광역시)
     * @param addr2
     * 		addr2(구)
     * @param addr3
     *      addr3(동,음)
     *
     * @return weather event detail {@link WeatherAreaEntity}
     */
    Optional<WeatherAreaEntity> findByAddr1LikeAndAddr2LikeAndAddr3Like(
            @Param("addr1") String addr1,
            @Param("addr2") String addr2,
            @Param("addr3") String addr3);
}
