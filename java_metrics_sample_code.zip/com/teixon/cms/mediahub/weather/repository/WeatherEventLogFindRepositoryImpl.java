package com.teixon.cms.mediahub.weather.repository;

import com.teixon.cms.mediahub.weather.dto.WeatherEventLogEntity;
import com.teixon.cms.mediahub.weather.dto.WeatherEventLogFindCondition;
import com.teixon.cms.mediahub.weather.dto.WeatherEventLogList;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.*;

/**
 * search for weather event log list repository
 */
@Repository(value = "WeatherEventLogRepository")
public class WeatherEventLogFindRepositoryImpl implements WeatherEventLogFindRepository {

    /** entity manager */
    @Autowired
    private EntityManager em;

    /** log handle */
    private Logger logger = LoggerFactory.getLogger(WeatherEventLogFindRepositoryImpl.class);

    @Override
    public WeatherEventLogList findList(WeatherEventLogFindCondition condition) {

        logger.debug("findList [condition = {}]", condition);

        final CriteriaBuilder cb = em.getCriteriaBuilder();
        final CriteriaQuery<WeatherEventLogEntity> cqSelect = cb.createQuery(WeatherEventLogEntity.class);
        final Root<WeatherEventLogEntity> selectRoot = cqSelect.from(WeatherEventLogEntity.class);

        cqSelect.select(selectRoot);
        cqSelect.where(getPredicates(selectRoot, condition));
        cqSelect.orderBy(cb.desc(selectRoot.get("registerDate")));

        final TypedQuery<WeatherEventLogEntity> querySelect = this.em.createQuery(cqSelect);
        querySelect.setFirstResult((int) condition.getOffset());
        querySelect.setMaxResults(condition.getPageSize());

        final List<WeatherEventLogEntity> list = querySelect.getResultList();
        final Long totalCount = countList(condition);

        return new WeatherEventLogList(list, totalCount, condition.getOffset(), condition.getPageSize());
    }

    @Override
    public Long countList(WeatherEventLogFindCondition condition) {

        logger.debug("countList [condition = {}]", condition);

        final CriteriaBuilder cb = this.em.getCriteriaBuilder();
        final CriteriaQuery<Long> cqCount = cb.createQuery(Long.class);
        final Root<WeatherEventLogEntity> countRoot = cqCount.from(WeatherEventLogEntity.class);

        // count query
        cqCount.select(cb.count(countRoot));
        cqCount.where(getPredicates(countRoot, condition));

        return this.em.createQuery(cqCount).getSingleResult();
    }


    private Predicate[] getPredicates(
            Root<WeatherEventLogEntity> root,
            WeatherEventLogFindCondition condition) {

        final CriteriaBuilder cb = this.em.getCriteriaBuilder();
        final List<Predicate> predicates = new ArrayList<>();

        predicates.add(cb.and(cb.equal(root.get("accountId"), condition.accountId)));

        Optional.of(condition.dateRange)
                .filter(range -> !range.isEmpty())
                .ifPresent(range -> {
                    Date to = range.getTo();
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(to);

                    cal.add(Calendar.DATE, 1);
                    cal.add(Calendar.MILLISECOND, -1);

                    final Predicate p = cb.between(root.get("registerDate"), range.getFrom() , cal.getTime());
                    predicates.add(p);
                });

        // keyword
        Optional.ofNullable(condition.keyword)
                .filter(StringUtils::isNotBlank)
                .ifPresent(keyword -> {
                    final Predicate p = cb.and( //
                            cb.or(
                                    cb.like(root.get("title"), String.format("%%%s%%", keyword)), //
                                    cb.like(root.get("title"), String.format("%%%s%%", keyword))
                            )
                    );
                    predicates.add(p);
                });


        return predicates.toArray(new Predicate[]{});
    }

}
