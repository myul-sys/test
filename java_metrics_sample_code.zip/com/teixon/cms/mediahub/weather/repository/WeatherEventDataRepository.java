package com.teixon.cms.mediahub.weather.repository;


import com.teixon.cms.mediahub.weather.dto.WeatherEventDataEntity;
import com.teixon.cms.mediahub.weather.dto.WeatherEventDataId;
import com.teixon.cms.mediahub.weather.dto.WeatherEventEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface WeatherEventDataRepository extends JpaRepository<WeatherEventDataEntity, WeatherEventDataId> {
    /**
     * get a weather event detail
     *
     *
     * @return weather event detail {@link WeatherEventEntity}
     */
    Optional<List<WeatherEventDataEntity>> findByWeatherEventDataId_WeatherEventIdAndWeatherEventDataId_FcstDateTimeGreaterThanEqual(String WeatherEventId, String fcstDateTime);

    /**
     * get a count
     *
     *
     * @return count WeatherEventId and baseTotalTime
     */
    Long countByWeatherEventDataId_WeatherEventIdAndBaseTotalTime(String WeatherEventId, String baseTotalTime);
}
