package com.teixon.cms.mediahub.weather.repository;


import com.teixon.cms.mediahub.weather.dto.WeatherEventEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface WeatherEventRepository extends JpaRepository<WeatherEventEntity, String> {

    /**
     * get a weather event detail
     *
     * @param accountId
     * 		account id
     * @param eventId
     * 		event id
     *
     * @return weather event detail {@link WeatherEventEntity}
     */
    @Query(value = //
            "SELECT we FROM WeatherEventEntity we WHERE we.accountId = :accountId AND we.eventId = :eventId ")
    Optional<WeatherEventEntity> findByEventId(
            @Param("accountId") String accountId,
            @Param("eventId") String eventId);

    /**
     * get a weather event detail
     *
     * @param accountId
     * 		account id
     * @param eventId
     * 		event id
     *
     * @return weather event detail {@link WeatherEventEntity}
     */
    @Query(value = //
            "SELECT we FROM WeatherEventEntity we WHERE we.accountId = :accountId AND we.eventId in(:eventIds) ")
    Optional<List<WeatherEventEntity>> findByEventIds(
            @Param("accountId") String accountId,
            @Param("eventIds") List<String> eventIds);
}
