package com.teixon.cms.mediahub.weather.repository;


import com.teixon.cms.mediahub.weather.dto.WeatherEventLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface WeatherEventLogRepository extends JpaRepository<WeatherEventLogEntity, String> {

}
