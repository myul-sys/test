package com.teixon.cms.mediahub.weather.repository;


import com.teixon.cms.mediahub.weather.dto.WeatherEventLogFindCondition;
import com.teixon.cms.mediahub.weather.dto.WeatherEventLogList;


public interface WeatherEventLogFindRepository {

    /**
     * search for weather event log list
     *
     * @param condition
     * 		search for conditions
     *
     * @return search for weather event log list
     */
    WeatherEventLogList findList(final WeatherEventLogFindCondition condition);

    /**
     * count for conditions
     *
     * @param condition
     * 		search for conditions
     *
     * @return search for weather event log count
     */
    Long countList(WeatherEventLogFindCondition condition);

}
