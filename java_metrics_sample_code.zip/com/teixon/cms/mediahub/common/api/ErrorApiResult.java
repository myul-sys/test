package com.teixon.cms.mediahub.common.api;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.exception.ExceptionUtils;

/**
 * restful 작업중 오류 정보를 담는다
 *
 * @author matin
 **/
public class ErrorApiResult {

	/**
	 * @param message
	 * 		message
	 */
	public ErrorApiResult(final String message) {

		this(null, message, null);
	}

	/**
	 * @param uri
	 * 		request url
	 * @param message
	 * 		message
	 */
	public ErrorApiResult(final String uri, final String message) {

		this(uri, message, null);
	}

	/**
	 * @param uri
	 * 		request url
	 * @param message
	 * 		message
	 * @param stacktrace
	 * 		exception stacktrace
	 */
	public ErrorApiResult(final String uri, final String message, final String stacktrace) {

		this.uri = uri;
		this.message = message;
		this.stacktrace = stacktrace;
	}

	/**
	 * @param uri
	 * 		request url
	 * @param message
	 * 		message
	 */
	public ErrorApiResult(final String uri, final String message, final String stacktrace, final Integer result) {
		this(uri, message, null);
		this.result = result;
	}

	/**
	 * requset url
	 */
	private String uri;

	/**
	 * error message
	 */
	private String message;

	/**
	 * statctrace
	 */
	private String stacktrace;

	/**
	 * statctrace
	 */
	private Integer result;

	/**
	 * @param th
	 * 		exception error
	 */
	public void setException(final Throwable th) {

		this.message = th.getMessage();
		this.stacktrace = ExceptionUtils.getStackTrace(th);
	}

	/**
	 * @return the uri
	 */
	public String getUri() {

		return uri;
	}

	/**
	 * @param uri
	 * 		the uri to set
	 */
	public void setUri(final String uri) {

		this.uri = uri;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {

		return message;
	}

	/**
	 * @param message
	 * 		the message to set
	 */
	public void setMessage(final String message) {

		this.message = message;
	}

	/**
	 * @return the stacktrace
	 */
	public String getStacktrace() {

		return stacktrace;
	}

	/**
	 * @param stacktrace
	 * 		the stacktrace to set
	 */
	public void setStacktrace(final String stacktrace) {

		this.stacktrace = stacktrace;
	}

	/**
	 * @return the result
	 */
	public Integer getResult() {
		return result;
	}

	/**
	 * @param result
	 * 		the result to set
	 */
	public void setResult(Integer result) {
		this.result = result;
	}

	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}

}
