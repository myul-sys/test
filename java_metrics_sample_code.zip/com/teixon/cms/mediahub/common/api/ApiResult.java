package com.teixon.cms.mediahub.common.api;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.logging.log4j.util.Strings;

/**
 * api request 시 반환될 정보
 *
 * @param <T>
 * 		type of the data
 *
 * @author matin
 */
public class ApiResult<T> {

	/**
	 * 결과 코드
	 */
	private int result;

	/**
	 * 메시지
	 */
	private String message;

	/**
	 * 결과 데이터
	 */
	private T data;

	/**
	 *
	 */
	public ApiResult() {

		this(0, "Success", null);
	}

	/**
	 * @param result
	 * 		결과 코드
	 * @param data
	 * 		결과 데이터
	 */
	public ApiResult(final int result, final T data) {

		this(result, "", data);
	}

	/**
	 * @param result
	 * 		결과 코드
	 * @param message
	 * 		메시지
	 * @param data
	 * 		데이터
	 */
	public ApiResult(final int result, final String message, final T data) {

		this.result = result;
		this.message = message;
		this.data = data;
	}

	/**
	 * @param data
	 * 		결과 데이터
	 */
	public ApiResult(final T data) {

		this(0, data);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @return 결과 코드
	 */
	public int getResult() {

		return result;
	}

	/**
	 * @param result
	 * 		결과 코드
	 */
	public void setResult(final int result) {

		this.result = result;
	}

	/**
	 * @return 처리 결과
	 */
	public T getData() {

		return data;
	}

	/**
	 * @param data
	 * 		결과 데이터
	 */
	public void setData(final T data) {

		this.data = data;
	}

	/**
	 * @return 메시지
	 */
	public String getMessage() {

		return message;
	}

	/**
	 * @param message
	 * 		메시지
	 */
	public void setMessage(final String message) {

		this.message = message;
	}

	/**
	 * 성공한 결과를 반환 한다.
	 *
	 * @param data
	 * 		결과 데이터
	 * @param <T>
	 * 		the type of the value
	 *
	 * @return 성공으로 설정된 CMSResult 객체
	 */
	public static <T> ApiResult<T> ofSuccess(final T data) {

		return ApiResult.of(0, data);
	}


	/**
	 * @param result
	 * 		result code
	 * @param message
	 * 		message
	 * @param <T>
	 * 		return data type
	 *
	 * @return result object
	 */
	public static <T> ApiResult<T> of(final int result, final String message) {
		return ApiResult.of(result, message, null);
	}

	/**
	 * @param result
	 * 		결과 코드
	 * @param data
	 * 		return data
	 * @param <T>
	 * 		data type
	 *
	 * @return result object
	 */
	public static <T> ApiResult<T> of(final int result, final T data) {

		return ApiResult.of(result, Strings.EMPTY, data);
	}

	/**
	 * @param result
	 * 		결과 코드
	 * @param message
	 * 		return message
	 * @param data
	 * 		return data
	 * @param <T>
	 * 		return data type
	 *
	 * @return result object
	 */
	public static <T> ApiResult<T> of(final int result, final String message, final T data) {

		return new ApiResult<T>(result, message, data);
	}

}
