package com.teixon.cms.mediahub.common.utils;


import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * 구간을 가지는 객체
 *
 * @param <T>
 */
public class Range<T extends Comparable<T>> {

	/** 시작값 */
	public T from;

	/** 종료값 */
	public T to;

	public Range() {

		this.from = null;
		this.to = null;
	}

	public Range(final T from, final T to) {

		this.from = from;
		this.to = to;
	}


	/**
	 * value1 '>' value2 를 검사 한다
	 *
	 * @param value1
	 * @param value2
	 *
	 * @return
	 */
	public boolean isBigger(final T value1, final T value2) {

		return value1.compareTo(value2) > 0;
	}

	/**
	 * value1 '<' value2 를 검사 한다
	 *
	 * @param value1
	 * @param value2
	 *
	 * @return
	 */
	public boolean isSmaller(final T value1, final T value2) {

		return value1.compareTo(value2) < 0;
	}

	public boolean isSame(final T value1, final T value2) {

		return value1.compareTo(value2) == 0;
	}


	/**
	 * from ~ to 사이 값인지 확인 한다
	 *
	 * @param value
	 *
	 * @return
	 */
	public boolean contains(final T value) {

		return (isBigger(from, value) || isSame(from, value))
				&& (isSmaller(to, value) || isSame(to, value));
	}


	public boolean isEmpty() {

		return this.from == null || this.to == null;
	}


	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}


	public T getFrom() {

		return from;
	}

	public Range<T> setFrom(final T from) {

		this.from = from;
		return this;
	}

	public T getTo() {

		return to;
	}

	public Range<T> setTo(final T to) {

		this.to = to;
		return this;
	}

}
