package com.teixon.cms.mediahub.common.utils;


import org.apache.poi.ss.formula.functions.T;
import org.springframework.util.MultiValueMap;

import java.util.Map;

/**
 * convert string format from value
 */
public class StringFormatter {


    /**
     * @param format
     * 		format string
     * @param parameters
     * 		parameters
     *
     * @return convert string
     */
    public static String fromValues(final String format, final MultiValueMap<String, String> parameters) {
        final StringBuilder buf = new StringBuilder(format);
        parameters.forEach((key,value) -> {
            final String findKey = String.format("{%s}", key);
            do {
                final int start = buf.indexOf(findKey);
                if (start < 0) {
                    break;
                }
                buf.replace(start,start + findKey.length(), value.toString());
            } while (true);
        });
        return buf.toString();
    }



    /**
     * @param format
     * 		format string
     * @param parameters
     * 		parameters
     *
     * @return convert string
     */
    public static String fromValues(final String format, final Map<String, String> parameters) {
        final StringBuilder buf = new StringBuilder(format);
        parameters.forEach((key,value) -> {
            final String findKey = String.format("{%s}", key);
            do {
                final int start = buf.indexOf(findKey);
                if (start < 0) {
                    break;
                }
                buf.replace(start,start + findKey.length(), value.toString());
            } while (true);
        });
        return buf.toString();
    }

    /**
     * @param parameters
     * 		parameters
     *
     * @return convert string
     */
    public static String fromParameter(final Map<String, String> parameters) {
        String result = "";
        int startCheck = 0;

        for ( String key : parameters.keySet() ) {

            System.out.println(key);
            if (startCheck == 0) {
                result = result + "?";
            } else {
                result = result + "&";
            }
            result = result + key + "=" + parameters.get(key);

            startCheck++;
        }
        return result;
    }
}
