package com.teixon.cms.mediahub.common.utils;

/**
 * os type checker
 */
public class OSChecker {

	/**
	 * os windows
	 */
	public static final String WINDOWS = "windows";

	/**
	 * os unix (or linux)
	 */
	public static final String UNIX = "unix";

	/**
	 * os mac os x
	 */
	public static final String MAC = "mac";

	/**
	 * @return get os name
	 */
	public static String getOSName() {

		return System.getProperty("os.name");
	}

	/**
	 * @param osName
	 * 		os name
	 *
	 * @return get os type
	 */
	public static String getOSType(final String osName) {

		if (osName.indexOf("mac") > 0) {
			return MAC;
		} else if (osName.indexOf("win") > 0) {
			return WINDOWS;
		} else if (osName.indexOf("nix") > 0 || osName.indexOf("nux") > 0) {
			return UNIX;
		} else {
			return null;
		}
	}

	/**
	 * @return get os type
	 */
	public static String getOSType() {

		return getOSType(getOSName());
	}

}
