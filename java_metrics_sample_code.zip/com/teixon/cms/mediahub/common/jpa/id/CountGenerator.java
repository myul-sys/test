package com.teixon.cms.mediahub.common.jpa.id;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.Configurable;
import org.hibernate.id.IdentifierGenerator;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.type.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.Properties;

/**
 * id count 생성기
 *
 * @author matin
 */
public class CountGenerator implements IdentifierGenerator, Configurable {

    /**
     * jpa 상 entity 이름
     */
    private String jpaEntityName;

    /**
     * logger
     */
    private final Logger logger = LoggerFactory.getLogger(CountGenerator.class);

    @Override
    public void configure(final Type type, final Properties params, final ServiceRegistry serviceRegistry) throws MappingException {

        // entityName = params.getProperty(ENTITY_NAME);
        jpaEntityName = params.getProperty(JPA_ENTITY_NAME);
    }

    @Override
    public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {
        // 이 Connection 은 Hibernate 가 관리하기 때문에 직접 close는 하지 말것.
        SimpleDateFormat sDate = new SimpleDateFormat("yyMMdd");
        final String formatString = sDate.format(new Date());

        Connection connection = session.connection();
        final String prefix = getPrefix(jpaEntityName);
        final String query = getCountQuery(jpaEntityName, formatString);

        logger.info("JPA_ENTITY_NAME : {}, {} ", prefix, query);
        try {
            if (query != StringUtils.EMPTY) {
                PreparedStatement ps = connection.prepareStatement(query);

                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    int id = rs.getInt("id") + 1;
                    int size = 5;
                    String code = prefix + formatString + StringUtils.leftPad("" + id, size, '0');

                    if (jpaEntityName.equals("EventEntity")) {
                        size = 3;
                        code = prefix + formatString + StringUtils.leftPad("" + id, size, '0');

                    } else if (jpaEntityName.equals("DepartmentEntity")) {
                        size = 3;
                        code = prefix + StringUtils.leftPad("" + id, size, '0');
                    }


                    logger.debug("Generated new IdentifierGenerator to [Entity = {}] => {}", jpaEntityName, code);
                    return code;
                }
            }

        } catch (SQLException e) {
            logger.error(e.getMessage());
            throw new HibernateException(
                    "Unable to generate Stock Code Sequence");
        }

        return null;
    }

    /**
     * @param jpaEntityName jpa EntityName
     * @return UUID prefixed from entity name
     */
    protected static String getCountQuery(final String jpaEntityName, final String simpleDateFormat) {

        return Optional.of(jpaEntityName)//
                .map(name -> {
                    final String query;
                    switch (name) {
                        case "ChannelEntity_New":
                        case "ChannelEntity":
                            query = "SELECT count(ch.channel_id) as id from channel_tbl as ch where ch.channel_id like '%" + simpleDateFormat + "%'";
                            break;
                        case "ChannelHistoryEntity":
                            query = "SELECT count(ch.channel_his_id) as id from channel_history_tbl as ch where ch.channel_his_id like '%" + simpleDateFormat + "%'";
                            break;
                        case "ChannelHistoryEntity_new":
                            query = "SELECT count(ch.channel_his_id) as id from channel_history_tbl_new as ch where ch.channel_his_id like '%" + simpleDateFormat + "%'";
                            break;
                        case "UserEntity":
                            query = "SELECT count(u.user_id) as id from user_tbl as u where u.user_id like '%" + simpleDateFormat + "%'";
                            break;
                        case "EventEntity":
                            query = "SELECT count(ev.event_id) as id from event_tbl as ev where ev.event_id like '%" + simpleDateFormat + "%'";
                            break;
                        case "DepartmentEntity":
                            query = "SELECT count(dt.dept_id) as id from department_tbl as dt where dt.dept_id like '%%'";
                            break;
                        case "PointEntity":
                            query = "SELECT count(dt.eventId) as id from point_tbl as pt where pt.event_id = '"+simpleDateFormat+"'";
                            break;
                        default:
                            query = StringUtils.EMPTY;
                            break;
                    }
                    return query;
                })//
                .orElse(Strings.EMPTY);
    }

    /**
     * @param jpaEntityName jpa EntityName
     * @return UUID prefixed from entity name
     */
    protected static String getPrefix(final String jpaEntityName) {

        return Optional.of(jpaEntityName)//
                .map(name -> {
                    final String prefix;
                    switch (name) {
                        case "ChannelEntity_New":
                        case "ChannelEntity":
                            prefix = "LIVE";
                            break;
                        case "ChannelHistoryEntity":
                            prefix = "CON_";
                            break;
                        case "EventEntity":
                            prefix = "E";
                            break;
                        case "DepartmentEntity":
                            prefix = "OR";
                            break;
                        default:
                            prefix = StringUtils.EMPTY;
                            break;
                    }
                    return prefix;
                })//
                .orElse(Strings.EMPTY);
    }
}