package com.teixon.cms.mediahub.common.jpa.id;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.type.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.Optional;
import java.util.Properties;
import java.util.UUID;

/**
 * uuid 생성기
 *
 * @author matin
 */
public class UUIDGenerator extends org.hibernate.id.UUIDGenerator {

	/**
	 * jpa 상 entity 이름
	 */
	private String jpaEntityName;

	/**
	 * logger
	 */
	private final Logger logger = LoggerFactory.getLogger(UUIDGenerator.class);

	@Override
	public void configure(final Type type, final Properties params, final ServiceRegistry serviceRegistry) throws MappingException {

		// entityName = params.getProperty(ENTITY_NAME);
		jpaEntityName = params.getProperty(JPA_ENTITY_NAME);

		super.configure(type, params, serviceRegistry);
	}

	@Override
	public Serializable generate(final SharedSessionContractImplementor session, final Object object) throws HibernateException {

		final String prefix = getPrefix(jpaEntityName);

		final String uuid = Optional.of(prefix).filter(Strings::isNotBlank)
				.map(pre -> String.format("%s-%s", pre, UUID.randomUUID().toString()))
				.orElse(UUID.randomUUID().toString());

		logger.debug("Generated new UUID to [Entity = {}] => {}", jpaEntityName, uuid);

		return uuid;
	}

	/**
	 * @param jpaEntityName
	 * 		jpa EntityName
	 *
	 * @return UUID prefixed from entity name
	 */
	protected static String getPrefix(final String jpaEntityName) {

		return Optional.of(jpaEntityName)//
				.map(name -> {
					final String prefix;
					switch (name) {
						case "AccountEntity":
							prefix = "ACCT";
							break;
						case "UserEntity":
							prefix = "USR";
							break;
						case "FileEntity":
							prefix = "FL";
							break;
						case "TapeEntity":
							prefix = "TP";
							break;
						case "JobEntity":
							prefix = "JOB";
							break;
						case "ChannelEntity":
							prefix = "CHL";
							break;
						case "UserPasswordResetSessionEntity":
							prefix = "PWD";
							break;
						default:
							prefix = StringUtils.EMPTY;
							break;
					}
					return prefix;
				})//
				.orElse(Strings.EMPTY);
	}

}