package com.teixon.cms.mediahub.common.jpa.columns;

/**
 * column length defines
 *
 * @author matin
 */
public class ColumnLength {

	/**
	 * name column 길이
	 */
	public static final int NAME = 500;

	/**
	 * pk column length
	 */
	public static final int UUID = 100;

	/**
	 * login id column length
	 */
	public static final int LOGIN_ID = 100;

	/**
	 * password column length
	 */
	public static final int PASSWORD = 200;

	/**
	 * title column length
	 */
	public static final int TITLE = 300;

	/**
	 * code column length
	 */
	public static final int CODE = 100;

	/**
	 * path column length
	 */
	public static final int PATH = 1024;

	/**
	 * status column length
	 */
	public static final int STATUS = 100;


	/**
	 * type column length
	 */
	public static final int TYPE = 100;

	/**
	 * value column length
	 */
	public static final int VALUE = 4000;


	/**
	 * ip column length
	 */
	public static final int IP = 1024;


	/**
	 * mobile number column length
	 */
	public static final int MOBILE_NUM = 20;

}
