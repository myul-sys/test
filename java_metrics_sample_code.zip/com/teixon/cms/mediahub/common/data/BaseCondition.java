package com.teixon.cms.mediahub.common.data;

/**
 * page 관련 기본 정보
 *
 * @author matin
 **/
public class BaseCondition {

	/**
	 * page 크기
	 */
	private Integer pageSize;

	/**
	 * page 번호
	 */
	private Integer pageNumber;

	/**
	 * @param pageNumber
	 * 		page 번호
	 * @param pageSize
	 * 		page 크기
	 */
	public BaseCondition(final Integer pageNumber, final Integer pageSize) {

		this.pageSize = pageSize > -1 && pageSize != null ? pageSize : Integer.MAX_VALUE;
		this.pageNumber = pageNumber;
	}

	/**
	 * @return offset index
	 */
	public long getOffset() {

		if (isEmptyPageNumbers()) {
			return 0;
		} else {
			return ((long) pageSize) * ((long) pageNumber);
		}
	}

	/**
	 * @return page size
	 */
	public Integer getPageSize() {

		return pageSize == null || pageSize < 0 ? Integer.MAX_VALUE : pageSize;
	}

	/**
	 * @param pageSize
	 * 		page size
	 */
	public void setPageSize(final Integer pageSize) {

		this.pageSize = pageSize;
	}

	/**
	 * @return page number
	 */
	public Integer getPageNumber() {

		return pageNumber == null ? 0 : pageNumber;
	}

	/**
	 * @param pageNumber
	 * 		page number
	 */
	public void setPageNumber(final Integer pageNumber) {

		this.pageNumber = pageNumber;
	}


	private boolean isEmptyPageNumbers() {

		return this.pageSize == null || this.pageNumber == null;
	}

}