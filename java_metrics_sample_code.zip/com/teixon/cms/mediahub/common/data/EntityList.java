package com.teixon.cms.mediahub.common.data;

import java.util.Collection;

/**
 * @param <T>
 * 		type of the entity class
 *
 * @author matin
 */
public class EntityList<T> {

	/**
	 * total
	 */
	private Long total;

	/**
	 * firstResult
	 */
	private Long firstResult;

	/**
	 * maxResult
	 */
	private Integer maxResult;

	/**
	 * content
	 */
	private Collection<T> content;

	/**
	 * @param content
	 * 		list of entity
	 * @param total
	 * 		total count
	 * @param firstResult
	 * 		first result offset
	 * @param pageSize
	 * 		page size
	 */
	public EntityList(
			final Collection<T> content, final Long total, final Long firstResult,
			final Integer pageSize) {

		this.total = total;
		this.firstResult = firstResult;
		this.maxResult = pageSize;
		this.content = content;
	}

	/**
	 * @return the total
	 */
	public Long getTotal() {

		return total;
	}

	/**
	 * @param total
	 * 		the total to set
	 */
	public void setTotal(final Long total) {

		this.total = total;
	}

	/**
	 * @return the firstResult
	 */
	public Long getFirstResult() {

		return firstResult;
	}

	/**
	 * @param firstResult
	 * 		the firstResult to set
	 */
	public void setFirstResult(final Long firstResult) {

		this.firstResult = firstResult;
	}

	/**
	 * @return the maxResult
	 */
	public Integer getMaxResult() {

		return maxResult;
	}

	/**
	 * @param maxResult
	 * 		the maxResult to set
	 */
	public void setMaxResult(final Integer maxResult) {

		this.maxResult = maxResult;
	}

	/**
	 * @return the content
	 */
	public Collection<T> getContent() {

		return content;
	}

	/**
	 * @param content
	 * 		the content to set
	 */
	public void setContent(final Collection<T> content) {

		this.content = content;
	}

}
