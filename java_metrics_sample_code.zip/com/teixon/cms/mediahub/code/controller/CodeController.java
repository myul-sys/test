package com.teixon.cms.mediahub.code.controller;


import com.teixon.cms.mediahub.code.dto.CodeEntity;
import com.teixon.cms.mediahub.code.dto.CodeGroupEntity;
import com.teixon.cms.mediahub.code.repository.CodeGroupRepository;
import com.teixon.cms.mediahub.code.repository.CodeRepository;
import com.teixon.cms.mediahub.common.api.ApiResult;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/api/account/{accountId}/code")
public class CodeController {

    /**
     * logger handle
     */
    private final Logger logger = LoggerFactory.getLogger(CodeController.class);

    /**
     * Code group management repository
     */
    @Autowired
    private CodeGroupRepository codeGroupRepo;

    /**
     * Code management repository
     */
    @Autowired
    private CodeRepository codeRepo;


    /**
     * delete a codeGroup
     *
     * @param accountId
     * 		code accountId
     *
     * @param groupId
     * 		code groupId
     *
     * @return new a code registered {@link CodeEntity}
     */
    @DeleteMapping(value = "/group/{groupId}")
    public ApiResult<CodeGroupEntity> groupDelete(//
                                                  @PathVariable(value = "accountId") final String accountId, //
                                                  @PathVariable(value = "groupId") final String groupId) {

        logger.debug("request to delete a code [accountId = {}], [groupId = {}]",
                accountId, groupId);

        final CodeGroupEntity delCodeGroup = codeGroupRepo.findByGroupId(accountId, groupId)//
                .map(cg -> {
                    cg.groupStatus = CodeGroupEntity.codeGroupStatus.Delete;
                    codeRepo.findByGroupId(accountId, groupId)
                            .map(c -> {
                                c.status = CodeEntity.codeStatus.Delete;
                                return codeRepo.saveAndFlush(c);
                            }).orElseThrow(() -> new RuntimeException("can not deleted code"));
                    return codeGroupRepo.saveAndFlush(cg);
                }).orElseThrow(() -> new RuntimeException("can not deleted codeGroup"));

        return ApiResult.ofSuccess(delCodeGroup);
    }

    /**
     * delete a code
     *
     *  @param accountId
     *      accountId
     *
     * @param groupId
     * 		code groupId
     *
     * @param id
     * 		code id
     *
     * @return new a code registered {@link CodeEntity}
     */
    @DeleteMapping(value = "/group/{groupId}/id/{id}")
    public ApiResult<CodeGroupEntity> codeDelete(//
                                                 @PathVariable(value = "accountId") final String accountId, //
                                                 @PathVariable(value = "groupId") final String groupId, //
                                                 @PathVariable(value = "id") final String id) {

        logger.debug("request to delete a code [accountId = {}],[groupId = {}],[id={}]"
                , accountId, groupId, id);

        final CodeGroupEntity delCodeGroup = codeGroupRepo.findByGroupId(accountId, groupId)
                .map( cg -> {
                    final CodeEntity delCode = codeRepo.findById(accountId, groupId, id)
                            .map(c -> {
                                c.status = CodeEntity.codeStatus.Delete;
                                return codeRepo.saveAndFlush(c);
                            }).orElseThrow(() -> new RuntimeException("can not deleted code"));
                    return codeGroupRepo.saveAndFlush(cg);
                }).orElseThrow(() -> new RuntimeException("can not deleted codeGroup"));

        return ApiResult.ofSuccess(delCodeGroup);
    }


    /**
     * modify a code
     *
     * @param accountId
     * 	     accountId
     *
     * @param groupId
     * 		code groupId
     *
     * @param codeGroup
     * 		a codeGroup requested to be modification
     *
     * @return modified a code {@link CodeEntity}
     */
    @PutMapping(value = "/group/{groupId}")
    public ApiResult<CodeGroupEntity> codeGroupPatch(//
                                                     @PathVariable(value = "accountId") final String accountId, //
                                                     @PathVariable(value = "groupId") final String groupId, //
                                                     @RequestBody final CodeGroupEntity codeGroup) {

        codeGroup.accountId = accountId;
        codeGroup.setGroupId(groupId);

        logger.debug("request to modify a codeGroup [codeGroupId = {}]", codeGroup);

        Optional.of(codeGroup)
                .filter(c -> StringUtils.isNotBlank(c.getGroupId()))//
                .orElseThrow(() -> new RuntimeException("the request for the wrong values"));

        final CodeGroupEntity modGroup = codeGroupRepo.findByGroupId(codeGroup.accountId, codeGroup.getGroupId())
                .map(oldGroup -> {
                    oldGroup.name= codeGroup.name;
                    return codeGroupRepo.saveAndFlush(oldGroup);
                }).orElseThrow(() ->
                        new RuntimeException(String.format("not found groupId ")));

        logger.debug("complete to patched a codeGroup [group = {}]", modGroup);

        return ApiResult.ofSuccess(modGroup);
    }

    /**
     * modify a code
     *
     * @param groupId
     * 		code groupId
     *
     * @param id
     * 		code id
     *
     * @param code
     * 		a code requested to be modification
     *
     * @return modified a code {@link CodeEntity}
     */
    @PutMapping(value = "/group/{groupId}/id/{id}")
    public ApiResult<CodeEntity> codePatch(//
                                           @PathVariable(value = "accountId") final String accountId, //
                                           @PathVariable(value = "groupId") final String groupId, //
                                           @PathVariable(value = "id") final String id, //
                                           @RequestBody final CodeEntity code) {

        code.accountId = accountId;
        code.groupId = groupId;
        code.setId(id);

        logger.debug("request to modify a code [code = {}]", code);

        Optional.of(code)
                .filter(c -> StringUtils.isNotBlank(c.groupId))//
                .filter(c -> StringUtils.isNotBlank(c.getId()))//
                .orElseThrow(() -> new RuntimeException("the request for the wrong values"));

        final CodeEntity modCode = codeRepo.findById(accountId, code.groupId, code.getId())//
                .map(c -> {
                    c.name = code.name;
                    c.status = code.status;
                    return codeRepo.saveAndFlush(c);
                }).orElseThrow(() -> new RuntimeException("can not modified code"));

        logger.debug("complete to modify a code [modCode = {}]", modCode);

        return ApiResult.ofSuccess(modCode);

    }
    /**
     * register new code
     *
     *  @param accountId
     *  		owner account id
     *
     * @param code group name
     * 		code group name
     *
     * @param code
     * 		a code requested to be modification
     *
     * @return new a code registered {@link CodeEntity}
     */
    @PostMapping(value = "/group/{groupId}")
    public ApiResult<CodeEntity> codePost(//
                                          @PathVariable(value = "accountId")final String accountId,
                                          @PathVariable(value = "groupId") final String groupId, //
                                          @RequestBody final CodeEntity code) {

        code.accountId = accountId;
        code.groupId = groupId;

        Optional.of(code) //
                .filter(c -> StringUtils.isNotBlank(c.name))//
                .orElseThrow(() -> new RuntimeException("the request for the wrong values"));

        logger.debug("request to register a new code [code = {}]", code);

        if(codeRepo.findByName(accountId, code.groupId , code.name)
                .isPresent()) {
            throw new RuntimeException("already for the code name");
        }

        final CodeEntity newCode = codeRepo.saveAndFlush(code); //

        logger.debug("complete to register a new code [accountId={}] [code = {}]", accountId,
                newCode);

        return ApiResult.ofSuccess(newCode);
    }

    /**
     * register new code
     *
     *  @param accountId
     *  		owner account id

     * @param codeGroup
     * 		a code requested to registration
     *
     * @param codeGroup
     * 		a codeGroup requested to be modification
     *
     * @return new a code registered {@link CodeEntity}
     */
    @PostMapping(value = "/group")
    public ApiResult<CodeGroupEntity> groupPost(//
                                                @PathVariable(value = "accountId")final String accountId,
                                                @RequestBody final CodeGroupEntity codeGroup) {

        codeGroup.accountId = accountId;

        logger.debug("request to register a new codeGroup [codeGroup = {}]", codeGroup);

        /**
         * 중복체크
         * */
        if( codeGroupRepo.findByName(accountId, codeGroup.name)
                .isPresent()){
            throw new RuntimeException("already for the code group name");
        }

        final CodeGroupEntity newCodeGroup = Optional.of(codeGroup) //
                .filter(c -> StringUtils.isNotBlank(c.name))//
                .map(c -> codeGroupRepo.saveAndFlush(c))//
                .orElseThrow(() -> new RuntimeException("the request for the wrong values"));

        logger.debug("complete to register a new CodeGroup [newCodeGroup = {}]", newCodeGroup);

        return ApiResult.ofSuccess(newCodeGroup);
    }


    /**
     * Get a list of code group
     *
     * @param accountId
     * 		owner account id
     *
     * @return code group list
     */
    @GetMapping(value = "/group/list")
    public ApiResult<List<CodeGroupEntity>> groupList(
            @PathVariable(value = "accountId") @NotBlank final String accountId) {

        logger.debug("group test ==> [acctId={}]", accountId);

        final List<CodeGroupEntity> list = codeGroupRepo.list(accountId);

        return ApiResult.ofSuccess(list);
    }

    /**
     * get code list
     *
     * @param accountId
     *     owner account id
     *
     * @param name
     * 		code group name
     *
     * @return code list
     */
    @GetMapping(value = "/group/{name}/list")
    public ApiResult<List<CodeEntity>> codeList(//
                                                @PathVariable(value = "accountId") @NotBlank final String accountId,
                                                @PathVariable(value = "name") @NotBlank final String name) {

        final List<CodeEntity> list = codeRepo.list(accountId, name);

        return ApiResult.ofSuccess(list);
    }




}
