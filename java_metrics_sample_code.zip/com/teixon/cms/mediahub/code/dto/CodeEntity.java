package com.teixon.cms.mediahub.code.dto;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

/**
 * Code value management entity
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "code_tbl")
public class CodeEntity {


    /**
     * code value
     */
    @Id
    @GenericGenerator(name = "code_id_uuid", strategy = "com.teixon.cms.mediahub.common.jpa.id.UUIDGenerator")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "code_id_uuid")
    @Column(name = "code_id", nullable = false, updatable = false, length = ColumnLength.UUID)
    //@JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String id;

    //@JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Column(name = "code_group_id", nullable = false, updatable = false, length = ColumnLength.UUID)
    public String groupId;

    @Column(name = "acct_id", nullable = false, updatable = false, length = 100)
    public String accountId;

    @Column(name = "code_nm", nullable = false, length = ColumnLength.NAME)
    public String name;

    /** code status */
    @Enumerated(EnumType.STRING)
    @Column(name = "code_status", nullable = false, length = ColumnLength.STATUS)
    public CodeEntity.codeStatus status;

    /**
     * default constructor
     */
    public CodeEntity() {
        this.status = CodeEntity.codeStatus.Use;
    }

    /**
     * @param name
     * 		set the code value
     */
    public CodeEntity(@NotBlank final String name) {
        this.name = name;
        this.status = CodeEntity.codeStatus.Use;
    }

    /**
     * code status
     */
    public enum codeStatus {
        /**
         * using code
         */
        Use,
        /**
         * not used code
         */
        NotUsed,
        /**
         * Delete
         * */
        Delete
    }

    @Override
    public String toString() {

        return ToStringBuilder.reflectionToString(this);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
