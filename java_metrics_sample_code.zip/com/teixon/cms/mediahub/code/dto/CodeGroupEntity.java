package com.teixon.cms.mediahub.code.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

/**
 * Properties management group
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "code_group_tbl")
public class CodeGroupEntity {

	/**
	 * define group code file path
	 */
	public static final String GROUP_FILE_PATH = "FILE_PATH";

	/**
	 * define group code task option
	 */
	public static final String GROUP_TASK_OPTION = "TASK_OPTION";


	/**
	 * group id
	 */
	@Id
	@GenericGenerator(name = "group_id_uuid", strategy = "com.teixon.cms.mediahub.common.jpa.id.UUIDGenerator")
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "group_id_uuid")
	@Column(name = "group_id", nullable = false, updatable = false, length = ColumnLength.UUID)
	//@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String groupId;

	@Column(name = "acct_id", nullable = false, length = 100)
	public String accountId;

	@Column(name = "group_nm", nullable = false, length = ColumnLength.NAME)
	public String name;


	/** code status */
	@Enumerated(EnumType.STRING)
	@Column(name = "group_status", nullable = false, length = ColumnLength.STATUS)
	public CodeGroupEntity.codeGroupStatus groupStatus;


	/**
	 * default constructor
	 */
	public CodeGroupEntity() {
		this.groupStatus = CodeGroupEntity.codeGroupStatus.Use;
	}

	/**
	 * @param name
	 * 		set the group title
	 */
	public CodeGroupEntity(@NotBlank final String name) {
		this.groupStatus = CodeGroupEntity.codeGroupStatus.Use;
		this.name = name;
	}

	/**
	 * code status
	 */
	public enum codeGroupStatus {
		/**
		 * using code
		 */
		Use,
		/**
		 * not used code
		 */
		NotUsed,
		/**
		 * Delete
		 * */
		Delete
	}


	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
}
