package com.teixon.cms.mediahub.code.repository;


import com.teixon.cms.mediahub.code.dto.CodeGroupEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Optional;

public interface CodeGroupRepository extends
        JpaRepository<CodeGroupEntity, String> {

    /**
     * get list of code group
     *
     * @return code group list
     */
    @Query(value = "SELECT cg FROM CodeGroupEntity cg"//
                    +" WHERE cg.accountId = :accountId" )
    List<CodeGroupEntity> list(
            @NotNull @Param("accountId") String accountId);


    /**
     * get a codeGroup
     *
     * @param accountId
     *
     * @param groupId
     *
     * @return a codeName
     */

    @Query(value = "SELECT cg FROM CodeGroupEntity cg WHERE "//
            +" cg.accountId = :accountId and cg.groupId = :groupId ")
    Optional<CodeGroupEntity> findByGroupId(
            @NotNull @Param("accountId") String accountId,
            @NotNull @Param("groupId") String groupId);

    /**
     * get a codeGroup
     *
     * @param accountId
     * 		the accountId
     *
     * @param name
     *
     * @return a codeName
     */

    @Query(value = "SELECT cg FROM CodeGroupEntity cg WHERE "//
            +" cg.accountId = :accountId and cg.groupId = :groupId "//
            +" and cg.name = :name" )
    Optional<CodeGroupEntity> findById(
            @NotNull @Param("accountId") String accountId,
            @NotNull @Param("groupId") String groupId,
            @NotNull @Param("name") String name);

    /**
     * get a codeGroup
     *
     * @param accountId
     * 		the accountId
     *
     * @param name
     *
     * @return a codeName
     */

    @Query(value = "SELECT cg FROM CodeGroupEntity cg WHERE cg.accountId = :accountId and cg.name = :name ")
    Optional<CodeGroupEntity> findByName(
            @NotNull @Param("accountId") String accountId,
            @NotNull @Param("name") String name);
}


