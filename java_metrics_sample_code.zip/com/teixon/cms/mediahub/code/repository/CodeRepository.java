package com.teixon.cms.mediahub.code.repository;

import com.teixon.cms.mediahub.code.dto.CodeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.validation.constraints.NotBlank;
import java.util.List;
import java.util.Optional;


public interface CodeRepository extends JpaRepository<CodeEntity, String> {

    /**
     * get list code
     *
     * @param accountId accountId
     * @param name      code group name
     * @return code list
     */
    @Query(value = //
            "SELECT c FROM CodeEntity c " //
                    + "WHERE c.accountId = :accountId and c.name = :name ")
    List<CodeEntity> list(
            @NotBlank @Param("accountId") String accountId,
            @NotBlank @Param("name") String name);

    /**
     * get a code
     *
     * @param accountId accountId
     * @param groupId   groupId
     * @return a code
     */

    @Query(value = "SELECT c FROM CodeEntity c WHERE c.accountId = :accountId "//
            + "and c.groupId= :groupId")
    Optional<CodeEntity> findByGroupId(
            @NotBlank @Param("accountId") String accountId,
            @NotBlank @Param("groupId") String groupId);

    /**
     * get a code
     *
     * @param accountId accountId
     * @param groupId   groupId
     * @param id        code id
     * @return a code
     */

    @Query(value = "SELECT c FROM CodeEntity c WHERE c.accountId = :accountId "//
            + "and c.groupId= :groupId and c.id = :id ")
    Optional<CodeEntity> findById(
            @NotBlank @Param("accountId") String accountId,
            @NotBlank @Param("groupId") String groupId,
            @NotBlank @Param("id") String id);

    /**
     * get a code
     *
     * @param accountId accountId
     * @param groupId   groupId
     * @param name      code group name
     * @return a code
     */

    @Query(value = "SELECT c FROM CodeEntity c WHERE c.accountId = :accountId "//
            + "and c.groupId= :groupId and c.name = :name ")
    Optional<CodeEntity> findByName(
            @NotBlank @Param("accountId") String accountId,
            @NotBlank @Param("groupId") String groupId,
            @NotBlank @Param("name") String name);

}