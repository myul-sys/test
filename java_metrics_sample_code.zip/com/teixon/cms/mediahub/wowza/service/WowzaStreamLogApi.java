package com.teixon.cms.mediahub.wowza.service;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.teixon.cms.mediahub.wowza.dto.WowzaLogSearchCondition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/**
 * wowza server log http send
 */
@Service
public class WowzaStreamLogApi {
    /**
     * logger
     */
    private final Logger logger = LoggerFactory.getLogger(WowzaStreamLogApi.class);

    /**
     *
     * @param condition  wowoza log condition
     * @param streamApiInfo wowza server info {@link WowzaStreamApiInfo}
     * @return
     * @throws IOException wowza server http error
     * @throws InterruptedException wowza server http error
     */
    public String WowzaStreamLogData(WowzaLogSearchCondition condition, WowzaStreamApiInfo streamApiInfo, String logfileName) throws IOException, InterruptedException {
        String requestUrl = streamApiInfo.GetBaseUrl();
        String urlParameter = String.format("lineCount=%d",condition.getLineCount());
        if (condition.getKeyword() != null && !condition.getKeyword().trim().equals("") ) {
            urlParameter = urlParameter + String.format("&search=%s",condition.getKeyword());
        }

        HttpRequest request = streamApiInfo.GetBuilder(String.format("%s/_defaultServer_/logfiles/%s?%s",requestUrl,logfileName,urlParameter))
                .GET()
                .build();

        String result = "";
        HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        result = response.body();

//        logger.debug(result);

        JsonParser parser = new JsonParser();
        JsonElement root = parser.parse(result);
        JsonObject rootObject = root.getAsJsonObject();
        if( rootObject.has("code") ) {
            result = null;
        }
        return result;
    }
}
