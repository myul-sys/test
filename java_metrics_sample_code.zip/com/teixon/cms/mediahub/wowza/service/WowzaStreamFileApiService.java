package com.teixon.cms.mediahub.wowza.service;

import com.teixon.cms.mediahub.common.utils.StringFormatter;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URLEncoder;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

/**
 * wowza stream file api service
 */
@Service
public class WowzaStreamFileApiService {

    /**
     * logger
     */
    private final Logger logger = LoggerFactory.getLogger(WowzaStreamFileApiService.class);
    /**
     * wowza stream file create
     * @param name stream file name
     * @param serverName wowza server name, null is default = _defaultServer_
     * @param uri wowza server connect url, null is default = rtmp://172.19.200.52:1935
     * @param streamApiInfo wowza server info {@link WowzaStreamApiInfo}
     *
     */
    public void WowzaStreamFileCreate(@Nullable String name, String serverName , String uri, WowzaStreamApiInfo streamApiInfo) throws IOException, InterruptedException {
        String defaultServerName = serverName == null ? "_defaultServer_" : serverName;
        String defaultServerUri = uri == null ? "rtmp://172.19.200.52:1935" : uri;

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("name", name);
        jsonObject.put("serverName", defaultServerName);
        jsonObject.put("uri", defaultServerUri);

        String requestUrl = streamApiInfo.GetBaseUrl();

        HttpRequest request = streamApiInfo.GetBuilder( String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/streamfiles",requestUrl))
                .POST(HttpRequest.BodyPublishers.ofString(jsonObject.toJSONString()))
                .build();

        String result = "";
        HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        result = response.body();

        logger.debug("{}",result);
//        this.WowzaStreamFileConnect(name, streamApiInfo);
    }


    /**
     * wowza stream file info
     * @param name stream file name
     *
     * wowza server info
     * @param streamApiInfo {@link WowzaStreamApiInfo}
     *
     */
    public void WowzaStreamFileGet(String name, WowzaStreamApiInfo streamApiInfo) throws IOException, InterruptedException {
        String requestUrl = streamApiInfo.GetBaseUrl();

        String url = String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/streamfiles/%s",requestUrl, URLEncoder.encode(name, Charset.forName("UTF-8")) );
        HttpRequest request = streamApiInfo.GetBuilder(url)
                .GET()
                .build();

        String result = "";
        HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        result = response.body();

    }

    /**
     * wowza stream file delete
     * @param name stream file name
     *
     * wowza server info
     * @param streamApiInfo {@link WowzaStreamApiInfo}
     *
     */
    public void WowzaStreamFileDelete(String name, WowzaStreamApiInfo streamApiInfo) throws IOException, InterruptedException {

        String requestUrl = streamApiInfo.GetBaseUrl();

        String url = String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/streamfiles/%s",requestUrl,URLEncoder.encode(name, Charset.forName("UTF-8")) );
        HttpRequest request = streamApiInfo.GetBuilder(url)
                .DELETE()
                .build();

        String result = "";
        HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        result = response.body();
    }

    /**
     * wowza stream file list
     */
    public void WowzaStreamFileList(WowzaStreamApiInfo streamApiInfo) throws IOException, InterruptedException {
        String requestUrl = streamApiInfo.GetBaseUrl();

        HttpRequest request = streamApiInfo.GetBuilder(String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/streamfiles",requestUrl))
                .GET()
                .build();

        String result = "";
        HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        result = response.body();
    }

    /**
     * wowza stream file connect
     * @param name stream file name
     *
     * wowza server info
     * @param streamApiInfo {@link WowzaStreamApiInfo}
     *
     */
    public void WowzaStreamFileConnect(String name, WowzaStreamApiInfo streamApiInfo) throws IOException, InterruptedException {

        String requestUrl = streamApiInfo.GetBaseUrl();

        Map<String, String> parameter = new HashMap<>();
        parameter.put("connectAppName","live");
        parameter.put("appInstance","_definst_");
        parameter.put("mediaCasterType","rtp");


        String url = String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/streamfiles/%s",requestUrl,URLEncoder.encode(name, Charset.forName("UTF-8")) );
        url = url + String.format("/actions/connect%s",StringFormatter.fromParameter(parameter));
        HttpRequest request = streamApiInfo.GetBuilder(url)
                .PUT(HttpRequest.BodyPublishers.noBody())
                .build();

        String result = "";
        HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        result = response.body();
        logger.debug("{}",result);
    }

    /**
     * wowza stream file disconnect
     * @param name
     *
     * wowza server info
     * @param streamApiInfo {@link WowzaStreamApiInfo}
     */
    public void WowzaStreamFileDisconnect(String name, WowzaStreamApiInfo streamApiInfo) throws IOException, InterruptedException {

        String requestUrl = streamApiInfo.GetBaseUrl();

        String url = String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/instances/_definst_/incomingstreams/%s.stream",requestUrl,URLEncoder.encode(name, Charset.forName("UTF-8")) );
        url = url + String.format("/actions/disconnectStream");
        HttpRequest request = streamApiInfo.GetBuilder(url)
                .PUT(HttpRequest.BodyPublishers.noBody())
                .build();

        String result = "";
        HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        result = response.body();
    }
}
