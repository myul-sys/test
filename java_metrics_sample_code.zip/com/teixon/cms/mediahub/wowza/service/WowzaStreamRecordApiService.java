package com.teixon.cms.mediahub.wowza.service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.teixon.cms.mediahub.wowza.dto.WowzaResult;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;

/**
 * wowza stream record api service
 */
@Service
public class WowzaStreamRecordApiService {

    /**
     * logger
     */
    private final Logger logger = LoggerFactory.getLogger(WowzaStreamRecordApiService.class);

    /**
     * wowza stream record list
     * @param streamApiInfo wowza server info {@link WowzaStreamApiInfo}
     * @throws IOException wowza server http error
     * @throws InterruptedException wowza server http error
     */
    public void WowzaStreamRecordList(WowzaStreamApiInfo streamApiInfo) throws IOException, InterruptedException {
        String requestUrl = streamApiInfo.GetBaseUrl();

        HttpRequest request = streamApiInfo.GetBuilder(String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/instances/_definst_/streamrecorders",requestUrl))
                .GET()
                .build();

        String result = "";
        HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        result = response.body();

        System.out.println(result);
    }

    /**
     * wowza stream record create
     * @param name wowza stream record name
     * @param streamApiInfo wowza server info {@link WowzaStreamApiInfo}
     * @return wowza result data
     *   WowzaResult {@link WowzaResult}
     */
    public WowzaResult WowzaStreamRecordCreate(String name, String fileName, WowzaStreamApiInfo streamApiInfo) {
        String requestUrl = streamApiInfo.GetBaseUrl();
        WowzaResult wowzaResult = null;

        String recorderName = name;
        if (recorderName.lastIndexOf(".stream") == -1) {
            recorderName = recorderName + ".stream";
        }

        String baseFile = fileName + ".mp4";
        String fileTemplate = "${BaseFileName}_${RecordingStartTime}_${SegmentNumber}";
        String segmentSchedule = "0 * * * * *";
        int segmentDuration = 900000;
        int segmentSize = 10485760;

        JSONObject jsonObject = new JSONObject();

        jsonObject.put("instanceName", "_definst_");
        jsonObject.put("fileVersionDelegateName", "");
        jsonObject.put("serverName", "");
        jsonObject.put("recorderName", name);
        jsonObject.put("currentSize", 0);
        jsonObject.put("segmentSchedule", "");
        jsonObject.put("startOnKeyFrame", true);
        jsonObject.put("outputPath", "");
        jsonObject.put("currentFile", "");
        jsonObject.put("recordData", false);
        jsonObject.put("applicationName", "");
        jsonObject.put("moveFirstVideoFrameToZero", true);
        jsonObject.put("recorderErrorString", "");
        jsonObject.put("segmentSize", segmentSize);
        jsonObject.put("defaultRecorder", false);
        jsonObject.put("splitOnTcDiscontinuity", false);
        jsonObject.put("version", "");
        jsonObject.put("baseFile", baseFile);
        jsonObject.put("segmentDuration", segmentDuration);
        jsonObject.put("recordingStartTime", "");
        jsonObject.put("fileTemplate", fileTemplate);
        jsonObject.put("backBufferTime", 0);
        jsonObject.put("segmentationType", "");
        jsonObject.put("currentDuration", 0);
        jsonObject.put("fileFormat", "MP4");
        jsonObject.put("recorderState", "");
        jsonObject.put("option", "Version existing file");

        HttpRequest request = streamApiInfo.GetBuilder(String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/instances/_definst_/streamrecorders/%s",requestUrl, recorderName))
                .POST(HttpRequest.BodyPublishers.ofString(jsonObject.toJSONString()))
                .build();

        try {

            String result = "";
            HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
            result = response.body();

            JSONParser parse = new JSONParser();

            JSONObject object = (JSONObject) parse.parse(result);
            final Gson gson = new Gson();
            final Type type = new TypeToken<WowzaResult>() {
            }.getType();
            wowzaResult = gson.fromJson(object.toJSONString(), type);
        }catch (Exception e) {
            wowzaResult = new WowzaResult();
            wowzaResult.message = e.getMessage();
            logger.error(e.getMessage());
        }

        return wowzaResult;
    }

    /**
     * wowza stream record split
     * @param name wowza stream record name
     * @param streamApiInfo wowza server info {@link WowzaStreamApiInfo}
     * @return wowza result data
     *   WowzaResult {@link WowzaResult}
     */
    public WowzaResult WowzaStreamRecordSplit(String name, WowzaStreamApiInfo streamApiInfo) {
        String requestUrl = streamApiInfo.GetBaseUrl();
        WowzaResult wowzaResult = null;

        String recorderName = name;
        if (recorderName.lastIndexOf(".stream") == -1) {
            recorderName = recorderName + ".stream";
        }

        String url = String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/instances/_definst_/streamrecorders",requestUrl);
        url = url + String.format("/%s/actions/splitRecording",recorderName);

        HttpRequest request = streamApiInfo.GetBuilder(url)
                .PUT(HttpRequest.BodyPublishers.noBody())
                .build();

        try {

            String result = "";
            HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
            result = response.body();

            JSONParser parse = new JSONParser();

            JSONObject object = (JSONObject) parse.parse(result);

            final Gson gson = new Gson();
            final Type type = new TypeToken<WowzaResult>() {
            }.getType();
            wowzaResult = gson.fromJson(object.toJSONString(), type);

        }catch (Exception e) {
            wowzaResult = new WowzaResult();
            wowzaResult.message = e.getMessage();
            logger.error(e.getMessage());
        }

        return wowzaResult;
    }

    /**
     * wowza stream record stop
     * @param name wowza stream record name
     * @param streamApiInfo wowza server info {@link WowzaStreamApiInfo}
     * @return wowza result data
     *   WowzaResult {@link WowzaResult}
     */
    public WowzaResult WowzaStreamRecordStop(String name, WowzaStreamApiInfo streamApiInfo) {
        String requestUrl = streamApiInfo.GetBaseUrl();
        WowzaResult wowzaResult = null;

        String recorderName = name;
        if (recorderName.lastIndexOf(".stream") == -1) {
            recorderName = recorderName + ".stream";
        }


        String url = String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/live/instances/_definst_/streamrecorders",requestUrl);
        url = url + String.format("/%s/actions/stopRecording",recorderName);

        HttpRequest request = streamApiInfo.GetBuilder(url)
                .PUT(HttpRequest.BodyPublishers.noBody())
                .build();
        try {

            String result = "";
            HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
            result = response.body();

            JSONParser parse = new JSONParser();

            JSONObject object = (JSONObject) parse.parse(result);

            final Gson gson = new Gson();
            final Type type = new TypeToken<WowzaResult>() {
            }.getType();
            wowzaResult = gson.fromJson(object.toJSONString(), type);

        }catch (Exception e) {
            wowzaResult = new WowzaResult();
            wowzaResult.message = e.getMessage();
            logger.error(e.getMessage());
        }

        return wowzaResult;
    }
}
