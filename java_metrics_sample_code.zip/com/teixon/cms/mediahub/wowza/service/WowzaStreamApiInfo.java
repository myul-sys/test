package com.teixon.cms.mediahub.wowza.service;


import com.teixon.cms.mediahub.common.utils.StringFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@Component
public class WowzaStreamApiInfo {

    public String accept = "application/json; charset=utf-8";
    public String contentType = "application/json; charset=utf-8";

    public String wowzaHost = "cms.teixon.com";
    public String wowzaPort = "8087";
   public String apiVersion = "v2";
    public String apiTarget = "servers";
    public String baseUrl = "http://{wowzaHost}:{wowzaPort}/{apiVersion}/{apiTarget}";

    public String sendPort = "1935";
    public String sendFile = "playlist.m3u8";
    public String sendRtmp = "rtmp";
    public String sendHttp = "http";

    public HttpRequest.Builder GetBuilder(String url) {
        HttpRequest.Builder result = HttpRequest.newBuilder();
        result.uri(URI.create(url)).setHeader("Accept", this.accept).setHeader("Content-Type", this.contentType);
        return result;
    }

    public HttpClient GetHttpClient() {
       final HttpClient httpClient = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .connectTimeout(Duration.ofSeconds(10))
                .build();

       return httpClient;
    }

    public String GetBaseUrl(){
        Map<String, String> path = new HashMap<>();
        path.put("wowzaHost",this.wowzaHost);
        path.put("wowzaPort",this.wowzaPort);
        path.put("apiVersion",this.apiVersion);
        path.put("apiTarget",this.apiTarget);

        return URI.create(StringFormatter.fromValues(this.baseUrl, path)).toString();
    }
}
