package com.teixon.cms.mediahub.wowza.service;

import com.teixon.cms.mediahub.wowza.dto.WowzaLogSearchCondition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * https://www.wowza.com/docs/statistics-query-examples
 * wowza server monitoring http send
 */
@Service
public class WowzaStreamMonitoringApi {
    /**
     * logger
     */
    private final Logger logger = LoggerFactory.getLogger(WowzaStreamMonitoringApi.class);

    /**
     * 해당 서버의 현재 전체 트래픽 정보 요청 한다.
     * @param applications 트래픽 정보 요청 어플리케이션 이름
     * @return
     * @throws IOException wowza server http error
     * @throws InterruptedException wowza server http error
     */
    public String WowzaStreamMonitoringCurrent(WowzaStreamApiInfo streamApiInfo, String applications) throws IOException, InterruptedException {
        logger.debug("WowzaStreamMonitoringCurrent : [applications : {}]",applications);
        String requestUrl = streamApiInfo.GetBaseUrl();

        HttpRequest request = streamApiInfo.GetBuilder(String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/%s/monitoring/current",requestUrl,applications))
                .GET()
                .build();

        String result = "";
        HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        result = response.body();
//
//        logger.debug(result);
        return result;
    }

    /**
     * 해당 채널의 현재 트래픽 정보 요청 한다.
     * @param applications 트래픽 정보 요청 어플리케이션 이름
     * @param channelName 트래픽 정보 요청 채널 이름
     * @return
     * @throws IOException wowza server http error
     * @throws InterruptedException wowza server http error
     */
    public String WowzaStreamMonitoringChannelCurrent(WowzaStreamApiInfo streamApiInfo, String applications, String channelName) throws IOException, InterruptedException {
        logger.debug("WowzaStreamMonitoringChannelCurrent : [applications : {}] [channelName : {}]",applications,channelName);
        String requestUrl = streamApiInfo.GetBaseUrl();
        HttpRequest request = streamApiInfo.GetBuilder(String.format("%s/_defaultServer_/vhosts/_defaultVHost_/applications/%s/instances/_definst_/incomingstreams/%s/monitoring/current",requestUrl,applications,channelName))
                .GET()
                .build();

        String result = "";
        HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        result = response.body();

        logger.debug(result);
        return result;
    }


    /**
     * 데이터 전송 속도 값의 단우 벼경시 125(으)로 나누거나 곱한다.
     * url 검색 데이터 문자열 포멧 2017-04-05T18:00:00
     * @param start 검색 시작 기간
     * @param end 검색 끝 기간
     * @return
     * @throws IOException wowza server http error
     * @throws InterruptedException wowza server http error
     */
    public String WowzaStreamMonitoringHistory(WowzaStreamApiInfo streamApiInfo, Date start , Date end) throws IOException, InterruptedException {
        logger.debug("WowzaStreamMonitoringHistory : [from : {}] [to : {}]",start,end);
        String requestUrl = streamApiInfo.GetBaseUrl();

        String ISO_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
        TimeZone utc = TimeZone.getTimeZone("UTC");
        SimpleDateFormat isoFormatter = new SimpleDateFormat(ISO_FORMAT);
        isoFormatter.setTimeZone(utc);

        String startParameter = String.format("start=%s",isoFormatter.format(start));
        String urlParameter = startParameter;
        if( end != null) {
            String endParameter = String.format("end=%s",isoFormatter.format(end));
            urlParameter = urlParameter + "&" + endParameter;
        }
        HttpRequest request = streamApiInfo.GetBuilder(String.format("%s/_defaultServer_/monitoring/historic?%s",requestUrl,urlParameter))
                .GET()
                .build();

        String result = "";
        HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        result = response.body();

        logger.debug(result);
        return result;
    }

    /**
     * 데이터 전송 속도 값의 단우 벼경시 125(으)로 나누거나 곱한다.
     * url 검색 데이터 문자열 포멧 2017-04-05T18:00:00
     * @param start 검색 시작 기간
     * @param end 검색 끝 기간
     * @return
     * @throws IOException wowza server http error
     * @throws InterruptedException wowza server http error
     */
    public String WowzaStreamApplicationMonitoringHistory(WowzaStreamApiInfo streamApiInfo, Date start , Date end) throws IOException, InterruptedException {
        logger.debug("WowzaStreamMonitoringHistory : [from : {}] [to : {}]",start,end);
        String requestUrl = streamApiInfo.GetBaseUrl();

        String ISO_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
        TimeZone utc = TimeZone.getTimeZone("UTC");
        SimpleDateFormat isoFormatter = new SimpleDateFormat(ISO_FORMAT);
        isoFormatter.setTimeZone(utc);

        String startParameter = String.format("start=%s",isoFormatter.format(start));
        String urlParameter = startParameter;
        if( end != null) {
            String endParameter = String.format("end=%s",isoFormatter.format(end));
            urlParameter = urlParameter + "&" + endParameter;
        }
        HttpRequest request = streamApiInfo.GetBuilder(String.format("%s/_defaultServer_/monitoring/historic?%s",requestUrl,urlParameter))
                .GET()
                .build();

        String result = "";
        HttpResponse<String> response = streamApiInfo.GetHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        result = response.body();

        logger.debug(result);
        return result;
    }
}
