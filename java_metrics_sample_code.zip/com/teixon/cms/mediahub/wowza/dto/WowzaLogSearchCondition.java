package com.teixon.cms.mediahub.wowza.dto;

import com.teixon.cms.mediahub.common.data.BaseCondition;
import com.teixon.cms.mediahub.common.utils.DateRange;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class WowzaLogSearchCondition extends BaseCondition  {

    /**
     * log search keyword to search
     */
    private String keyword;

    /**
     * log search line count
     */
    private int lineCount;

    private DateRange dateRange;

    /**
     * constructor
     */
    public WowzaLogSearchCondition() {
        this(0, Integer.MAX_VALUE);
        this.lineCount = 100;
        this.dateRange = new DateRange(null,null);
    }

    /**
     * @param pageNumber
     * 		page number (begin 0)
     * @param pageSize
     * 		page size
     */
    public WowzaLogSearchCondition(final Integer pageNumber, final Integer pageSize) {
        super(pageNumber, pageSize);
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public int getLineCount() {
        return lineCount;
    }

    public void setLineCount(int lineCount) {
        this.lineCount = lineCount;
    }

    public DateRange getDateRange() {
        return dateRange;
    }

    public void setDateRange(DateRange dataRange){
        this.dateRange = dataRange;
    }
}
