package com.teixon.cms.mediahub.wowza.dto;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class WowzaResult {

	public Boolean success;
	public String message;
	public String data;

	public WowzaResult() {
		this.success = false;
		this.message = null;
		this.data = null;
	}

	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}
}
