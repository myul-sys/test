package com.teixon.cms.mediahub.wowza.dto;

import java.util.Date;

public class WowzaTrafficHistoryResult {
    public String date;
    public Integer traffic;
}
