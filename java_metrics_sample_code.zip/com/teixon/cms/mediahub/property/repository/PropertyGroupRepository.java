package com.teixon.cms.mediahub.property.repository;

import com.teixon.cms.mediahub.property.dto.PropertyGroupEntity;
import com.teixon.cms.mediahub.property.dto.PropertyGroupId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * the properties group management repository
 */
public interface PropertyGroupRepository extends
		JpaRepository<PropertyGroupEntity, PropertyGroupId> {

	/**
	 * get list of property group
	 *
	 * @param accountId
	 * 		owner account id
	 *
	 * @return property group list
	 */
	@Query(value = "SELECT pg FROM PropertyGroupEntity pg WHERE pg.groupId.accountId = :accountId")
	List<PropertyGroupEntity> list(@NotBlank @Param("accountId") String accountId);

	/**
	 * deleted all property groups by account id
	 *
	 * @param accountId
	 * 		target account id
	 */
	void deleteAllByGroupIdAccountId(@NotBlank String accountId);

}
