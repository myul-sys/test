package com.teixon.cms.mediahub.property.repository;

import com.teixon.cms.mediahub.property.dto.PropertyEntity;
import com.teixon.cms.mediahub.property.dto.PropertyId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Optional;

/**
 * the property management repository
 */
public interface PropertyRepository extends JpaRepository<PropertyEntity, PropertyId> {

	/**
	 * get list properties
	 *
	 * @param accountId
	 * 		owner account id
	 * @param groupCode
	 * 		property group code
	 *
	 * @return property list
	 */
	@Query(value = //
			       "SELECT prop FROM PropertyEntity prop " //
					       + "WHERE prop.propertyId.accountId = :accountId AND prop.propertyId.groupCode = :groupCode ")
	List<PropertyEntity> list(
			@NotBlank @Param("accountId") String accountId,
			@NotBlank @Param("groupCode") String groupCode);

	/**
	 * get a property
	 *
	 * @param propertyId
	 * 		the propertyId of the property
	 *
	 * @return a property
	 */

	@Query(value = "SELECT prop FROM PropertyEntity prop WHERE prop.propertyId = :propertyId ")
	Optional<PropertyEntity> findbyPropertyId(@NotNull @Param("propertyId") PropertyId propertyId);

	/**
	 * get a property value
	 *
	 * @param propertyId
	 * 		the propertyId of the property
	 *
	 * @return a property value
	 */
	@Query(value = //
			       "SELECT prop.value FROM PropertyEntity prop WHERE prop.propertyId = :propertyId ")
	String getValue(@NotNull @Param("propertyId") PropertyId propertyId);


	/**
	 * deleted all properties by account id
	 *
	 * @param accountId
	 * 		target account id
	 */
	void deleteAllByPropertyIdAccountId(String accountId);


	/**
	 * deleted all properties by account id and group code
	 *
	 * @param accountId
	 * 		owned account id
	 * @param groupCode
	 * 		target group code
	 */
	void deleteAllByPropertyIdAccountIdAndPropertyIdGroupCode(String accountId, String groupCode);

}
