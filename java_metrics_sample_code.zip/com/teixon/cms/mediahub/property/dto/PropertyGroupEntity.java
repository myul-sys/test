package com.teixon.cms.mediahub.property.dto;

import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * Properties management group
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "property_group_tbl")
public class PropertyGroupEntity {

	/**
	 * define group code file path
	 */
	public static final String GROUP_FILE_PATH = "FILE_PATH";

	/**
	 * define group code task option
	 */
	public static final String GROUP_TASK_OPTION = "TASK_OPTION";

	/**
	 * the properties group id
	 */
	@EmbeddedId
	private final PropertyGroupId groupId;

	/**
	 * group title
	 */
	@Column(name = "title", nullable = false, length = ColumnLength.TITLE)
	private String title;

	/** group owns properties */
	@OneToMany(fetch = FetchType.EAGER, //
	           cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.REMOVE}, //
	           // cascade = CascadeType.ALL, //
	           orphanRemoval = true)
	@JoinColumns(value = {//
			@JoinColumn(name = "acct_id", referencedColumnName = "acct_id"), //
			@JoinColumn(name = "prop_group_cd", referencedColumnName = "prop_group_cd") //
	},foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
	private List<PropertyEntity> properties;

	/**
	 * default constructor
	 */
	public PropertyGroupEntity() {

		this.groupId = new PropertyGroupId();
	}

	/**
	 * @param groupId
	 * 		set the properties group id
	 * @param title
	 * 		set the group title
	 */
	public PropertyGroupEntity(@NotNull final PropertyGroupId groupId, @NotBlank final String title) {

		this.groupId = groupId;
		this.title = title;
	}

	/**
	 * post persist
	 */
	@PostPersist
	public void postPersist() {

		this.properties.forEach(prop -> {
			prop.getPropertyId().setAccountId(this.getGroupId().getAccountId());
			prop.getPropertyId().setGroupCode(this.getGroupId().getGroupCode());
		});
	}

	/**
	 * post update
	 */
	@PostUpdate
	public void postUpdate() {

		this.properties.forEach(prop -> {
			prop.getPropertyId().setAccountId(this.getGroupId().getAccountId());
			prop.getPropertyId().setGroupCode(this.getGroupId().getGroupCode());
		});
	}

	//	@PostRemove
	@PreRemove
	public void preRemove() {

		this.properties.clear();
	}


	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @return get the properties group id
	 */
	public PropertyGroupId getGroupId() {

		return groupId;
	}

	/**
	 * @return the properties group title
	 */
	public String getTitle() {

		return title;
	}

	/**
	 * @param title
	 * 		set the properties group title
	 */
	public void setTitle(@NotBlank final String title) {

		this.title = title;
	}

	/**
	 * @return property list
	 */
	public List<PropertyEntity> getProperties() {

		return properties;
	}

	/**
	 * @param properties
	 * 		set property list
	 */
	public void setProperties(final List<PropertyEntity> properties) {

		this.properties = properties;
	}

}
