package com.teixon.cms.mediahub.property.dto;

import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * Properties management group ID
 */
@Embeddable
public class PropertyGroupId implements Serializable {

	/**
	 * serial version
	 */
	private static final long serialVersionUID = -2222665358490152971L;

	/**
	 * group code
	 */
	@Column(name = "prop_group_cd", nullable = false, length = ColumnLength.CODE)
	private String groupCode;

	/**
	 * account id
	 */
	@Column(name = "acct_id", nullable = false, updatable = false, length = ColumnLength.UUID)
	private String accountId;

	/**
	 * default constructor
	 */
	public PropertyGroupId() {

	}

	/**
	 * @param accountId
	 * 		the properties owner account id
	 * @param groupCode
	 * 		the properties group code
	 */
	public PropertyGroupId(final String accountId, final String groupCode) {

		this.groupCode = groupCode;
		this.accountId = accountId;
	}

	@Override
	public boolean equals(final Object o) {

		return EqualsBuilder.reflectionEquals(this, o);
	}

	@Override
	public int hashCode() {

		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @return the properties group code (english only)
	 */
	public String getGroupCode() {

		return groupCode;
	}

	/**
	 * @param groupCode
	 * 		set the properties group code (english only)
	 */
	public void setGroupCode(@NotBlank final String groupCode) {

		this.groupCode = groupCode;
	}

	/**
	 * @return the owner account id
	 */
	public String getAccountId() {

		return accountId;
	}

	/**
	 * @param accountId
	 * 		set the owner account id
	 */
	public void setAccountId(@NotBlank final String accountId) {

		this.accountId = accountId;
	}

}
