package com.teixon.cms.mediahub.property.dto;

import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * property value management entity
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "property_tbl")
public class PropertyEntity {

	/**
	 * property key id
	 */
	@EmbeddedId
	private final PropertyId propertyId;

	/**
	 * property value
	 */
	@Column(name = "prop_value", nullable = false, updatable = false, length = ColumnLength.VALUE)
	private String value;

	/** property status */
	@Enumerated(EnumType.STRING)
	@Column(name = "status", nullable = false, length = ColumnLength.STATUS)
	private PropertyStatus status;

	/**
	 * default constructor
	 */
	public PropertyEntity() {

		this.propertyId = new PropertyId();
		this.status = PropertyStatus.Use;
	}

	/**
	 * @param propertyId
	 * 		set the property id
	 * @param value
	 * 		set the property value
	 */
	public PropertyEntity(@NotNull final PropertyId propertyId, @NotBlank final String value) {

		this.propertyId = propertyId;
		this.value = value;
		this.status = PropertyStatus.Use;
	}

	/**
	 * property status
	 */
	public enum PropertyStatus {
		/**
		 * using property
		 */
		Use,
		/**
		 * not used property
		 */
		NotUsed,
	}

	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @return the property key id {@link PropertyId}
	 */
	public PropertyId getPropertyId() {

		return propertyId;
	}

	/**
	 * @return the property value
	 */
	public String getValue() {

		return value;
	}

	/**
	 * @param value
	 * 		set the property value
	 */
	public void setValue(@NotBlank final String value) {

		this.value = value;
	}

	/**
	 * @return status of the property
	 */
	public PropertyStatus getStatus() {

		return status;
	}

	/**
	 * @param status
	 * 		set status of the property
	 */
	public void setStatus(@NotNull final PropertyStatus status) {

		this.status = status;
	}

}
