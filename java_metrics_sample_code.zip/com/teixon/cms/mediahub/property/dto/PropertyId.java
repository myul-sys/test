package com.teixon.cms.mediahub.property.dto;

import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * property ID
 */
@Embeddable
public class PropertyId implements Serializable {

	/**
	 * serial version
	 */
	private static final long serialVersionUID = 5186426021708824752L;

	/**
	 * account id
	 */
	@Column(name = "acct_id", nullable = false, updatable = false, length = ColumnLength.UUID)
	private String accountId;

	/**
	 * group code
	 */
	@Column(name = "prop_group_cd", nullable = false, length = ColumnLength.CODE)
	private String groupCode;

	/**
	 * property key
	 */
	@Column(name = "prop_key", nullable = false, updatable = false, length = ColumnLength.CODE)
	private String key;

	/**
	 * default constructor
	 */
	public PropertyId() {

	}

	/**
	 * @param groupId
	 * 		property group id
	 * @param key
	 * 		the property key
	 */
	public PropertyId(@NotNull final PropertyGroupId groupId, final String key) {

		this(groupId.getAccountId(), groupId.getGroupCode(), key);
	}

	/**
	 * @param accountId
	 * 		the properties owner account id
	 * @param groupCode
	 * 		the properties group code
	 * @param key
	 * 		the property key
	 */
	public PropertyId(
			@NotBlank final String accountId, @NotBlank final String groupCode,
			@NotBlank final String key) {

		this.groupCode = groupCode;
		this.accountId = accountId;
		this.key = key;
	}

	@Override
	public boolean equals(final Object o) {

		return EqualsBuilder.reflectionEquals(this, o);
	}

	@Override
	public int hashCode() {

		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @return the owner account id
	 */
	public String getAccountId() {

		return accountId;
	}

	/**
	 * @param accountId
	 * 		set the owner account id
	 */
	public void setAccountId(@NotBlank final String accountId) {

		this.accountId = accountId;
	}

	/**
	 * @return the property key
	 */
	public String getKey() {

		return key;
	}

	/**
	 * @return the properties group code (english only)
	 */
	public String getGroupCode() {

		return groupCode;
	}

	/**
	 * @param groupCode
	 * 		set the properties group code (english only)
	 */
	public void setGroupCode(@NotBlank final String groupCode) {

		this.groupCode = groupCode;
	}

	/**
	 * @param key
	 * 		set the property key
	 */
	public void setKey(@NotBlank final String key) {

		this.key = key;
	}

}
