package com.teixon.cms.mediahub.property.service;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.teixon.cms.mediahub.property.dto.PropertyEntity;
import com.teixon.cms.mediahub.property.dto.PropertyGroupEntity;
import com.teixon.cms.mediahub.property.dto.PropertyGroupId;
import com.teixon.cms.mediahub.property.dto.PropertyId;
import com.teixon.cms.mediahub.property.repository.PropertyGroupRepository;
import com.teixon.cms.mediahub.property.repository.PropertyRepository;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import javax.transaction.Transactional;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

/**
 * properties management service
 */
@Service
public class PropertyService {

	/**
	 * logger handle
	 */
	private final Logger logger = LoggerFactory.getLogger(PropertyService.class);

	/**
	 * group data management repository
	 */
	@Autowired
	private PropertyGroupRepository groupRepo;

	/**
	 * property management repository
	 */
	@Autowired
	private PropertyRepository propRepo;

	/**
	 * properties initialized from json data
	 */
	@Value("${bluecap-lto.init-data.properties:init-data/properties.json}")
	private String initDataPath;

	/**
	 * register new a group
	 *
	 * @param group
	 * 		property group 등록
	 *
	 * @return registered group
	 */
	public PropertyGroupEntity registerGroup(final PropertyGroupEntity group) {

		return groupRepo.saveAndFlush(group);
	}

	/**
	 * register new a property
	 *
	 * @param property
	 * 		a property to registration
	 *
	 * @return new a property
	 */
	public PropertyEntity registerProperty(final PropertyEntity property) {

		logger.debug("register a new property [property = {}]", property);

		final PropertyEntity newProp = Optional.of(property) //
				.filter(prop -> StringUtils.isNotBlank(prop.getValue()))//
				.map(prop -> propRepo.saveAndFlush(prop))//
				.orElseThrow(() -> new RuntimeException("the request for the wrong values"));

		logger.debug("complete to registered a new property [property = {}]", newProp);

		return newProp;
	}

	/**
	 * modify a property
	 *
	 * @param property
	 * 		a property to modify
	 *
	 * @return modified property
	 */
	public PropertyEntity modifyProperty(final PropertyEntity property) {

		return this.modifyProperty(property.getPropertyId(), property);
	}

	/**
	 * modify a property
	 *
	 * @param propertyId
	 * 		the propertyId of the property to be modified
	 * @param property
	 * 		a property to modify
	 *
	 * @return modified property
	 */
	public PropertyEntity modifyProperty(final PropertyId propertyId, final PropertyEntity property) {

		logger.debug("modify a property [propertyId = {}] [property = {}]", propertyId, property);

		Optional.of(property).filter(prop -> StringUtils.isNotBlank(prop.getValue()))//
				.orElseThrow(() -> new RuntimeException("the request for the wrong values"));

		final PropertyEntity modProp = propRepo.findById(property.getPropertyId())//
				.map(prop -> {
					prop.setValue(property.getValue());
					prop.setStatus(property.getStatus());
					return propRepo.saveAndFlush(prop);
				}).orElseThrow(() -> new RuntimeException("can not modified property"));

		logger.debug("complete to modified a property [propertyId = {}] [property = {}]", propertyId,
				property);

		return modProp;
	}

	/**
	 * delete a property
	 *
	 * @param propertyId
	 * 		the propertyId of the property to be deleted
	 *
	 * @return deleted property
	 */
	public PropertyEntity deleteProperty(final PropertyId propertyId) {

		logger.debug("delete a property [propertyId = {}] ", propertyId);

		final PropertyEntity delProp = propRepo.findById(propertyId)//
				.map(prop -> {
					propRepo.deleteById(prop.getPropertyId());
					return prop;
				}).orElseThrow(() -> new RuntimeException("can not deleted property"));

		logger.debug("complete to delete a property [propertyId = {}] [property = {}]", propertyId,
				delProp);

		return delProp;
	}

	/**
	 * get a property
	 *
	 * @param propertyId
	 * 		the propertyId of the property
	 *
	 * @return a property
	 */
	public PropertyEntity getProperty(@NotNull final PropertyId propertyId) {

		return propRepo.findById(propertyId).orElse(null);
	}

	/**
	 * get property list
	 *
	 * @param groupId
	 * 		owner properties group id
	 *
	 * @return property list
	 */
	public List<PropertyEntity> getProperties(@NotNull final PropertyGroupId groupId) {

		return propRepo.list(groupId.getAccountId(), groupId.getGroupCode());
	}

	/**
	 * get a property
	 *
	 * @param accountId
	 * 		owner account id
	 * @param groupCode
	 * 		group code
	 * @param key
	 * 		the key of property
	 *
	 * @return a property
	 */
	public PropertyEntity getProperty(//
			@NotBlank final String accountId, @NotBlank final String groupCode,
			@NotBlank final String key) {

		return this.getProperty(new PropertyId(accountId, groupCode, key));
	}

	/**
	 * get the value of property
	 *
	 * @param propertyId
	 * 		the propertyId of the property
	 *
	 * @return the value of property
	 */
	public String getValue(@NotNull final PropertyId propertyId) {

		final PropertyEntity property = this.getProperty(propertyId);
		return property != null ? property.getValue() : null;
	}

	/**
	 * get the value of property
	 *
	 * @param accountId
	 * 		owner account id
	 * @param groupCode
	 * 		group code
	 * @param key
	 * 		the key of property
	 *
	 * @return the value of property
	 */
	public String getValue(final String accountId, final String groupCode, final String key) {

		return this.getValue(new PropertyId(accountId, groupCode, key));
	}

	/**
	 * get a property group
	 *
	 * @param groupId
	 * 		the groupId of the property group
	 *
	 * @return a property group
	 */
	public PropertyGroupEntity getGroup(@NotNull final PropertyGroupId groupId) {

		return groupRepo.findById(groupId).orElseGet(null);
	}

	/**
	 * get group list
	 *
	 * @param accountId
	 * 		owner account id of the groups
	 *
	 * @return group list
	 */
	public List<PropertyGroupEntity> getGroups(@NotBlank final String accountId) {

		return groupRepo.list(accountId);
	}

	/**
	 * replace source string to property group values
	 *
	 * <pre>
	 *     if properties are [{ key : "ROOT", value : "localRoot"}, { key : "SUB", value : "sub"}]
	 *     replaceString(..., "/{ROOT}/aaa/{SUB}") = "/localRoot/aaa/sub"
	 *     replaceString(..., "/{ROOT}/aaa/{SUB}/{SUB}") = "/localRoot/aaa/sub/sub"
	 * </pre>
	 *
	 * @param groupId
	 * 		properties group id
	 * @param text
	 * 		text to search and replace in, no-op if null
	 *
	 * @return the text with any replacements processed
	 */
	public String replaceString(@NotNull final PropertyGroupId groupId, @NotBlank final String text) {

		final List<PropertyEntity> properties = propRepo
				.list(groupId.getAccountId(), groupId.getGroupCode());
		final Predicate<PropertyEntity> propFilter = prop -> prop.getStatus() == PropertyEntity.PropertyStatus.Use;

		final String[] values = properties.stream().filter(propFilter)//
				.map(PropertyEntity::getValue).toArray(String[]::new);
		final String[] keys = properties.stream().filter(propFilter)//
				.map(prop -> String.format("{%s}", prop.getValue())).toArray(String[]::new);

		return StringUtils.replaceEachRepeatedly(text, keys, values);
	}


	/**
	 * initialize of account properties
	 *
	 * @param accountId
	 * 		account id to initialize
	 */
	@Transactional
	public void initializeOf(final String accountId) {

		logger.debug("initialize to properties [accountId = {}]", accountId);

		final Gson gson = new Gson();

		final List<PropertyGroupEntity> groups;

		// read a file
		try {
			final File jsonFile = ResourceUtils.getFile(initDataPath);

			final String strProp = Files
					.readString(Path.of(jsonFile.getPath()), Charset.defaultCharset());

			final JsonObject jsonObj = gson.fromJson(strProp, JsonObject.class);

			final JsonElement jsonGroups = jsonObj.get("groups");
			groups = gson.fromJson(jsonGroups, //
					new TypeToken<List<PropertyGroupEntity>>() {
					}.getType());

		} catch (final Throwable th) {
			throw new RuntimeException(//
					String.format("can not read a file [init-data.properties = %s]", initDataPath), th);
		}

		try {
			propRepo.deleteAllByPropertyIdAccountId(accountId);
			groupRepo.deleteAllByGroupIdAccountId(accountId);

			// groupRepo.flush();
			groups.forEach(group -> group.getGroupId().setAccountId(accountId));
			groupRepo.saveAll(groups);

		} catch (final Throwable th) {
			throw new RuntimeException(//
					String.format("fail of insert properties [init-data.properties = %s]", initDataPath), th);
		} finally {
			groupRepo.flush();
			propRepo.flush();
		}
		logger.debug("complete initialized to properties [accountId = {}]", accountId);
	}

}
