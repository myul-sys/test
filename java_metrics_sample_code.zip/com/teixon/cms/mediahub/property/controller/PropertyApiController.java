package com.teixon.cms.mediahub.property.controller;


import com.teixon.cms.mediahub.common.api.ApiResult;
import com.teixon.cms.mediahub.property.dto.PropertyEntity;
import com.teixon.cms.mediahub.property.dto.PropertyGroupEntity;
import com.teixon.cms.mediahub.property.dto.PropertyGroupId;
import com.teixon.cms.mediahub.property.dto.PropertyId;
import com.teixon.cms.mediahub.property.repository.PropertyGroupRepository;
import com.teixon.cms.mediahub.property.repository.PropertyRepository;
import com.teixon.cms.mediahub.property.service.PropertyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * the properties management restful API controller
 */
@RestController
@RequestMapping(value = "/api/account/{accountId}/property")
public class PropertyApiController {

	/**
	 * logger handle
	 */
	private final Logger logger = LoggerFactory.getLogger(PropertyApiController.class);

	/**
	 * property management service
	 */
	@Autowired
	private PropertyService propService;

	/**
	 * property group management repository
	 */
	@Autowired
	private PropertyGroupRepository groupRepo;

	/**
	 * property management repository
	 */
	@Autowired
	private PropertyRepository propRepo;

	/**
	 * modify to property group
	 *
	 * @param accountId
	 * 		owned account id
	 * @param groupCode
	 * 		group code
	 * @param group
	 * 		modify group information
	 *
	 * @return modified group
	 */
	@RequestMapping(value = "/group/{groupCode}", method = {
			RequestMethod.PATCH}, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ApiResult<PropertyGroupEntity> patchGroup(
			@PathVariable(value = "accountId") final String accountId, //
			@PathVariable(value = "groupCode") final String groupCode, //
			@RequestBody final PropertyGroupEntity group
	) {

		group.getGroupId().setAccountId(accountId);
		group.getGroupId().setGroupCode(groupCode);

		logger.debug("request to patch a property group [group = {}]", group.getGroupId());

		final PropertyGroupEntity modGroup = groupRepo.findById(group.getGroupId())
				.map(oldGroup -> {

				// propRepo.deleteAllByPropertyIdAccountIdAndPropertyIdGroupCode(accountId, groupCode);
				oldGroup.getProperties().clear();
				oldGroup.getProperties().addAll(group.getProperties());

			return groupRepo.saveAndFlush(oldGroup);
		}).orElseThrow(() ->
				new RuntimeException(String.format("not found groupId : {}", group.getGroupId())));

		logger.debug("complete to patched a property group [group = {}]", modGroup);

		return ApiResult.ofSuccess(modGroup);
	}

	/**
	 * register new property
	 *
	 * @param accountId
	 * 		owner account id
	 * @param groupCode
	 * 		property group code
	 * @param property
	 * 		a property requested to registration
	 *
	 * @return new a property registered {@link PropertyEntity}
	 */
	@PostMapping(value = "/group/{groupCode}", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ApiResult<PropertyEntity> post(//
			@PathVariable(value = "accountId") final String accountId, //
			@PathVariable(value = "groupCode") final String groupCode, //
			@RequestBody final PropertyEntity property) {

		property.getPropertyId().setAccountId(accountId);
		property.getPropertyId().setGroupCode(groupCode);

		logger.debug("request to register a new property [accountId={}] [property = {}]", accountId,
				property);

		final PropertyEntity newProp = propService.registerProperty(property);

		logger.debug("complete to register a new property [accountId={}] [property = {}]", accountId,
				newProp);

		return ApiResult.ofSuccess(newProp);
	}


	/**
	 * modify a property
	 *
	 * @param accountId
	 * 		owner account id
	 * @param groupCode
	 * 		property group code
	 * @param key
	 * 		property key
	 * @param property
	 * 		a property requested to be modification
	 *
	 * @return modified a property {@link PropertyEntity}
	 */
	@RequestMapping(value = "/group/{groupCode}/key/{key}",
	                method = {RequestMethod.PATCH},
	                consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ApiResult<PropertyEntity> patch(//
			@PathVariable(value = "accountId") final String accountId, //
			@PathVariable(value = "groupCode") final String groupCode, //
			@PathVariable(value = "key") final String key, //
			@RequestBody final PropertyEntity property) {

		property.getPropertyId().setAccountId(accountId);
		property.getPropertyId().setGroupCode(groupCode);
		property.getPropertyId().setKey(key);

		logger
				.debug("request to modify a property [accountId={}] [property = {}]", accountId, property);

		final PropertyEntity modProp = propService.modifyProperty(property);

		logger
				.debug("complete to modify a property [accountId={}] [property = {}]", accountId, modProp);

		return ApiResult.ofSuccess(modProp);

	}

	/**
	 * delete a property
	 *
	 * @param accountId
	 * 		owner account id
	 * @param groupCode
	 * 		property group code
	 * @param key
	 * 		property key
	 *
	 * @return new a property registered {@link PropertyEntity}
	 */
	@RequestMapping(value = "/group/{groupCode}/key/{key}",
	                method = {RequestMethod.DELETE},
	                consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ApiResult<PropertyEntity> delete(//
			@PathVariable(value = "accountId") final String accountId, //
			@PathVariable(value = "groupCode") final String groupCode, //
			@PathVariable(value = "key") final String key) {

		final PropertyId propId = new PropertyId(accountId, groupCode, key);
		logger.debug("request to delete a property [propertyId = {}]", propId);

		final PropertyEntity delProp = propService
				.deleteProperty(new PropertyId(accountId, groupCode, key));

		logger
				.debug("complete to delete a property [propertyId = {}] [property = {}]", propId, delProp);

		return ApiResult.ofSuccess(delProp);
	}

	/**
	 * Get a list of property group
	 *
	 * @param accountId
	 * 		owner account id
	 *
	 * @return property group list
	 */
	@GetMapping(value = "/group/list", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ApiResult<List<PropertyGroupEntity>> groupList(
			@PathVariable(value = "accountId") final String accountId) {

		logger.debug("group test ==> [acctId={}]", accountId);

		return ApiResult.ofSuccess(propService.getGroups(accountId));
	}

	/**
	 * get property list
	 *
	 * @param accountId
	 * 		owner account id
	 * @param groupCode
	 * 		property group code
	 *
	 * @return property list
	 */
	@RequestMapping(value = "/group/{groupCode}/list", method = {
			RequestMethod.GET}, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ApiResult<List<PropertyEntity>> propertyList(//
			@PathVariable(value = "accountId") final String accountId, //
			@PathVariable(value = "groupCode") final String groupCode) {

		return ApiResult
				.ofSuccess(propService.getProperties(new PropertyGroupId(accountId, groupCode)));
	}


	/**
	 * override properties init-dataa
	 *
	 * @param accountId
	 * 		account id
	 *
	 * @return 0 is success. or else failed.
	 */
	@RequestMapping(value = "/init", method = {RequestMethod.PUT}, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ApiResult<Integer> initProperties(//
			@PathVariable(value = "accountId") final String accountId
	) {

		final ApiResult<Integer> result = new ApiResult<>();
		try {
			propService.initializeOf(accountId);
			result.setData(0);
		} catch (final Throwable th) {
			logger.error("can not initialized properties", th);
			result.setMessage(th.getMessage());
			result.setData(-1);
		}

		return result;
	}

}
