package com.teixon.cms.mediahub.device.repository;

import com.teixon.cms.mediahub.channel.dto.ChannelHistoryEntity;
import com.teixon.cms.mediahub.repository.department.DepartmentResultEntity;
import com.teixon.cms.mediahub.repository.device.*;
import com.teixon.cms.mediahub.repository.event.EventEntity;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.*;

/**
 * search for Device list repository
 */
@Repository(value = "DeviceRepository")
public class DeviceRepositoryImpl implements DeviceFindRepository {

    /** entity manager */
    @Autowired
    private EntityManager em;

    /** log handle */
    private Logger logger = LoggerFactory.getLogger(DeviceRepositoryImpl.class);

    @Override
    public DeviceList findList(DeviceFindCondition condition) {

        logger.debug("findList [condition = {}]", condition);

        final CriteriaBuilder cb = em.getCriteriaBuilder();
        final CriteriaQuery<DeviceEntity> cqSelect = cb.createQuery(DeviceEntity.class);
        final Root<DeviceEntity> selectRoot = cqSelect.from(DeviceEntity.class);

        cqSelect.select(selectRoot);
        cqSelect.where(getPredicates(selectRoot, condition));
        cqSelect.orderBy(cb.desc(selectRoot.get("registerDate")));

        if(condition.getKeywordType() != null && ( condition.getKeywordType().equals("ownerDepartment") || condition.getKeywordType().toLowerCase().equals("all"))) {
            Join<ChannelHistoryEntity, DepartmentResultEntity> join = selectRoot.join("ownerDepartmentInfo", JoinType.LEFT);
        }

        final TypedQuery<DeviceEntity> querySelect = this.em.createQuery(cqSelect);
        querySelect.setFirstResult((int) condition.getOffset());
        querySelect.setMaxResults(condition.getPageSize());

        final List<DeviceEntity> list = querySelect.getResultList();
        final Long totalCount = countList(condition);

        return new DeviceList(new ArrayList(list), totalCount, condition.getOffset(), condition.getPageSize());
    }

    @Override
    public Long countList(DeviceFindCondition condition) {

        logger.debug("countList [condition = {}]", condition);

        final CriteriaBuilder cb = this.em.getCriteriaBuilder();
        final CriteriaQuery<Long> cqCount = cb.createQuery(Long.class);
        final Root<DeviceEntity> countRoot = cqCount.from(DeviceEntity.class);
        if(condition.getKeywordType() != null && ( condition.getKeywordType().equals("ownerDepartment") || condition.getKeywordType().toLowerCase().equals("all"))) {
            Join<ChannelHistoryEntity, DepartmentResultEntity> join = countRoot.join("ownerDepartmentInfo", JoinType.LEFT);
        }

        if(condition.getKeywordType() != null && ( condition.getKeywordType().equals("modelName") || condition.getKeywordType().toLowerCase().equals("all"))) {
            Join<ChannelHistoryEntity, DeviceModelResultEntity> join = countRoot.join("model", JoinType.LEFT);
        }

        if(condition.getKeywordType() != null && ( condition.getKeywordType().equals("manufacturerName") || condition.getKeywordType().toLowerCase().equals("all"))) {
            Join<ChannelHistoryEntity, DeviceManufacturerResultEntity> join = countRoot.join("manufacturer", JoinType.LEFT);
        }

        // count query
        cqCount.select(cb.count(countRoot));
        cqCount.where(getPredicates(countRoot, condition));

        return this.em.createQuery(cqCount).getSingleResult();
    }


    private Predicate[] getPredicates(
            Root<DeviceEntity> root,
            DeviceFindCondition condition) {

        final CriteriaBuilder cb = this.em.getCriteriaBuilder();
        final List<Predicate> predicates = new ArrayList<>();

        predicates.add(cb.and(cb.equal(root.get("accountId"), condition.getAccountId())));

        // check statues
        Optional.ofNullable(condition.getFindStatuses()) //
                .filter(statuses -> statuses != null && statuses.size() > 0)//
                .ifPresent(statuses -> {
                    predicates.add(cb.and(root.get("status").in(statuses)));
                });

        Optional.of(condition.getDateRange())
                .filter(range -> !range.isEmpty())
                .ifPresent(range -> {
                    Date to = range.getTo();
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(to);

                    cal.add(Calendar.DATE, 1);
                    cal.add(Calendar.MILLISECOND, -1);

                    final Predicate p = cb.between(root.get("registerDate"), range.getFrom() , cal.getTime());
                    predicates.add(p);
                });
        // keyword
        Optional.ofNullable(condition.getKeyword()) //
                .filter(keyword -> !keyword.equals("null") && !StringUtils.trimToEmpty(keyword).isBlank()) //
                .ifPresent(keyword -> {
                    if(condition.getKeywordType() == null || condition.getKeywordType().toLowerCase().equals("all"))
                        condition.setKeywordType("all");

                    switch(condition.getKeywordType()){
                        case "manufacturerName":
                            final Predicate p4 = cb.and(//
                                    cb.or(//
                                            cb.like(root.get("manufacturer").get("name"), String.format("%%%s%%", keyword)) //
                                    ));
                            predicates.add(p4);
                            break;
                        case "modelName":
                            final Predicate p5 = cb.and(//
                                    cb.or(//
                                            cb.like(root.get("model").get("name"), String.format("%%%s%%", keyword)) //
                                    ));
                            predicates.add(p5);
                            break;
                        case "deviceId":
                        case "serial":
                        case "deviceName":
                        case "ownerName":
                            final Predicate p = cb.and(//
                                    cb.or(//
                                            cb.like(root.get(condition.getKeywordType()), String.format("%%%s%%", keyword)) //
                                    ));
                            predicates.add(p);
                            break;
                        case "ownerDepartment":
                            final Predicate p3 = cb.and(//
                                    cb.or(//
                                            cb.like(root.get("ownerDepartmentInfo").get("name"), String.format("%%%s%%", keyword)) //
                                    ));
                            predicates.add(p3);
                            break;
                        case "all":
                            final Predicate p2 = cb.and(//
                                    cb.or(//
                                            cb.like(root.get("deviceId"), String.format("%%%s%%", keyword)), //
                                            cb.like(root.get("serial"), String.format("%%%s%%", keyword)), //
                                            cb.like(root.get("manufacturer").get("name"), String.format("%%%s%%", keyword)), //
                                            cb.like(root.get("model").get("name"), String.format("%%%s%%", keyword)), //
                                            cb.like(root.get("deviceName"), String.format("%%%s%%", keyword)), //
                                            cb.like(root.get("ownerDepartmentInfo").get("name"), String.format("%%%s%%", keyword)),
                                            cb.like(root.get("ownerName"), String.format("%%%s%%", keyword))
                                    ));
                            predicates.add(p2);
                            break;
                    }
                });

        return predicates.toArray(new Predicate[]{});
    }

}
