package com.teixon.cms.mediahub.device.repository;

import com.teixon.cms.mediahub.repository.device.DeviceManufacturerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface DeviceManufacturerRepository extends JpaRepository<DeviceManufacturerEntity, String> {

    /**
     * list Device Manufacturer
     *
     * @param deviceManufacturerId
     * 		deviceManufacturerId
     * @return list device Manufacturer a info
     */
    @Query("select dmf from DeviceManufacturerEntity as dmf where dmf.deviceManufacturerId = :deviceManufacturerId")
    Optional<DeviceManufacturerEntity> findByDeviceManufacturerId( @Param("deviceManufacturerId") String deviceManufacturerId);

    /**
     * list Device Manufacturer
     *
     * @param type
     * 		type
     *
     * @return list device Manufacturer a info
     */
    @Query("select dmf from DeviceManufacturerEntity as dmf where dmf.type = :type ")
    Optional<List<DeviceManufacturerEntity>> findListByType(@Param("type") DeviceManufacturerEntity.ManufacturerType type);

}
