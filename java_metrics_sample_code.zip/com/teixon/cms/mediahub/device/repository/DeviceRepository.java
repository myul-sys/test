package com.teixon.cms.mediahub.device.repository;


import com.teixon.cms.mediahub.repository.device.DeviceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface DeviceRepository extends JpaRepository<DeviceEntity, String>, DeviceFindRepository {


    /**
     * check serial
     *
     * @param serial
     * 		serial
     *
     * @return device a info
     */
    @Query("select count(dr) from DeviceEntity as dr where dr.serial = :serial ")
    Optional<Integer> countBySerial(@Param("serial") String serial);


    /**
     * check serial
     *
     * @param serial
     * 		serial
     *
     * @return device a info
     */
    @Query("select dr from DeviceEntity as dr where dr.serial = :serial ")
    Optional<DeviceEntity> findBySerial(@Param("serial") String serial);

    /**
     * get image byte array
     *
     * @param accountId
     * 		accountId
     * @param deviceId
     * 		deviceId
     *
     * @return get image byte array
     */
    @Query("select dr from DeviceEntity as dr where dr.accountId = :accountId AND dr.deviceId = :deviceId ")
    Optional<DeviceEntity> findByImage(@Param("accountId") String accountId, @Param("deviceId") String deviceId);

}
