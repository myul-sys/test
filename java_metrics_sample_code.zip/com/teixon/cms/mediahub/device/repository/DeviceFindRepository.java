package com.teixon.cms.mediahub.device.repository;

import com.teixon.cms.mediahub.repository.device.DeviceFindCondition;
import com.teixon.cms.mediahub.repository.device.DeviceList;

public interface DeviceFindRepository {

    /**
     * search for device list
     *
     * @param condition
     * 		search for conditions
     *
     * @return selected device list
     */
    DeviceList findList(final DeviceFindCondition condition);

    /**
     * count for conditions
     *
     * @param condition
     * 		search for conditions
     *
     * @return selected device count
     */
    Long countList(DeviceFindCondition condition);
}
