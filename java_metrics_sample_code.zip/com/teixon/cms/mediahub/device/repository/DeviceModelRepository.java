package com.teixon.cms.mediahub.device.repository;

import com.teixon.cms.mediahub.repository.device.DeviceModelEntity;
import com.teixon.cms.mediahub.repository.device.DeviceModelId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DeviceModelRepository extends JpaRepository<DeviceModelEntity, DeviceModelId> {

    Optional<List<DeviceModelEntity>> findByDeviceModelId_DeviceManufacturerId(String deviceManufacturerId);

}
