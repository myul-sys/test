package com.teixon.cms.mediahub.user.repository;


import com.teixon.cms.mediahub.user.dto.UserFindCondition;
import com.teixon.cms.mediahub.user.dto.UserList;

/**
 * user find functions
 *
 * @author matin
 **/
public interface UserFindRepository {

	/**
	 * 사용자 목록을 조회한다
	 *
	 * @param condition
	 * 		사용자 목록 조회 조건
	 *
	 * @return 사용자 목록
	 */
	UserList findByList(UserFindCondition condition);

	/**
	 * 사용자 목록의 갯수를 가져온다
	 *
	 * @param condition
	 * 		사용자 목록 조회 조건
	 *
	 * @return 사용자 목록 총 갯수
	 */
	Long countByList(final UserFindCondition condition);

}
