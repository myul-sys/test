package com.teixon.cms.mediahub.user.repository;

import com.teixon.cms.mediahub.user.dto.UserEntity;
import com.teixon.cms.mediahub.user.dto.UserEntity.UserStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.Set;

/**
 * user entity management repository
 *
 * @author matin
 */
public interface UserRepository extends JpaRepository<UserEntity, String>, UserFindRepository {

	/**
	 * get a user detail
	 *
	 * @param accountId
	 * 		account id
	 * @param userId
	 * 		user id
	 *
	 * @return user detail {@link UserEntity}
	 */
	@Query(value = //
			       "SELECT u FROM UserEntity u WHERE u.accountId = :accountId AND u.userId = :userId ")
	Optional<UserEntity> findByUserId(
			@Param("accountId") String accountId,
			@Param("userId") String userId);

	/**
	 * find by login id and status user detail
	 *
	 * @param accountId
	 * 		acount id
	 * @param loginId
	 * 		login id
	 *
	 * @return {@link UserEntity}
	 */
	@Query(value = //
			       "SELECT u FROM UserEntity u " + //
					       "WHERE u.accountId = :accountId AND u.loginId = :loginId AND u.isDeleteStatus = :isDeleteStatus")
	Optional<UserEntity> findByLoginId(
			@Param("accountId") String accountId, //
			@Param("loginId") String loginId, //
			@Param("isDeleteStatus") Boolean isDeleteStatus); //

	/**
	 * count by lgoin id and statuses
	 *
	 * @param loginId
	 * 		login id
	 * @param statuses
	 * 		include statuses
	 *
	 * @return count of UserEntity list {@link UserEntity}
	 */
	@Query(value = //
			"SELECT COUNT(u) FROM UserEntity u " + //
					"WHERE u.accountId = :accountId and u.loginId = :loginId and u.status in :statuses")
	int countByLoginId(
			@Param("accountId") String accountId,
			@Param("loginId") String loginId, //
			@Param("statuses") Set<UserStatus> statuses);

	/**
	 * find by lgoin id and statuses
	 *
	 * @param name
	 * 		name
	 * @param status
	 * 		include statuses
	 *
	 * @return count of UserEntity list {@link UserEntity}
	 */
	@Query(value = //
			"SELECT u FROM UserEntity u " + //
					"WHERE u.accountId = :accountId and u.name = :name and u.status in :status")
	Optional<UserEntity> findByUserName(
			@Param("accountId") String accountId,
			@Param("name") String name, //
			@Param("status") Set<UserStatus> status);

	/**
	 * find by login id and status user detail
	 *
	 * @param loginId
	 * 		login id
	 * @param statuses
	 * 		user statuses
	 *
	 * @return {@link UserEntity}
	 */
	@Query(value = //
			"SELECT u FROM UserEntity u " + //
					"WHERE u.accountId = :accountId and u.loginId = :loginId and u.status in :statuses")
	Optional<UserEntity> findByUserPw(
			@Param("accountId") String accountId,//
			@Param("loginId") String loginId, //
			@Param("statuses") Set<UserStatus> statuses);


}
