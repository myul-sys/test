package com.teixon.cms.mediahub.user.repository;

import com.teixon.cms.mediahub.user.dto.UserEntity;
import com.teixon.cms.mediahub.user.dto.UserFindCondition;
import com.teixon.cms.mediahub.user.dto.UserList;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.*;

/**
 * 사용자 목록을 조회 한다
 *
 * @author matin
 **/
@Repository(value = "UserRepository")
public class UserRepositoryImpl implements UserFindRepository {

    /**
     * entity manager
     */
    @Autowired
    private EntityManager em;

    /**
     * 로그 핸들
     */
    private final Logger logger = LoggerFactory.getLogger(UserRepositoryImpl.class);

    @Override
    public UserList findByList(final UserFindCondition condition) {

        logger.debug("findByList [condition = {}]", condition);

        // make query
        final CriteriaBuilder cb = this.em.getCriteriaBuilder();
        final CriteriaQuery<UserEntity> cqSelect = cb.createQuery(UserEntity.class);
        final Root<UserEntity> selectRoot = cqSelect.from(UserEntity.class);

        cqSelect.select(selectRoot);
        cqSelect.where(getPredicates(selectRoot, condition));
        cqSelect.orderBy(cb.desc(selectRoot.get("registerDate")));

        final TypedQuery<UserEntity> querySelect = this.em.createQuery(cqSelect);

        querySelect.setFirstResult((int) condition.getOffset());
        querySelect.setMaxResults(condition.getPageSize());

        final List<UserEntity> list = querySelect.getResultList();
        final Long totalCount = countByList(condition);

        return new UserList(list, totalCount, condition.getOffset(), condition.getPageSize());
    }


    @Override
    public Long countByList(final UserFindCondition condition) {

        logger.debug("countByList [condition = {}]", condition);

        final CriteriaBuilder cb = this.em.getCriteriaBuilder();
        final CriteriaQuery<Long> cqCount = cb.createQuery(Long.class);
        final Root<UserEntity> countRoot = cqCount.from(UserEntity.class);

        // count query
        cqCount.select(cb.count(countRoot));
        cqCount.where(getPredicates(countRoot, condition));

        return this.em.createQuery(cqCount).getSingleResult();
    }

    /**
     * 검색 조건을 생성 한다
     *
     * @param root      UserEntity root
     * @param condition 조건
     * @return 검색 조건 목록
     */
    private Predicate[] getPredicates(
            final Root<UserEntity> root,
            final UserFindCondition condition) {

        logger.debug("getPredicates [condition = {}]", condition);

        final CriteriaBuilder cb = this.em.getCriteriaBuilder();
        final List<Predicate> predicates = new ArrayList<>();

        // 검색자가 accountId 없으면 검색 안됨
        predicates.add(cb.and(cb.equal(root.get("accountId"), condition.getAccountId())));

        // excepted delete user
        predicates.add(cb.and(cb.notEqual(root.get("status"), UserEntity.UserStatus.Delete)));



        Optional.ofNullable(condition.departmentId).ifPresent(
            departmentId -> {
                predicates.add(cb.and(cb.equal(root.get("departmentId"), condition.departmentId)));
            }
        );

        //등록일 검색
        Optional.of(condition.dateRange)
            .filter(range -> !range.isEmpty())
            .ifPresent(range -> {
                Date to = range.getTo();
                Calendar cal = Calendar.getInstance();
                cal.setTime(to);

                cal.add(Calendar.DATE, 1);
                cal.add(Calendar.MILLISECOND, -1);
                final Predicate p = cb.between(root.get("registerDate"), range.getFrom(), cal.getTime());
                predicates.add(p);
            });


        // keyword
        Optional.ofNullable(condition.keyword) //
            .filter(keyword -> !keyword.equals("null") && !StringUtils.trimToEmpty(keyword).isBlank()) //
            .ifPresent(keyword -> {
                if (condition.keywordType == null || condition.keywordType.toLowerCase().equals("all"))
                    condition.keywordType = "all";

                switch (condition.keywordType) {
                    case "loginId":
                    case "userId":
                    case "name":
                    case "ownerWork":
                    case "phone":
                        final Predicate p = cb.and(//
                                cb.or(//
                                        cb.like(root.get(condition.keywordType), String.format("%%%s%%", keyword)) //
                                ));
                        predicates.add(p);
                        break;
                    case "all":
                        final Predicate p2 = cb.and(//
                                cb.or(//
                                        cb.like(root.get("loginId"), String.format("%%%s%%", keyword)), //
                                        cb.like(root.get("userId"), String.format("%%%s%%", keyword)), //
                                        cb.like(root.get("name"), String.format("%%%s%%", keyword)), //
                                        cb.like(root.get("ownerWork"), String.format("%%%s%%", keyword)), //
                                        cb.like(root.get("departmentInfo").get("name"), String.format("%%%s%%", keyword)),
                                        cb.like(root.get("phone"), String.format("%%%s%%", keyword)) //
                                ));
                        predicates.add(p2);
                        break;

                    case "departmentName":
                        final Predicate p3 = cb.and(//
                                cb.or(//
                                        cb.like(root.get("departmentInfo").get("name"), String.format("%%%s%%", keyword)) //
                                ));
                        predicates.add(p3);
                        break;

                    case "departmentId":
                        predicates.add(cb.and(cb.equal(root.get("departmentId"), keyword)));
                        break;

                }
            });

        // check types
        Optional.ofNullable(condition.findUserTypes)//
                .filter(types -> types != null && types.size() > 0)//
                .ifPresent(types -> {
                    predicates.add(cb.and(root.get("userType").in(types)));
                });

        // check statues
        Optional.ofNullable(condition.findStatuses) //
                .filter(statuses -> statuses != null && statuses.size() > 0)//
                .ifPresent(statuses -> {
                    predicates.add(cb.and(root.get("status").in(statuses)));
                });

		/*Optional.ofNullable(condition.getKeyword()) //
				.filter(keyword -> !StringUtils.trimToEmpty(keyword).isBlank()) //
				.ifPresent(keyword -> {
					final Predicate p = cb.and(//
							cb.or(//
									cb.like(root.get("name"), String.format("%%%s%%", keyword)), //
									cb.like(root.get("loginId"), String.format("%%%s%%", keyword))//
							));
					predicates.add(p);
				});
		*/
        //check Date
        Optional.ofNullable(condition.lastDate)
                .filter(lastDate -> lastDate != null) //
                .ifPresent(lastDate -> {
                    final Predicate p = cb.and(
                            cb.lessThanOrEqualTo(root.get("loginDate"), lastDate)
                    );
                    predicates.add(p);
                });

        return predicates.toArray(new Predicate[predicates.size()]);
    }

}