package com.teixon.cms.mediahub.user.dto;

import com.teixon.cms.mediahub.common.data.EntityList;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

/**
 * 사용자 목록
 *
 * @author matin
 **/
public class UserList extends EntityList<UserEntity> {

	/**
	 * @param content
	 * 		entity list
	 * @param total
	 * 		total count
	 * @param firstResult
	 * 		index of first item
	 * @param maxResult
	 * 		page size
	 */
	public UserList(
			final List<UserEntity> content, final Long total, final Long firstResult,
			final Integer maxResult) {

		super(content, total, firstResult, maxResult);
	}

	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}

}
