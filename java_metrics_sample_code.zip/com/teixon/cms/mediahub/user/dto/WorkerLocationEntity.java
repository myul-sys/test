package com.teixon.cms.mediahub.user.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;


/**
 * 사용자 위치 정보
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "worker_loc_tbl")
@IdClass(WorkerLocationKey.class)
public class WorkerLocationEntity {

	/** 작업자 아이디 */
	@Id
	@Column(name = "worker_id", nullable = false, updatable = false, length = ColumnLength.UUID)
	public String workerId;

	/** 순서 */
	@Id
	@Column(name = "idx", nullable = false, updatable = false)
	public Integer index;

	/** 위치 시간 */
	@CreatedDate
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	@Column(name = "time", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	public Date time;

	/** account id */
	public String accountId;

	/** 위도 */
	public Double lat;

	/** 경도 */
	public Double lng;

	/**
	 * 현장 아아디
	 */
	public String eventId;


	@JsonIgnore
	@OneToOne
	@JoinColumn(
			name = "worker_id", referencedColumnName = "worker_id", insertable = false, updatable = false, nullable = true,
			foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT)
	)
	public WorkerEntity worker;

	@Transient
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	public WorkerEntity.WorkerType workerType;

	public WorkerEntity.WorkerType getWorkerType() {
		if(worker == null)
			return null;
		else
			return worker.workerType;
	}

	public WorkerLocationEntity() {

		this.index = 0;
		this.time = new Date();
	}

	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}

}
