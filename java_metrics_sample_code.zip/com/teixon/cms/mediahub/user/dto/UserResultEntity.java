package com.teixon.cms.mediahub.user.dto;

import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import com.teixon.cms.mediahub.repository.department.DepartmentResultEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
/**
 * user information entity
 *
 * @author matin
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "user_tbl")
public class UserResultEntity {

	/**
	 * user id
	 */
	@Id
	@Column(name = "user_id", nullable = false, updatable = false, length = ColumnLength.UUID)
	@GenericGenerator(name = "user_id_uuid", strategy = "com.teixon.cms.mediahub.common.jpa.id.CountGenerator")
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "user_id_uuid")
	private String userId;

	/**
	 * user name
	 */
	@Column(name = "user_nm", nullable = false, length = ColumnLength.NAME)
	private String name;

	/**
	 * user phone
	 */
	@Column(name = "user_ph", nullable = false, length = 100)
	public String phone;

	/**
	 * user department
	 */
	@Column(name = "user_department_id", nullable = false, length = 100)
	public String departmentId;

	/** owner department  */
	@OneToOne
	@JoinColumn(
			name = "user_department_id",
			referencedColumnName = "dept_id",
			insertable = false,
			updatable = false,
			foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT)
	)
	public DepartmentResultEntity departmentInfo = null;

	/**
	 * user ownerWork(담당업무)
	 */
	@Column(name = "user_work", nullable = true, length = 100)
	public String ownerWork;


	/**
	 * constructor
	 */
	public UserResultEntity() {

	}


	/**
	 * @return user id
	 */
	public String getUserId() {

		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}




	/**
	 * @return user name
	 */
	public String getName() {

		return name;
	}

	/**
	 * @param name
	 * 		user name
	 */
	public void setName(@NotBlank final String name) {

		this.name = name;
	}

	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}
}
