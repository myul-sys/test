package com.teixon.cms.mediahub.user.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import com.teixon.cms.mediahub.repository.department.DepartmentResultEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

/**
 * 작업자 정보를 관리 한다
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "worker_tbl")
public class WorkerEntity {

	/** 작업자 id */
	@Id
	@Column(name = "worker_id", nullable = false, updatable = false, length = ColumnLength.UUID)
	@GenericGenerator(name = "worker_id_uuid", strategy = "com.teixon.cms.mediahub.common.jpa.id.UUIDGenerator")
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "worker_id_uuid")
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	public String worker_id;


	@Column(name = "token", nullable = false, updatable = false, length = ColumnLength.VALUE)
	public String token;

	/** 계정 아이디 */
	@Column(name = "acct_id", nullable = false, updatable = false, length = ColumnLength.UUID)
	public String accountId;

	/** 현장 id */
	@Column(name = "event_id", nullable = true, updatable = true, length = ColumnLength.UUID)
	public String eventId;

	/** 사용자 아이디 */
	@Column(name = "user_id", nullable = true, updatable = false, length = ColumnLength.UUID)
	public String userId;


	/** owner user */
	/*@Transient
	@OneToOne
	@JoinColumn(
			name = "user_id",
			referencedColumnName = "user_id",
			insertable = false,
			updatable = false,
			foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT)
	)
	public UserEntity userInfo = null;*/

	@Enumerated(EnumType.STRING)
	@Column(name = "user_type", nullable = true, length = 100)
	public UserEntity.UserType userType;

	/*public UserEntity.UserType getUserType() {
		if(userInfo == null)
			return null;
		else
			return userInfo.getUserType();
	}*/

	/** 사용자 아이디  */
	@Column(name = "login_id", nullable = true, updatable = false, length = ColumnLength.UUID)
	public String loginId;

	/** 이름 */
	@Column(name = "user_nm", nullable = true, updatable = false, length = ColumnLength.NAME)
	public String name;

	/** 연락처 */
	@Column(name = "mobile_num", nullable = true, updatable = false, length = ColumnLength.MOBILE_NUM)
	public String mobileNumber;

	/**
	 * 소속
	 */
	@Column(name = "worker_department_Id", length = 100)
	public String departmentId;

	/** owner department */
	@OneToOne
	@JoinColumn(
			name = "worker_department_Id",
			referencedColumnName = "dept_id",
			insertable = false,
			updatable = false,
			foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT)
	)
	public DepartmentResultEntity departmentInfo = null;

	@Transient
	public String deptInfoName = null;

	public String getDeptInfoName() {
		if(departmentInfo == null)
			return null;
		else
			return departmentInfo.getName();
	}


	/**
	 * 소속
	 */
	@Column(name = "worker_department_name", length = 100)
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	public String deptName;

	@JsonProperty(value = "departmentName")
	public String getDepartmentName() {
		if(deptInfoName == null)
			return deptName;
		else
			return deptInfoName;
	}


	/**
	 * user status
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "status", nullable = false, length = 100)
	public UserEntity.UserStatus status;

	/** 로그인한 날자 */
	@CreatedDate
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	@Column(name = "login_dt", nullable = false)
	public Date loginDate;

	/** 로그아웃 날자 */
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	@Column(name = "logout_dt", nullable = true)
	public Date logoutDate;

	/** 마지막 작업 요청일자 */
	@UpdateTimestamp
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	@Column(name = "last_req_dt", nullable = true)
	public Date lassRequestDate;


	@Enumerated(EnumType.STRING)
	@Column(name = "type", nullable = false, length = ColumnLength.CODE)
	public WorkerType workerType = WorkerType.Guest;

	@Enumerated(EnumType.STRING)
	@Column(name = "device", nullable = false, length = ColumnLength.CODE)
	public ConnectionDevice device = ConnectionDevice.Web;


	/*@Transient
	public UserEntity userInfo = null;
*/
	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}


	/** 작업자 유형 */
	public enum WorkerType {
		/** 드론 조종사 */
		Controller,

		/** 일반 작업자 */
		Worker,

		/** 현장 관리자 */
		Manager,

		/** 게스트 */
		Guest,
	}


	public enum ConnectionDevice {
		ControllerApp,
		ViewApp,
		Web
	}

}