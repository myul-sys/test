package com.teixon.cms.mediahub.user.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.Objects;

public class WorkerLocationKey implements Serializable {


	private static final long serialVersionUID = 1036175104258965855L;

	/** worker id */
	public String workerId;

	/** sort index */
	public Integer index;


	@Override
	public boolean equals(final Object o) {

		return EqualsBuilder.reflectionEquals(this, o);
	}

	@Override
	public int hashCode() {

		return Objects.hash(workerId, index);
	}

	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}

}
