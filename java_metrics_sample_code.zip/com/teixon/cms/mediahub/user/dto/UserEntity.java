package com.teixon.cms.mediahub.user.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import com.teixon.cms.mediahub.repository.department.DepartmentResultEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * user information entity
 *
 * @author matin
 */
@Entity
@EntityListeners(value = {AuditingEntityListener.class})
@Table(name = "user_tbl")
public class UserEntity {

	/**
	 * account id
	 */
	@Column(name = "acct_id", nullable = false, updatable = false, length = ColumnLength.UUID)
	private String accountId;

	/**
	 * user id
	 */
	@Id
	@Column(name = "user_id", nullable = false, updatable = false, length = ColumnLength.UUID)
	@GenericGenerator(name = "user_id_uuid", strategy = "com.teixon.cms.mediahub.common.jpa.id.CountGenerator")
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "user_id_uuid")
	private String userId;

	/**
	 * user login id(email)
	 */
	@Column(name = "user_login_id", nullable = false, updatable = false, length = ColumnLength.LOGIN_ID)
	private String loginId;

	/**
	 * user login password
	 */
	@Column(name = "user_pwd", nullable = false, length = ColumnLength.PASSWORD)
	//@JsonProperty(value = "password", access = JsonProperty.Access.WRITE_ONLY)
	@SerializedName("password")
	private String password;

	/**
	 * user name
	 */
	@Column(name = "user_nm", nullable = false, length = ColumnLength.NAME)
	private String name;

	/**
	 * user phone
	 */
	@Column(name = "user_ph", nullable = false, length = 100)
	public String phone;

	/**
	 * user department
	 */
	@Column(name = "user_department_id", nullable = false, length = 100)
	public String departmentId;

	/** owner department  */
	@OneToOne
	@JoinColumn(
			name = "user_department_id",
			referencedColumnName = "dept_id",
			insertable = false,
			updatable = false,
			foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT)
	)
	public DepartmentResultEntity departmentInfo = null;

	/**
	 * user ownerWork(담당업무)
	 */
	@Column(name = "user_work", nullable = true, length = 100)
	public String ownerWork;


	/**
	 * user added date(등록일자)
	 */
	@CreatedDate
	@Column(name = "reg_dt", nullable = false)
	public Date registerDate;


	/**
	 * user added user id
	 */
	@Column(name = "reg_user_id", nullable = true)
	public String registerUserId;

	/**
	 * user added user info
	 */
	@JsonIgnore
	@OneToOne
	@JoinColumn(
			name = "reg_user_id", referencedColumnName = "user_id", insertable = false, updatable = false, nullable = true,
			foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT)
	)
	private UserEntity registerUser;

	@Transient
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	public String registerUserName;
	public String getRegisterUserName(){
		if(registerUser != null){
			return this.registerUser.name;
		}
		return null;
	}

	/**
	 * 수정일자
	 */
	@Column(name = "mod_dt", nullable = true)
	public String modDate;

	/**
	 * 최근 접속일
	 */
	@Column(name = "login_dt", nullable = true)
	public Date loginDate;


	/**
	 * user type (User or Admin or manager) - 권한
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "user_type", nullable = false, length = 100)
	private UserType userType;

	/**
	 * user status 상태
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "status", nullable = false, length = 100)
	private UserStatus status;


	/**
	 * user status 상태의 상태값
	 */
	@Column(name = "isDelete_status", nullable = true, length = 100)
	public Boolean isDeleteStatus;


	/**
	 * constructor
	 */
	public UserEntity() {

		this.userType = UserType.User;
		this.status = UserStatus.Waiting;
		this.isDeleteStatus = false;
	}

	/**
	 * @return registered date
	 */
	public Date getRegisterDate() {

		return registerDate;
	}

	public void setRegisterDate(Date registerDate) {
		this.registerDate = registerDate;
	}

	/**
	 * @return get user type
	 */
	public UserType getUserType() {

		return userType;
	}

	/**
	 * @param userType
	 * 		set to user type
	 */
	public void setUserType(@NotNull final UserType userType) {

		this.userType = userType;
	}

	/**
	 * @return user status
	 */
	public UserStatus getStatus() {

		return status;
	}

	/**
	 * @param status
	 * 		set to status
	 */
	public void setStatus(@NotNull final UserStatus status) {

		this.status = status;
	}

	public Boolean getisDeleteStatus() {
		return isDeleteStatus;
	}

	public void setisDeleteStatus(Boolean deleteStatus) {
		isDeleteStatus = deleteStatus;
	}

	/**
	 * @return user of acccount id
	 */
	public String getAccountId() {

		return accountId;
	}

	/**
	 * @param accountId
	 * 		set to accountId
	 */
	public void setAccountId(final String accountId) {

		this.accountId = accountId;
	}

	/**
	 * @return user id
	 */
	public String getUserId() {

		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return user id
	 */
	public String getLoginId() {

		return loginId;
	}

	/**
	 * @param loginId
	 * 		user login id
	 */
	public void setLoginId(@NotBlank final String loginId) {

		this.loginId = loginId.trim().toLowerCase();
	}

	/**
	 * @return user login password
	 */
	public String getPassword() {

		return password;
	}

	/**
	 * @param password
	 * 		user login password
	 */
	public void setPassword(@NotBlank final String password) {

		this.password = password;
	}

	/**
	 * @return user name
	 */
	public String getName() {

		return name;
	}

	/**
	 * @param name
	 * 		user name
	 */
	public void setName(@NotBlank final String name) {

		this.name = name;
	}

	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * 사용자 유형
	 */
	public enum UserType {
		/**
		 * 관리자
		 */
		Admin,
		/**
		 * 현장담당자
		 * *//*
		Manager,*/
		/**
		 * 일반 사용자
		 */
		User,
	}

	/**
	 * 사용자 유형
	 */
	public enum IsDeleteStatus {
		/**
		 * 조회 가능하지 않은 상태
		 * */
		True,
		/**
		 * 조회 가능한 상태
		 * */
		False,
	}

	/**
	 * 사용자 상태
	 */
	public enum UserStatus {
		/**
		 * 승인대기
		 */
		Waiting,
		/**
		 * 사용(승인완료)
		 */
		Used,
		/**
		 * 사용안함
		 * (이용정지)
		 */
		NotUsed,
		/**
		 * 휴면
		 */
		Inactive,
		/**
		 * 탈퇴
		 * */
		Unsubscribe,
		/**
		 * 삭제
		 */
		Delete,
	}

}
