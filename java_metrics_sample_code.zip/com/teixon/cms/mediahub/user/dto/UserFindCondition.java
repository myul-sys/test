package com.teixon.cms.mediahub.user.dto;

import com.teixon.cms.mediahub.common.data.BaseCondition;
import com.teixon.cms.mediahub.common.utils.DateRange;
import com.teixon.cms.mediahub.user.dto.UserEntity.UserStatus;
import com.teixon.cms.mediahub.user.dto.UserEntity.UserType;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.validation.constraints.NotBlank;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * condition of user search.
 *
 * @author matin
 **/
public class UserFindCondition extends BaseCondition {

	/**
	 * account id
	 */
	private String accountId;

	/**
	 * user id
	 */
	private String userId;


	/**
	 * department id
	 */
	public String departmentId;

	/**
	 * user keyword
	 */
	public String keyword;

	/** device search keyword type
	 * - 전체 : All
	 * - login ID : login Id
	 * - user ID : user Id
	 * - 이름 : Name
	 * - 담당업무 : ownerWork
	 * - 연락처 : phone
	 */
	public String keywordType;

	/**
	 * user statuses set String parameter
	 */
	private Set<String> statuses;

	/**
	 * user statuses set query
	 */
	public Set<UserStatus> findStatuses;

	/**
	 * user type set String parameter
	 */
	private  Set<String> userTypes;
	/**
	 * user type set query
	 */
	public  Set<UserType> findUserTypes;

	/** 시작일 끝일 */
	public DateRange dateRange;



	/**
	 * 6개월전 로그인 날짜
	 */
	public Date lastDate;


	/**
	 * constructor
	 */
	public UserFindCondition() {
		this(0, Integer.MAX_VALUE);
		dateRange = new DateRange(null,null);
		initStatuses();
		initUserTypes();
	}

	public void initStatuses(){
		this.statuses = new HashSet<String>(Arrays.asList(UserStatus.Used.toString(), UserStatus.Waiting.toString(), UserStatus.Inactive.toString(), UserStatus.NotUsed.toString(),UserStatus.Unsubscribe.toString()));
	}

	public void initUserTypes(){
		this.userTypes =  new HashSet<String>(Arrays.asList(UserType.Admin.toString(), UserType.User.toString()));
	}

	/**
	 * @param pageNumber
	 * 		page number (begin 0)
	 * @param pageSize
	 * 		page size
	 */
	public UserFindCondition(final Integer pageNumber, final Integer pageSize) {
		super(pageNumber, pageSize);
	}

	@Override
	public String toString() {

		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @return account id
	 */
	public String getAccountId() {

		return accountId;
	}

	/**
	 * @param accountId
	 * 		set to account id
	 */
	public void setAccountId(@NotBlank final String accountId) {

		this.accountId = accountId;
	}

	/**
	 * @return user id
	 */
	public String getUserId() {

		return userId;
	}

	/**
	 * @param userId
	 * 		set to user id
	 */
	public void setUserId(final String userId) {

		this.userId = userId;
	}

	/**
	 * @return keyword
	 */
	public String getKeyword() {

		return keyword;
	}

	/**
	 * keyword condition by user name or user login id
	 *
	 * @param keyword
	 * 		set to search keyword
	 */
	public void setKeyword(final String keyword) {

		this.keyword = keyword;
	}

	/**
	 * @return user statuses set
	 */
	public Set<String> getStatuses() {

		return statuses;
	}

	/**
	 * @param statuses
	 * 		set to user statuses
	 */
	public void setStatuses(final Set<String> statuses) {
		this.statuses = statuses;
	}


	/**
	 * @return user types
	 */
	public Set<String> getUserTypes() {
		return userTypes;
	}

	/**
	 * @param userTypes
	 * 		set to user types
	 */
	public void setUserTypes(final Set<String> userTypes) {
		this.userTypes = userTypes;
	}

	public void setDateRange(DateRange dateRange) {
		this.dateRange = dateRange;
	}

	/**
	 * @return department id
	 */
	public String getDepartmentId() {
		return departmentId;
	}

	/**
	 * @param departmentId
	 * 		set to user departmentId
	 */
	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public DateRange getDateRange() {
		return dateRange;
	}

}
