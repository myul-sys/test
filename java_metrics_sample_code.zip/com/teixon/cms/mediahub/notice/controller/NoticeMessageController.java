package com.teixon.cms.mediahub.notice.controller;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.annotation.SendToUser;

public class NoticeMessageController {

    /**
     * receiver push alarm
     */
    @MessageMapping("/sendMessage")
    @SendToUser("/topic/message")
    public String sendMessage(String message, SimpMessageHeaderAccessor messageHeaderAccessor){

        return message;
    }
}
