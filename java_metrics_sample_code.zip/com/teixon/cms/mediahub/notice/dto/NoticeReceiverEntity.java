package com.teixon.cms.mediahub.notice.dto;


import com.teixon.cms.mediahub.common.jpa.columns.ColumnLength;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@EntityListeners(value ={AuditingEntityListener.class})
@Table(name = "Notice_Receiver_tbl")
public class NoticeReceiverEntity {

    /**
     * notice Receiver id
     */
    @Id
    @Column(name = "notice_his_id", nullable = false, updatable = false, length = ColumnLength.UUID)
    @GenericGenerator(name = "notice_Receiver_id_uuid", strategy = "com.teixon.cms.mediahub.common.jpa.id.UUIDGenerator")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "notice_Receiver_id_uuid")
    private String noticeReceiverId;


    /**
     * notice id
     */
    @Column(name = "notice_id", length = ColumnLength.TITLE)
    public String noticeId;

    /**
     * account id
     */
    @Column(name = "acct_id", nullable = false, updatable = false, length = ColumnLength.UUID)
    public String accountId;

    /**
     * 현장 id
     */
    @Column(name = "event_id", length = ColumnLength.UUID)
    public String eventId;


    /**
     * 수신 사용자 아이디
     */
    @Column(name = "receiver_id", nullable = false, length = ColumnLength.UUID)
    public String receiverId;

    /**
     * 수신 사용자 이름
     */
    @Column(name = "receiver_nm", nullable = false, length = ColumnLength.NAME)
    public String receiverName;

    /**
     * notice status
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 100)
    public NoticeStatus status;

    /**
     * notice added date
     */
    @CreatedDate
    @Column(name = "reg_dt", nullable = false)
    public Date registerDate;


    public NoticeReceiverEntity() {

        this.status = NoticeStatus.fail;
    }

    @Override
    public String toString() {

        return ToStringBuilder.reflectionToString(this);
    }

    /**
     * notice status
     */
    public enum NoticeStatus {

        /**
         * 실패
         */
        fail,

        /**
         * 성공
         */
        success,

    }














}
