package com.teixon.cms.mediahub.mail.controller;


import com.teixon.cms.mediahub.mail.service.MailService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@RestController
@RequestMapping("/email")
public class MailController {


    @Autowired
    private MailService mailService;

    /**
     * logger
     */
    private final Logger logger = LoggerFactory.getLogger(MailController.class);



    /**
     * mail api 요청 받으면 여기로 감.
     *
     * */
    @PostMapping("/sendPw")
    public ModelAndView sendEmail_pw (
            HttpServletRequest request, HttpServletResponse response) {

        HttpSession session = request.getSession();
        String loginId = (String) session.getAttribute("loginId");

        logger.debug("email redirectMap [loginId={}]", loginId);

        //mailService.sendEmail(loginId);

        return new ModelAndView();
    }
}
