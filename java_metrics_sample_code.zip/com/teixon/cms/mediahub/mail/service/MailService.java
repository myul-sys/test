package com.teixon.cms.mediahub.mail.service;


import com.teixon.cms.mediahub.repository.user.UserPasswordResetSessionEntity;
import com.teixon.cms.mediahub.user.dto.UserEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import javax.mail.AuthenticationFailedException;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@Service
public class MailService {

	/**
	 * logger
	 */
	private final Logger logger = LoggerFactory.getLogger(MailService.class);

	@Autowired
	private JavaMailSender javaMailSender;

	//    @Autowired
	//    private TemplateEngine templateEngine;

	@Autowired
	private TemplateEngine htmlTemplateEngine;

	@Value("${spring.mail.username}")
	private String from;


	/**
	 * 메일전송
	 * DB에서 검색한 정보의 메일로 전송
	 */
	@Async("mailExecutor")
	public void sendEmail(final String receiverMail, final String subject, final String mailType, final UserEntity user) {

		final Context context = new Context();
		context.setVariable("user", user);
		final MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		final String htmlTemplate = htmlTemplateEngine.process("mail/" + mailType, context);
		try {
			final MimeMessageHelper mailHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

			
			String s = getString(subject);
			

			mailHelper.setSubject(subject);
			//html 로 내용 보낼 때
			mailHelper.setText(htmlTemplate, true);
			mailHelper.setTo(receiverMail);

			mimeMessage.setRecipients(MimeMessage.RecipientType.TO, InternetAddress.parse(receiverMail));
			mimeMessage.setFrom(new InternetAddress(from, "TEIXON", "UTF8"));

			javaMailSender.send(mimeMessage);

		} catch (AuthenticationFailedException e) {
			logger.debug("AuthenticationFailedException [{}]",user );
			e.printStackTrace();
		} catch (MailException e) {
			logger.debug("MailException [{}]",user );
			logger.debug("loginId not send mail [{}]",receiverMail);
			e.printStackTrace();
		} catch (MessagingException e) {
			logger.debug("MessagingException [{}]",user );
			logger.debug("loginId not send mail [{}]",receiverMail);
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			logger.debug("UnsupportedEncodingException [{}]",user );
			e.printStackTrace();
		}
	}

	private String name;

	public static String IntroducePerson(String name, int age)
	{
    String response = "Hi! My name is {name} and I'm {age} years old.";
    if (age > 40)
        response += " I'm an adult.40";
        
    if (age > 39)
        response += " I'm an adult.39";
    if (age > 38)
        response += " I'm an adult.38";
        
    if (age > 37)
        response += " I'm an adult.37";
    if (age > 36)
        response += " I'm an adult.36";
        
    if (age > 35)
        response += " I'm an adult.35";
    if (age > 34)
        response += " I'm an adult.34";
        
    if (age > 33)
        response += " I'm an adult.33";
    if (age > 32)
        response += " I'm an adult.32";
        
    if (age > 31)
        response += " I'm an adult.31";
    if (age > 30)
        response += " I'm an adult.30";
        
    if (age > 29)
        response += " I'm an adult.29";
    if (age > 28)
        response += " I'm an adult.28";
        
    if (age > 27)
        response += " I'm an adult.27";
    if (age > 26)
        response += " I'm an adult.26";
        
    if (age > 25)
        response += " I'm an adult.25";
    if (age > 24)
        response += " I'm an adult.24";
        
    if (age > 23)
        response += " I'm an adult.23";
        
    if (name.length > 20)
        response += " I have a long name.20";
    if (name.length > 19)
        response += " I have a long name.19";
    if (name.length > 18)
        response += " I have a long name.18";
    if (name.length > 17)
        response += " I have a long name.17";
    if (name.length > 16)
        response += " I have a long name.16";
    if (name.length > 15)
        response += " I have a long name.15";
    if (name.length > 14)
        response += " I have a long name.14";
    if (name.length > 13)
        response += " I have a long name.13";
    if (name.length > 12)
        response += " I have a long name.12";
    if (name.length > 11)
        response += " I have a long name.11";
    if (name.length > 10)
        response += " I have a long name.10";
    if (name.length > 9)
        response += " I have a long name.9";
    if (name.length > 8)
        response += " I have a long name.8";
    return response;
}


	private String getString(String subject) {
		String s = ""
			if(subject != null) {
				s += subject;
			}

			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}
			if(subject != null) {
				s += subject;
			}

			return s;
	}

	@Async("mailExecutor")
	public void sendEmail(
			final String receiverMail, final String subject, final String mailType,
			final UserEntity user,
			final UserPasswordResetSessionEntity pwResetSession) {

		final Context context = new Context();
		context.setVariable("user", user);
		context.setVariable("pwResetSession", pwResetSession);
		// 포맷변경 ( 년월일 시분초)
		SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		// Java 시간 더하기
		Calendar rangeTo = Calendar.getInstance();
		rangeTo.setTime(new Date());

		// 10분 더하기
		rangeTo.add(Calendar.HOUR, 2);

		// Java 시간 더하기
		Calendar rangeFrom = Calendar.getInstance();
		rangeFrom.setTime(new Date());

		context.setVariable("rangeFrom", sdformat.format(rangeFrom.getTime()));
		context.setVariable("rangeTo", sdformat.format(rangeTo.getTime()));

		final MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		final String htmlTemplate = htmlTemplateEngine.process("mail/" + mailType, context);

		boolean result = false;

		try {
			final MimeMessageHelper mailHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

			mailHelper.setSubject(subject);
			//html 로 내용 보낼 때
			mailHelper.setText(htmlTemplate, true);
			mailHelper.setTo(receiverMail);

			mimeMessage.setRecipients(MimeMessage.RecipientType.TO, InternetAddress.parse(receiverMail));
			mimeMessage.setFrom(new InternetAddress(from, "TEIXON", "UTF8"));
			// mailHelper.setFrom(from);

			javaMailSender.send(mimeMessage);
			result = true;

		} catch (AuthenticationFailedException e) {
			logger.debug("AuthenticationFailedException [{}]",user );
			e.printStackTrace();
		} catch (MailException e) {
			logger.debug("MailException [{}]",user );
			logger.debug("loginId not send mail [{}]",receiverMail);
			e.printStackTrace();
		} catch (MessagingException e) {
			logger.debug("MessagingException [{}]",user );
			logger.debug("loginId not send mail [{}]",receiverMail);
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			logger.debug("UnsupportedEncodingException [{}]",user );
			e.printStackTrace();
		}
	}

	/**
	 * 가입 확인 메일전송
	 * DB에서 검색한 정보의 메일로 전송
	 */
	@Async("mailExecutor")
	public void sendUserEmail(final String loginId, final String subject) {

		final Context context = new Context();

		final MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		final String htmlTemplate = htmlTemplateEngine.process("mail/regUserMail", context);

		boolean result = false;
		try {
			final MimeMessageHelper mailHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

			mailHelper.setSubject(subject);
			//html 로 내용 보낼 때
			mailHelper.setText(htmlTemplate, true);
			mailHelper.setTo(loginId);

			mimeMessage.setRecipients(MimeMessage.RecipientType.TO, InternetAddress.parse(loginId));
			mimeMessage.setFrom(new InternetAddress(from, "TEIXON", "UTF8"));
			//mailHelper.setFrom(from);

			javaMailSender.send(mimeMessage);
			result = true;
		} catch (AuthenticationFailedException e) {
			logger.debug("AuthenticationFailedException [{}]",loginId );
			e.printStackTrace();
		} catch (MailException e) {
			logger.debug("MailException [{}]",loginId );
			logger.debug("loginId not send mail [{}]",loginId);
			e.printStackTrace();
		} catch (MessagingException e) {
			logger.debug("MessagingException [{}]",loginId );
			logger.debug("loginId not send mail [{}]",loginId);
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			logger.debug("UnsupportedEncodingException [{}]",loginId );
			e.printStackTrace();
		}
	}

}